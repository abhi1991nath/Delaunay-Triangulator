#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
#include "lexical_analyser.h"

int main(int argc,char* argv[])
{
	int token_count, i,problem_index;
	struct symbol_table * table;
	//system("cd ../");
	//system("cd ./lexical_analyser/");
	struct config_file_entry *token_names = scan_config_file(  &token_count,&problem_index);
	if( token_names == NULL ) return 1;
	//for( i=0; i<token_count; i++ )
	//{
	//	printf("Token %s Spec %s\n", token_names[i].token_name, token_names[i].spec);
	//}
	
	//return 0;

	//fp = fopen("lex_config","r");
	//while(fp)
	//{
	//	fgets(fp,buffer,100);
	//	// parse and create automata for each token
	//}
	//close(fp);
	
	table = prog_lex_analyse(token_names,token_count,problem_index,argv[1]);
	if(table)
	{
		destroySymbolTable(table);
	}
	free(token_names);
	return 0;		
}
