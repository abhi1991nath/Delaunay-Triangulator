#define TOKEN_NAME_LENGTH 32                      // a part of <a,b>
#define TOKEN_LENGTH (TOKEN_NAME_LENGTH + 1 + 20) // 1 for comma <a,b>
#define LEXEME_MAX_LENGTH 256

//create structures for creating automata
struct in_file_pos
{
	int pos[2];
	struct in_file_pos* next;
};

struct table_entry
{
	char token_name[TOKEN_NAME_LENGTH];
	char lexeme[LEXEME_MAX_LENGTH];
	int attr;
	struct in_file_pos *positions_head,*positions_last;
	struct table_entry* next; 
	struct table_entry* type_next;
};

struct symbol_table
{
	struct table_entry **categories,*start,*last;
	int count,error;
};

struct config_file_entry
{
	char token_name[30];
	char spec[200];
};

struct automata_output
{
	char token_name[30];
	int index, lexeme_length;
};

int Max( int a, int b );
int match_delim( char a, char** b, int n );
int match_char( char a, char** b, int n1, int n2 );
int find_tab( char** a);
void append( char* a, char b);
char** space_separate( char* a, int n1, int n2, int* length );
struct automata_output *match_lexeme( struct config_file_entry *cfe, char* lexeme_begin );
struct automata_output *get_token( char* lexeme_begin, struct config_file_entry *clist, int token_count);
struct config_file_entry *scan_config_file(char* ConfigFile , int *t_c, int *p_c );

struct symbol_table * lexical_main(char program[],char ConfigFile[]);

struct symbol_table * prog_lex_analyse(struct config_file_entry*,int,int,char []);
void destroySymbolTable(struct symbol_table *);
void printSymbolTable(struct symbol_table *);
