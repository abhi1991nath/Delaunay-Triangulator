
//#define CONFIG_FILE "../config_files/config_file_ifelse"
#define TOKEN_PROG_FILE "lexical_analyser/token_prog"
#define ERROR_LOG_FILE "lexical_analyser/error_log"
#define SYMBOL_TABLE_FILE "lexical_analyser/symbol_table"
//#define GRAMMER_FILE_NAME "../Grammars/IfElseGrammerUnambigous"
