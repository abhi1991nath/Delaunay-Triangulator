#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>

#include "lexical_analyser/lexical_analyser.h"
#include "file_names.h"
#include "slrparser.h"

int tokenize(char* pt,char c,char* name,int length)
{
	int i = 0;
	char* ptr = name;
	if(*pt == '\0')return -1; 
	while(*pt != c && *pt != '\n' && i < length-1){*ptr = *pt ; ptr++; pt++; i++;}
	*ptr = '\0';
	if(i < length - 1)return i;  //no. of characters matched
	else return -1;
}

struct NonTerminal * searchNT(char* name,struct NonTerminal *startptrN)
{
	struct NonTerminal * ptrN = startptrN;
	if(ptrN)
	{
		do
		{
			if(strcmp(name,ptrN->name) == 0)return ptrN;
			else ptrN = ptrN -> next;
		}
		while(ptrN);
	}
	return NULL;
}

struct NonTerminal * getPtrOfNT(char* name,struct SetOfNonTerminals * mainPtr,int inSet)
{
	struct NonTerminal * ptrN = searchNT(name,mainPtr->start);
	if(ptrN)return ptrN;
	else 
	{
		ptrN = (struct NonTerminal *)calloc(1,sizeof(struct NonTerminal));
		if(inSet)ptrN -> name = name;
		else
		{
			ptrN -> name = (char*)malloc((strlen(name)+1)*sizeof(char));
			strcpy(ptrN -> name , name);
		}
		
		if(mainPtr->count == 0)
		{
			mainPtr -> tail = mainPtr -> start = ptrN;
		}
		else 
		{
			mainPtr ->tail = mainPtr -> tail -> next = ptrN;
		}
		(mainPtr->count) ++;
	}
	return ptrN;
}

struct Terminal * searchT(char* name,struct Terminal *startptrT)
{
	struct Terminal * ptrT = startptrT;
	if(ptrT)
	{
		do
		{
			if(strcmp(name,ptrT->name) == 0)return ptrT;
			else ptrT = ptrT -> next;
		}
		while(ptrT);
	}
	return NULL;
}

struct Terminal * getPtrOfT(char* name,struct SetOfTerminals * mainPtr)
{
	struct Terminal * ptrT = searchT(name,mainPtr->start);
	if(ptrT)return ptrT;
	else 
	{
		ptrT = (struct Terminal *)calloc(1,sizeof(struct Terminal));
		ptrT -> name = (char*)malloc((strlen(name)+1)*sizeof(char));
		strcpy(ptrT -> name , name);
		if(mainPtr->count == 0)
		{
			mainPtr -> tail = mainPtr -> start = ptrT;
		}
		else
		{
			mainPtr ->tail = mainPtr -> tail -> next = ptrT;
		}
		(mainPtr->count) ++;
	}
	return ptrT;
}

void addProductions(struct NonTerminal* ptrN, char* pt,struct SetOfNonTerminals *SetPtrN,struct SetOfTerminals *SetPtrT)
{
	char name[NameLength];
	int pos,prodstart=1;
	
	struct NonTerminal_s_Productions *prodset = ptrN ->Productions;
	struct ProductionTail *prod = (struct ProductionTail *)calloc(1,sizeof(struct ProductionTail));
	
	if(ptrN ->Productions == NULL)
	{
		ptrN ->Productions = prodset = (struct NonTerminal_s_Productions *)calloc(1,sizeof(struct NonTerminal_s_Productions));
		prodset-> tailProduction = prodset-> firstProduction = prod; 
	}
	else prodset -> tailProduction -> nextProduction = prod;

	struct ProductionNode *node;/**/
	
	while((pos = tokenize(pt,' ',name,NameLength)) != -1)
	{
		//printf("%s\n",name);
		if(!strcmp(name,EPSILON))node = NULL;
		
		else if(name[0]>=65 && name[0]<=90)
		{
			node = (struct ProductionNode *)calloc(1,sizeof(struct ProductionNode));
			node -> type = N;
			node->self_N = getPtrOfNT(name,SetPtrN,0);
		}
		else
		{
			node = (struct ProductionNode *)calloc(1,sizeof(struct ProductionNode));
			node -> type = T;
			node->self_T = getPtrOfT(name,SetPtrT);
		}
		if(prodstart)
		{
			prod -> start = prod -> cur = prod -> last = node ;
			prod -> head = ptrN;
			 
			prodstart = 0;
			(ptrN->production_count) ++;
			(SetPtrN->production_count) ++;
		}		
		else 
		{
			prod ->last -> next = node;
			prod -> last = prod -> last -> next;
		}
		
		(prod-> prod_length)++;
		
		pt = pt + pos ;
		if(pt[0]!='\0')
		{
			pt += strlen(" "); 
			if(pt[0]=='|')
			{
				prod->nextProduction = (struct ProductionTail *)calloc(1,sizeof(struct ProductionTail));
				prod = prod ->nextProduction;
				prodset -> tailProduction = prod;
				prodstart = 1;
				pt = pt + strlen("| ");
			}
		}
	}
	ptrN->ClosureMark = 1;
}

void scanGrammer(char* filename,struct SetOfNonTerminals *mainPtrN,struct SetOfTerminals *mainPtrT)
{
	FILE *fp = fopen(filename,"r");
	
	char line[LineLength],*pt;
	char name[NonTerminalLength];
	int pos;
	struct NonTerminal *ptrN;
	
	while (fgets(line,LineLength,fp))
	{
		
		if(!strcmp(line,"") || line[0]=='#')continue;
		pt = line;
		pos = tokenize(pt,' ',name,NonTerminalLength);
		ptrN = getPtrOfNT(name,mainPtrN,0);
		pt += pos + strlen(" := ") ; 
		//printf("%s%s := \n",line,name);
		addProductions(ptrN,pt,mainPtrN,mainPtrT);
	}
	fclose(fp);	
}

void printGrammer(struct SetOfNonTerminals *SetPtrN,struct SetOfTerminals *SetPtrT,int detailed)
{
	struct NonTerminal *ptN;
	struct Terminal *ptT;
	struct ProductionTail *ptProd;
	struct ProductionNode *ptNode;
	struct terminal_pointer_entry *ptTentry;
	int i;
	if(SetPtrN->count == 0)printf("NonTerminal Set is Empty\n\n");
	else
	{
		printf("\n%d Non Terminal's Productions are :-\n\n",SetPtrN->count);
		ptN = SetPtrN -> start;
		do
		{
			printf("%s",ptN->name);
			if(ptN -> Productions != NULL)
			{
				printf(" := ");
				ptProd = ptN -> Productions -> firstProduction;
				do
				{
					
					ptNode = ptProd -> start;
					i = ptProd -> dotpos;
					if(ptNode == NULL)printf(EPSILON);
					while(ptNode != NULL)
					{
						if(!detailed && i-- == 0)printf(". ");
						if(ptNode -> type == N)
						{
							printf("%s",ptNode -> self_N -> name);
						}
						else
						{
							printf("%s",ptNode -> self_T -> name);
						}
						ptNode = ptNode ->next;
						printf("%s",ptNode != NULL?" ":"");
					}
					if(!detailed && ptProd -> start && i == 0)printf(" .");
					
					ptProd = ptProd -> nextProduction;
					printf("%s",ptProd != NULL?" | ":"\n");
				}while(ptProd != NULL);
			}
			else printf("\nNo Productions from this Non Terminal \n\n");
			
			
			if(detailed && ptN->FirstSet)
			{
				printf("First Set := ");
				ptTentry = ptN->FirstSet->start;
				while(ptTentry)
				{
					printf("%s%s",ptTentry->self->name,(ptTentry->next)?", ":"");
					ptTentry = ptTentry -> next;
				}
				if(ptN->FirstSet->isepsilon)printf("%s%s",(ptN->FirstSet->count)?", ":"",EPSILON);
				printf("\n");
			}
			
			if(detailed && ptN->FollowSet)
			{
				printf("Follow Set := ");
				ptTentry = ptN->FollowSet->start;
				while(ptTentry)
				{
					printf("%s%s",ptTentry->self->name,(ptTentry->next)?", ":"");
					ptTentry = ptTentry -> next;
				}
				if(ptN->FollowSet->isdollor)printf("%s%s",(ptN->FollowSet->count)?", ":"",DOLLOR);
				printf("\n\n");
			}
			
			ptN = ptN -> next;
		}while(ptN !=NULL);
	}
	
	if(detailed)
	{
		if(SetPtrT && SetPtrT->count)
		{
			printf("\n%d Terminal are :-\n",SetPtrT->count);
			ptT = SetPtrT -> start;
			while(ptT)
			{
				printf("%s\n",ptT->name);
				ptT = ptT -> next;
			}
		}
	}
}

void destroyGrammer(struct SetOfNonTerminals *SetPtrN,struct SetOfTerminals *SetPtrT, int final)
{
	struct NonTerminal *ptN;
	struct Terminal *ptT;
	struct ProductionTail *ptProd;
	struct ProductionNode *ptNode;
	struct NonTerminal_s_Productions *prods;
	struct terminal_pointer_entry *ptTentry;
	if(SetPtrN->count == 0);
	else
	{
		//printf("%d Non Terminal's Productions are :-\n",SetPtrN->count);
		ptN = SetPtrN -> start;
		do
		{
			//printf("%s",ptN->name);
			prods = ptN -> Productions;
			if(prods != NULL)
			{
				//printf(" := ");
				ptProd = prods -> firstProduction;
				do
				{
					if(final)
					{
						ptNode = ptProd -> start;
						while(ptNode != NULL)
						{
							ptProd -> start = ptProd -> start ->next;
							free(ptNode);
							ptNode = ptProd->start; 
							//printf("%s",ptNode != NULL?" ":"");
						}
					}
					
					//ptProd = ptProd -> nextProduction;
					prods -> firstProduction = prods -> firstProduction -> nextProduction;
					free(ptProd);
					ptProd = prods-> firstProduction;
					//printf("%s",ptProd != NULL?" | ":"\n");
				}while(ptProd != NULL);
			}
			free(prods);
			if(final)free(ptN->name);
			//else printf("\nNo Productions from this Non Terminal \n");
			SetPtrN -> start = SetPtrN -> start -> next;
			
			if(ptN->FirstSet)
			{
				ptTentry = ptN->FirstSet->start;
				//if(!(ptN->StartSet->isepsilon))printf("%s ,",EPSILON);
				while(ptTentry)
				{
					//printf("%s%s",ptTentry->name,ptTentry->next?" ,":"\n\n");
					ptTentry = ptTentry -> next;
					free(ptN->FirstSet->start);
					ptN->FirstSet->start = ptTentry;
				}
				free(ptN->FirstSet);
			}
			
			if(ptN->FollowSet)
			{
				ptTentry = ptN->FollowSet->start;
				//if(!(ptN->StartSet->isepsilon))printf("%s ,",EPSILON);
				while(ptTentry)
				{
					//printf("%s%s",ptTentry->name,ptTentry->next?" ,":"\n\n");
					ptTentry = ptTentry -> next;
					free(ptN->FollowSet->start);
					ptN->FollowSet->start = ptTentry;
				}
				free(ptN->FollowSet);
			}			
						
			free(ptN);
			ptN = SetPtrN -> start;
		}while(ptN !=NULL);
	}
	
	if(final)
	{
		if(SetPtrT && SetPtrT->count == 0);
		else
		{
			//printf("%d Terminal are :-\n",SetPtrT->count);
			ptT = SetPtrT -> start;
			while(ptT)
			{
				//printf("%s\n",ptT->name);
				SetPtrT -> start = SetPtrT -> start -> next;
				if(final)free(ptT->name);
				free(ptT);
				ptT = SetPtrT -> start;
			}
		}
		free(SetPtrT);
	}
	
	free(SetPtrN);
}

void ExtendGrammer(struct SetOfNonTerminals * MainPtrN)
{
	struct NonTerminal *ptN = MainPtrN -> start;
	MainPtrN -> start = (struct NonTerminal *)calloc(1,sizeof(struct NonTerminal));
	MainPtrN -> start -> next = ptN;
	MainPtrN -> start -> name = (char*)malloc(2*sizeof(char));
	strcpy(MainPtrN -> start -> name,EXTENDED_START_SYMBOL);
	MainPtrN -> start -> production_count = 1;
	MainPtrN -> start -> ClosureMark = 0;
	(MainPtrN -> count) ++;
	(MainPtrN -> production_count) ++;
	MainPtrN -> start -> Productions = (struct NonTerminal_s_Productions *)calloc(1,sizeof(struct NonTerminal_s_Productions));
	MainPtrN -> start -> Productions -> firstProduction = (struct ProductionTail *)calloc(1,sizeof(struct ProductionTail));
	MainPtrN -> start -> Productions -> tailProduction = MainPtrN -> start -> Productions -> firstProduction;
	MainPtrN -> start -> Productions -> firstProduction -> start =  (struct ProductionNode *)calloc(1,sizeof(struct ProductionNode));
	MainPtrN -> start -> Productions -> firstProduction -> cur = MainPtrN -> start -> Productions -> firstProduction -> start;
	MainPtrN -> start -> Productions -> firstProduction -> last = MainPtrN -> start -> Productions -> firstProduction -> start;
	MainPtrN -> start -> Productions -> firstProduction -> dotpos = 0;
	MainPtrN -> start -> Productions -> firstProduction -> head = MainPtrN -> start;
	MainPtrN -> start -> Productions -> firstProduction -> start -> type = N;
	MainPtrN -> start -> Productions -> firstProduction -> start -> self_N =  MainPtrN -> start -> next;
}

struct SetOfNonTerminals * StartSet(struct SetOfNonTerminals * MainPtrN)
{
	struct SetOfNonTerminals * startSet = (struct SetOfNonTerminals *)calloc(1,sizeof(struct SetOfNonTerminals));
	startSet -> count = 1;
	startSet -> production_count = 1;
	startSet -> start = startSet -> tail = (struct NonTerminal *)calloc(1,sizeof(struct NonTerminal));
	startSet -> start -> name = MainPtrN -> start -> name ;
	startSet -> start -> production_count = 1;
	startSet -> start -> ClosureMark = 0;
	startSet -> start -> Productions = (struct NonTerminal_s_Productions *)calloc(1,sizeof(struct NonTerminal_s_Productions));
	startSet -> start -> Productions -> firstProduction = (struct ProductionTail *)calloc(1,sizeof(struct ProductionTail));
	startSet -> start -> Productions -> firstProduction -> start =  MainPtrN -> start -> Productions -> firstProduction -> start;
	startSet -> start -> Productions -> firstProduction -> cur = MainPtrN -> start -> Productions -> firstProduction -> start;
	startSet -> start -> Productions -> firstProduction -> last = MainPtrN -> start -> Productions -> firstProduction -> start;
	startSet -> start -> Productions -> firstProduction -> dotpos = 0;
	startSet -> start -> Productions -> firstProduction -> head = startSet -> start;
	startSet -> start -> Productions -> firstProduction -> start -> type = N;
	startSet -> start -> Productions -> firstProduction -> start -> self_N =  MainPtrN -> start -> next;
	return startSet;
}

struct SetOfNonTerminals * Clone (struct SetOfNonTerminals * SetPtrN)
{
	struct SetOfNonTerminals * SetCopy = (struct SetOfNonTerminals *)calloc(1,sizeof(struct SetOfNonTerminals));
	struct NonTerminal *ptN,*ptNCopy;
	struct ProductionTail *ptProd,*ptProdCopy;
	struct ProductionNode *ptNode;
	if(SetPtrN->count == 0)return SetCopy;
	else
	{
		//printf("%d Non Terminal's Productions are :-\n",SetPtrN->count);
		SetCopy -> count = SetPtrN->count;
		SetCopy -> production_count = SetPtrN->production_count;
		ptN = SetPtrN -> start;
		ptNCopy = SetCopy -> tail = SetCopy -> start = (struct NonTerminal *)calloc(1,sizeof(struct NonTerminal));
		do
		{
			//printf("%s",ptN->name);
			ptNCopy->name = ptN->name;
			ptNCopy->production_count = ptN->production_count;
			ptNCopy->ClosureMark = ptN->ClosureMark;
			if(ptN -> Productions != NULL)
			{
				//printf(" := ");
				ptNCopy->Productions = (struct NonTerminal_s_Productions *)calloc(1,sizeof(struct NonTerminal_s_Productions));
				ptNCopy->Productions->firstProduction = ptNCopy->Productions->tailProduction = (struct ProductionTail *)calloc(1,sizeof(struct ProductionTail));
				ptProdCopy = ptNCopy->Productions->firstProduction;
				ptProd = ptN -> Productions -> firstProduction;
				do
				{
					ptProdCopy->start = ptProd -> start;
					ptProdCopy->last = ptProd -> last;
					ptProdCopy->cur = ptProd -> cur;
					ptProdCopy->dotpos = ptProd -> dotpos;
					ptProdCopy->head = ptNCopy;
					
					ptProd = ptProd -> nextProduction;
					if(ptProd != NULL)
					{
						ptProdCopy->nextProduction = ptNCopy->Productions->tailProduction = (struct ProductionTail *)calloc(1,sizeof(struct ProductionTail));
						ptProdCopy = ptProdCopy->nextProduction;
					}
					//printf("%s",ptProd != NULL?" | ":"\n");
				}while(ptProd != NULL);
			}
			//else printf("\nNo Productions from this Non Terminal \n");
			ptN = ptN -> next;
			if(ptN != NULL)
			{
				ptNCopy -> next = SetCopy -> tail = (struct NonTerminal *)calloc(1,sizeof(struct NonTerminal));
				ptNCopy = ptNCopy -> next;
			}
		}while(ptN !=NULL);	
	}
	return SetCopy;
}

void copyProduction(struct NonTerminal * ptDestination,struct NonTerminal * ptSource)
{
	if(ptSource->production_count)
	{
		struct ProductionTail *prodS = ptSource->Productions->firstProduction;
		struct NonTerminal_s_Productions *prodset = ptDestination ->Productions;
		struct ProductionTail *prod = (struct ProductionTail *)calloc(1,sizeof(struct ProductionTail));
	
		if(ptDestination ->Productions == NULL)
		{
			ptDestination ->Productions = prodset = (struct NonTerminal_s_Productions *)calloc(1,sizeof(struct NonTerminal_s_Productions));
			prodset-> tailProduction = prodset-> firstProduction = prod; 
		}
		else prodset -> tailProduction -> nextProduction = prod;
		
		do
		{
			prod->start = prodS -> start;
			prod->cur = prodS -> cur;
			prod->last = prodS -> last;
			prod->head = ptDestination;
			prod->dotpos = prodS -> dotpos;
			
			prodS = prodS -> nextProduction ;
			if(prodS)
			{
				prod -> nextProduction = (struct ProductionTail *)calloc(1,sizeof(struct ProductionTail));
				prod = prod -> nextProduction;
				prodset -> tailProduction = prod;
			}
		}while(prodS != NULL);
		ptDestination -> production_count += ptSource -> production_count;
	}	
}

struct SetOfNonTerminals * Closure (struct SetOfNonTerminals * SetPtrN)
{
	int change;
	struct SetOfNonTerminals *SetClosure = SetPtrN; //Clone(SetPtrN); 
	struct NonTerminal *ptClosure,*ptmain,*ptN;
	//struct Terminal *ptT;
	struct ProductionTail *ptProdClosure,*ptProdmain;
	struct ProductionNode *ptNode;
	if(SetClosure->count == 0)return SetClosure;
	else
	{
		do
		{
			ptClosure = SetClosure -> start;
			change = 0;
			//printf("%s",ptN->name);
			do
			{
				if(ptClosure -> Productions != NULL)
				{
					//printf(" := ");
					ptProdClosure = ptClosure -> Productions -> firstProduction;
					do
					{
						ptNode = ptProdClosure->cur;
						if(ptNode)
						{
							if(ptNode->type == N)
							{
								ptN = getPtrOfNT(ptNode->self_N->name,SetClosure,1);
								if(ptN->ClosureMark != 1)
								{
									copyProduction(ptN,ptNode->self_N);
									SetClosure->production_count += ptNode->self_N->production_count;
									ptN->ClosureMark = 1;
									change = 1;
								}
							}
						}
						ptProdClosure = ptProdClosure -> nextProduction; 
					}while(ptProdClosure != NULL);
				}
				ptClosure = ptClosure -> next;
			}while(ptClosure != NULL);
		}while(change);
	}
	return SetClosure;
}

struct SetOfNonTerminals * Goto(struct SetOfNonTerminals * SetPtrN,char* name)
{
	struct SetOfNonTerminals * SetGoto = (struct SetOfNonTerminals *)calloc(1,sizeof(struct SetOfNonTerminals));
	struct NonTerminal *ptN,*ptNGoto;
	//struct Terminal *ptT;
	struct ProductionTail *ptProd,*ptProdGoto;
	//struct ProductionNode *ptNode;
	struct NonTerminal_s_Productions *prods,*prodsGoto;
	int first,created;
	
	if(SetPtrN && SetPtrN->production_count)
	{
		ptN = SetPtrN -> start;
		first = 0;
		do
		{
			created = 0;
			//printf("%d\n",ptN->production_count);
			if(ptN->production_count)
			{
				prods = ptN->Productions;
				ptProd = prods->firstProduction;
				do
				{
					if(ptProd->cur 
						&& 
						(
							((ptProd->cur->type == N) && !strcmp(ptProd->cur->self_N->name,name))
							||
							((ptProd->cur->type == T) && !strcmp(ptProd->cur->self_T->name,name))
						)
					  )
					{
						if(!created)
						{
							ptNGoto = (struct NonTerminal *)calloc(1,sizeof(struct NonTerminal));
							ptNGoto -> name = ptN -> name;
							prodsGoto = ptNGoto -> Productions = (struct NonTerminal_s_Productions *)calloc(1,sizeof(struct NonTerminal_s_Productions));
							prodsGoto -> firstProduction = (struct ProductionTail *)calloc(1,sizeof(struct ProductionTail));
							ptProdGoto = prodsGoto -> tailProduction = prodsGoto -> firstProduction;
							created = 1;
							if(!first)
							{
								SetGoto->start = SetGoto->tail = ptNGoto;
								first = 1;
							}
							else
							{
								SetGoto -> tail = SetGoto -> tail -> next = ptNGoto;
							}
						}
						else
						{
							prodsGoto -> tailProduction -> nextProduction = (struct ProductionTail *)calloc(1,sizeof(struct ProductionTail));
							prodsGoto -> tailProduction = ptProdGoto = prodsGoto -> tailProduction -> nextProduction;
						}
						ptProdGoto -> start = ptProd -> start;
						ptProdGoto -> last = ptProd -> last;
						ptProdGoto -> cur = ptProd -> cur->next;
						ptProdGoto -> head = ptNGoto;
						ptProdGoto -> dotpos = (ptProd -> dotpos) + 1;
						
						(ptNGoto -> production_count) ++;
					}
					ptProd = ptProd -> nextProduction;
				}while(ptProd);
				if(created)
				{
					(SetGoto -> count)++;
					(SetGoto -> production_count) += (SetGoto -> tail -> production_count) ;
				}
			}
			ptN = ptN -> next;
		}while(ptN);
	}
	else if(!SetPtrN)return NULL;
	
	return Closure(SetGoto);
	//return SetGoto;
}

int IsCopyPresent(struct SetsOfNonTerminals * itemSet,struct SetOfNonTerminals * SetGoto)
{
	struct SetOfNonTerminals * SetPtr = itemSet -> start;
	struct NonTerminal *ptN,*ptNGoto;
	struct ProductionTail *ptProd,*ptProdGoto;
	struct NonTerminal_s_Productions *prods,*prodsGoto;
	int prodmatch,match,i;	
	match = 0;
	i=1;
	do
	{
		if((SetPtr->count == SetGoto -> count) && (SetPtr->production_count == SetGoto -> production_count))
		{
			ptN = SetPtr -> start;
			do
			{
				ptNGoto = searchNT(ptN->name,SetGoto->start);
				match =1;
				if(ptNGoto && (ptNGoto -> production_count == ptN -> production_count))
				{
					prods = ptN -> Productions;
					prodsGoto = ptNGoto -> Productions;
					ptProd = prods -> firstProduction;
					do
					{
						prodmatch = 0;
						ptProdGoto = prodsGoto -> firstProduction;
						while(!prodmatch && ptProdGoto)
						{
							if((ptProdGoto -> start == ptProd -> start) && (ptProdGoto -> dotpos == ptProd -> dotpos))prodmatch = 1;
							ptProdGoto = ptProdGoto -> nextProduction;
						}
						if(!prodmatch)break;
						ptProd = ptProd -> nextProduction;
					}while(ptProd);
					match = prodmatch;
				}
				else match= 0;
				ptN = ptN -> next;
			}while(match && ptN);
		}
		else match = 0;
		SetPtr = SetPtr -> next;
		i++;
	}while(!match && SetPtr);
	if (match) return i-1;
	else return 0;
}

struct SetsOfNonTerminals * Items(struct SetOfNonTerminals * mainPtrN,struct SetOfTerminals * mainPtrT)
{
	struct SetsOfNonTerminals * itemSet = (struct SetsOfNonTerminals *)calloc(1,sizeof(struct SetsOfNonTerminals ));
	int change;
	struct NonTerminal * PtrN;
	struct Terminal * PtrT;
	struct SetOfNonTerminals *SetPtr,*SetGoto;
	itemSet->start = itemSet->last = Closure(StartSet(mainPtrN));
	itemSet -> count = 1; 
	//do
	//{
	//	change = 0;
		SetPtr = itemSet->start;
		do
		{
			PtrN = mainPtrN -> start;
			do
			{
				SetGoto = Goto(SetPtr , PtrN->name);
				if(((SetGoto -> count) != 0) && !IsCopyPresent(itemSet,SetGoto))
				{
					change = 1;
					itemSet -> last = itemSet -> last -> next = SetGoto;
					(itemSet -> count)++;
				}
				else destroyGrammer(SetGoto,NULL,0);
				PtrN = PtrN -> next;
			}while(PtrN);
			
			PtrT = mainPtrT -> start;
			do
			{
				SetGoto = Goto(SetPtr , PtrT->name);
				if(((SetGoto -> count) != 0) && !IsCopyPresent(itemSet,SetGoto))
				{
					change = 1;
					itemSet -> last = itemSet -> last -> next = SetGoto;
					(itemSet -> count)++;
				}
				else destroyGrammer(SetGoto,NULL,0);				
				PtrT = PtrT -> next;
			}while(PtrT);
			SetPtr = SetPtr -> next;
		}while(SetPtr);
	//}while(change);
	
	return itemSet;
}

void printSetOfItems(struct SetsOfNonTerminals * PtrSets,struct SetOfTerminals *PtrSetT)
{
	struct SetOfNonTerminals * PtrSetN = PtrSets -> start;
	int i = 0;
	do
	{
		printf("\nSet %d Contents are :-\n",++i);
		printGrammer(PtrSetN,PtrSetT,0);
		printf("\n");
		PtrSetN = PtrSetN -> next;
	}while(PtrSetN);
}

void destroySetOfItems(struct SetsOfNonTerminals * PtrSets)
{
	struct SetOfNonTerminals * PtrSetN = PtrSets -> start;
	do
	{
		//printf("\nSet %d Contents are :-\n");
		destroyGrammer(PtrSetN,NULL,0);
		//printf("\n");
		PtrSetN = PtrSetN -> next;
	}while(PtrSetN);
}

void CreateFollow(struct SetOfNonTerminals * mainPtrN)
{
	int change,nextalso,found;
	//struct SetOfNonTerminals *SetClosure = SetPtrN; //Clone(SetPtrN); 
	struct NonTerminal *ptN;
	struct Terminal *ptT;
	struct ProductionTail *ptProd;
	struct ProductionNode *ptNode,*ptNode2;
	struct follow *followset,*followset2;
	struct first *firstset;
	struct terminal_pointer_entry *ptrFollow,*ptrFollow2,*ptrFirst;
	if(mainPtrN->count == 0)return;
	else
	{
		mainPtrN-> start-> FollowSet = (struct follow *)calloc(1,sizeof(struct follow ));
		mainPtrN-> start-> FollowSet -> isdollor = 1;
		do
		{
			//printf("haha ");fflush(stdout);
			ptN = mainPtrN -> start;
			change = 0;
			//printf("%s",ptN->name);
			do
			{
				//printf("haha ");fflush(stdout);
				if(ptN -> Productions != NULL)
				{
					//printf(" := ");
					ptProd = ptN -> Productions -> firstProduction;
					do
					{
						//printf("prod_start ");fflush(stdout);
						ptNode2 = ptProd->start;		
						while(ptNode2)
						{
							//printf("prod_next_node ");fflush(stdout);
							if(ptNode2->type == T)
							{
								ptNode2 = ptNode2->next;
								continue;
							}
							if(!(ptNode2->self_N -> FollowSet))ptNode2->self_N -> FollowSet = (struct follow *)calloc(1,sizeof(struct follow ));
							followset = ptNode2->self_N -> FollowSet;
							ptrFollow = followset -> start;
							ptNode = ptNode2-> next;
							do
							{	
								nextalso = 0;
								if(ptNode)
								{
										
									if(ptNode->type == T)
									{
										ptrFollow = followset -> start;
										found = 0;
										while(!found && ptrFollow)
										{
											if(ptrFollow->self == ptNode->self_T)found = 1;
											
											ptrFollow = ptrFollow -> next;
										}
										if(!found)
										{
											ptrFollow = (struct terminal_pointer_entry *)calloc(1,sizeof(struct terminal_pointer_entry ));
											ptrFollow -> self = ptNode->self_T;
											if(followset->count == 0)
											{
												followset -> start = followset -> tail = ptrFollow;
											}
											else
											{
												followset -> tail = followset -> tail -> next = ptrFollow;
											}
											(followset->count) ++;
											change = 1;
										}
									}
									else
									{
										if(ptNode->self_N->FirstSet)
										{
											firstset = ptNode->self_N->FirstSet;
											if(firstset -> count)
											{
												ptrFirst = firstset -> start;
												do
												{
													ptrFollow = followset -> start;
													found = 0;
													while(!found && ptrFollow)
													{
														if(ptrFollow->self == ptrFirst->self)found = 1;
											
														ptrFollow = ptrFollow -> next;
													}
													if(!found)
													{
														ptrFollow = (struct terminal_pointer_entry *)calloc(1,sizeof(struct terminal_pointer_entry ));
														ptrFollow -> self = ptrFirst->self;
														if(followset->count == 0)
														{
															followset -> start = followset -> tail = ptrFollow;
														}
														else
														{
															followset -> tail = followset -> tail -> next = ptrFollow;
														}
														(followset->count) ++;
														change = 1;
													}
													
													ptrFirst = ptrFirst -> next;
												}while(ptrFirst);
											}
											if(firstset->isepsilon)nextalso = 1;
										}
									}
									ptNode = ptNode->next;
								}
								else 
								{
									if(ptProd->head->FollowSet)
									{
										followset2 = ptProd->head->FollowSet;
										if(followset2 -> count)
										{
											ptrFollow2 = followset2 -> start;
											do
											{
												ptrFollow = followset -> start;
												found = 0;
												while(!found && ptrFollow)
												{
													if(ptrFollow->self == ptrFollow2->self)found = 1;
										
													ptrFollow = ptrFollow -> next;
												}
												if(!found)
												{
													ptrFollow = (struct terminal_pointer_entry *)calloc(1,sizeof(struct terminal_pointer_entry ));
													ptrFollow -> self = ptrFollow2->self;
													if(followset->count == 0)
													{
														followset -> start = followset -> tail = ptrFollow;
													}
													else
													{
														followset -> tail = followset -> tail -> next = ptrFollow;
													}
													(followset->count) ++;
													change = 1;
												}
												
												ptrFollow2 = ptrFollow2 -> next;
											}while(ptrFollow2);
										}
										if(followset2->isdollor && !(followset->isdollor))
										{
											followset->isdollor = 1;
											change = 1;
										}
									}
								}
							}while(nextalso);
							ptNode2 = ptNode2 -> next;
						}
						ptProd = ptProd -> nextProduction; 
						//printf("prod_done ");fflush(stdout);
					}while(ptProd != NULL);
				}
				ptN = ptN -> next;
			}while(ptN != NULL);
		}while(change);
	}
	return ;
}
	
void CreateFirst(struct SetOfNonTerminals * mainPtrN)
{
	int change,nextalso,found;
	//struct SetOfNonTerminals *SetClosure = SetPtrN; //Clone(SetPtrN); 
	struct NonTerminal *ptN;
	struct Terminal *ptT;
	struct ProductionTail *ptProd;
	struct ProductionNode *ptNode,*ptNode2;
	struct first *firstset,*firstset2;
	struct terminal_pointer_entry *ptrFirst,*ptrFirst2;
	if(mainPtrN->count == 0)return;
	else
	{
		do
		{
			//printf("haha ");fflush(stdout);
			ptN = mainPtrN -> start;
			change = 0;
			//printf("%s",ptN->name);
			do
			{
				if(!(ptN -> FirstSet))ptN -> FirstSet = (struct first *)calloc(1,sizeof(struct first ));
				//printf("haha ");fflush(stdout);
				firstset = ptN -> FirstSet;
				ptrFirst = firstset -> start;
				if(ptN -> Productions != NULL)
				{
					//printf(" := ");
					ptProd = ptN -> Productions -> firstProduction;
					do
					{
						ptNode = ptProd->start;
						do
						{
							if(ptNode)
							{
								nextalso = 0;
								if(ptNode->type == T)
								{
									ptrFirst = firstset -> start;
									found = 0;
									while(!found && ptrFirst)
									{
										if(ptrFirst->self == ptNode->self_T)found = 1;
										
										ptrFirst = ptrFirst -> next;
									}
									if(!found)
									{
										ptrFirst = (struct terminal_pointer_entry *)calloc(1,sizeof(struct terminal_pointer_entry ));
										ptrFirst -> self = ptNode->self_T;
										if(firstset->count == 0)
										{
											firstset -> start = firstset -> tail = ptrFirst;
										}
										else
										{
											firstset -> tail = firstset -> tail -> next = ptrFirst;
										}
										(firstset->count) ++;
										change = 1;
									}
								}
								else
								{
									if(ptNode->self_N->FirstSet)
									{
										firstset2 = ptNode->self_N->FirstSet;
										if(firstset2 -> count)
										{
											ptrFirst2 = firstset2 -> start;
											do
											{
												ptrFirst = firstset -> start;
												found = 0;
												while(!found && ptrFirst)
												{
													if(ptrFirst->self == ptrFirst2->self)found = 1;
										
													ptrFirst = ptrFirst -> next;
												}
												if(!found)
												{
													ptrFirst = (struct terminal_pointer_entry *)calloc(1,sizeof(struct terminal_pointer_entry ));
													ptrFirst -> self = ptrFirst2->self;
													if(firstset->count == 0)
													{
														firstset -> start = firstset -> tail = ptrFirst;
													}
													else
													{
														firstset -> tail = firstset -> tail -> next = ptrFirst;
													}
													(firstset->count) ++;
													change = 1;
												}
												
												ptrFirst2 = ptrFirst2 -> next;
											}while(ptrFirst2);
										}
										if(firstset2->isepsilon)nextalso = 1;
									}
								}
								ptNode = ptNode->next;
							}
							else 
							{
								if(!(firstset -> isepsilon))
								{
									firstset -> isepsilon = 1;
									change = 1;
								}
							}
							
						}while(nextalso);
						
						ptProd = ptProd -> nextProduction; 
					}while(ptProd != NULL);
				}
				ptN = ptN -> next;
			}while(ptN != NULL);
		}while(change);
	}
	return ;
}

int getNoOfT(struct SetOfTerminals *T,char* name)
{
	int i=1;
	struct Terminal * ptrT = T->start;
	if(ptrT)
	{
		do
		{
			if(strcmp(name,ptrT->name) == 0)return i;
			else 
			{
				ptrT = ptrT -> next;
				i++;
			}
		}
		while(ptrT);
	}
	return 0;	
}

char* getTbyNo(struct SetOfTerminals *T,int n)
{
	int i=1;
	struct Terminal * ptrT = T->start;
	if(n > 0 && n <= T->count )
	{
		while(ptrT)
		{
			if(i==n)return ptrT->name;
			i++;
			ptrT = ptrT -> next;
		}
	}
	else return NULL;
}

int getNoOfNT(struct SetOfNonTerminals *NT,char* name)
{
	int i=1;
	struct NonTerminal *ptrN = NT->start->next;
	if(ptrN)
	{
		do
		{
			if(strcmp(name,ptrN->name) == 0)return i;
			else 
			{
				ptrN = ptrN -> next;
				i++;
			}
		}
		while(ptrN);
	}
	return 0;	
}

int getNoOfProduction(struct SetOfNonTerminals *NT,char* name,struct ProductionNode *start)
{
	int i=1;
	struct NonTerminal * ptrN = NT->start->next;
	struct ProductionTail *ptrProd;
	if(ptrN)
	{
		do
		{
			if(strcmp(name,ptrN->name) == 0)
			{
				if(ptrN -> production_count == 0)return 0;
				ptrProd = ptrN -> Productions -> firstProduction;
				do
				{
					if(ptrProd -> start == start)return i;
					ptrProd = ptrProd ->nextProduction;
					i++;
				}while(ptrProd);
			}
			else 
			{
				i += ptrN -> production_count;
				ptrN = ptrN -> next;
			}
		}
		while(ptrN);
	}
	return 0;	
}

struct ProductionTail * getProductionbyNo(struct SetOfNonTerminals *NT,int n)
{
	int i=1,k;
	struct NonTerminal *ptrN = NT -> start->next;
	struct ProductionTail *ptrProd;
	if((NT->production_count - 1) == 0 || (NT->production_count - 1) < n)return NULL;
	else
	{
		do
		{
			if(n < i + ptrN->production_count)
			{
				ptrProd = ptrN -> Productions -> firstProduction;
				while(i!=n)
				{
					i++;
					ptrProd = ptrProd -> nextProduction;
				}
				return ptrProd;
			}
			i += ptrN->production_count;
			ptrN = ptrN->next;
		}while(ptrN);
		return NULL;
	}
}

struct ParsingTable * ConstructParsingTable(struct SetsOfNonTerminals * items,struct SetOfNonTerminals *NT,struct SetOfTerminals *Term)
{
	struct ParsingTable * table = (struct ParsingTable *)calloc(1,sizeof(struct ParsingTable ));
	int cur_state,final_state,TerminalNo,NonTerminalNo,ProductionNo,type,value,conflict,i;
	struct SetOfNonTerminals *ptrSetN,*ptrSetGoto;
	struct Terminal *ptrT;
	struct NonTerminal *ptrN,*ptrMain;
	struct ProductionTail *prod;
	struct terminal_pointer_entry *ptEntry;
	
	table->ActionFunc = (struct ActionEntry **)calloc(items->count,sizeof(struct ActionEntry *));
	for(i=0;i<(items->count);i++)
	{
		(table->ActionFunc)[i] = (struct ActionEntry *)calloc(Term->count + 1,sizeof(struct ActionEntry )); // 1  for $
	}
	
	table->GotoFunc = (struct GotoEntry **)calloc(items->count,sizeof(struct GotoEntry *));
	for(i=0;i<(items->count);i++)
	{
		(table->GotoFunc)[i] = (struct GotoEntry *)calloc(NT->count,sizeof(struct GotoEntry ));
	}
	
	cur_state=1;
	conflict =0;
	ptrSetN = items -> start;
	do
	{
		ptrN = ptrSetN -> start;
		do
		{
			prod = ptrN->Productions->firstProduction;
			do
			{
				if((prod-> cur != NULL) && (prod->cur->type == T))
				{
					ptrSetGoto = Goto(ptrSetN,prod->cur->self_T->name);
					if(ptrSetGoto->count && (final_state = IsCopyPresent(items,ptrSetGoto)) )
					{
						TerminalNo = getNoOfT(Term,prod->cur->self_T->name);
						if(((table->ActionFunc)[cur_state-1] + TerminalNo-1)->type == ERROR)
						{
							((table->ActionFunc)[cur_state-1] + TerminalNo-1)->type = SHIFT;
							((table->ActionFunc)[cur_state-1] + TerminalNo-1)->value = final_state;
						}
						else if (((table->ActionFunc)[cur_state-1] + TerminalNo-1)->type == REDUCE)
						{
							value = ((table->ActionFunc)[cur_state-1] + TerminalNo-1)->value;
							printf("Conflict at (%d,%d) : Shift/Reduce : ",cur_state,TerminalNo);
							printf("Shift to %d , Reduce by %d\n",final_state,value);
							conflict = 1;
						}
						else if(((table->ActionFunc)[cur_state-1] + TerminalNo-1)->type == SHIFT)
						{
							if(((table->ActionFunc)[cur_state-1] + TerminalNo-1)->value != final_state)
							{
								value = ((table->ActionFunc)[cur_state-1] + TerminalNo-1)->value;
								printf("strange Conflict at (%d,%d) : Shift/Shift : ",cur_state,TerminalNo);
								printf("Shift to %d , Shift by %d\n",final_state,value);
								conflict = 1;
							}
						}
					}
					destroyGrammer(ptrSetGoto,NULL,0);
				}
				else if(prod-> cur == NULL)
				{
					if(!strcmp(prod->head->name,EXTENDED_START_SYMBOL))
					{
						((table->ActionFunc)[cur_state-1] + Term->count)->type = ACCEPT;
					}
					else
					{
						ptrMain = searchNT(ptrN->name,NT->start);
						ptEntry = ptrMain -> FollowSet->start;
						ProductionNo = getNoOfProduction(NT,ptrN->name,prod->start);
						while(ptEntry)
						{
							TerminalNo = getNoOfT(Term,ptEntry->self->name);
							if(((table->ActionFunc)[cur_state-1] + TerminalNo-1)->type == ERROR)
							{
								((table->ActionFunc)[cur_state-1] + TerminalNo-1)->type = REDUCE;
								((table->ActionFunc)[cur_state-1] + TerminalNo-1)->value = ProductionNo;
							}	
							else
							{
								type = ((table->ActionFunc)[cur_state-1] + TerminalNo-1)->type;
								value = ((table->ActionFunc)[cur_state-1] + TerminalNo-1)->value;
								printf("Conflict at (%d,%d) : %s/Reduce : ",cur_state,TerminalNo,(type == REDUCE)?"Reduce":"Shift");
								printf("Reduce by %d or %s %d\n",ProductionNo,(type == REDUCE)?"Reduce by":"Shift to",value);
								conflict = 1;
							}
							ptEntry = ptEntry -> next;
						}
						if(ptrMain->FollowSet->isdollor)
						{
							TerminalNo = Term->count+1;
							if(((table->ActionFunc)[cur_state-1] + TerminalNo-1)->type == ERROR)
							{
								((table->ActionFunc)[cur_state-1] + TerminalNo-1)->type = REDUCE;
								((table->ActionFunc)[cur_state-1] + TerminalNo-1)->value = ProductionNo;
							}	
							else
							{
								value = ((table->ActionFunc)[cur_state-1] + TerminalNo-1)->value;
								printf("Conflict at (%d,%d) : Reduce/Reduce : ",cur_state,TerminalNo);
								printf("Reduce by %d or %d\n",ProductionNo,value);
								conflict = 1;
							}
						}/**/
					}
				}/**/
				prod = prod -> nextProduction;
			}while(prod);
			ptrN = ptrN -> next;
		}while(ptrN);
		
		ptrN = NT->start->next;
		NonTerminalNo = 1;
		while(ptrN)
		{
			ptrSetGoto = Goto(ptrSetN,ptrN->name);
			if(ptrSetGoto->count && (final_state = IsCopyPresent(items,ptrSetGoto)) )
			{
				((table->GotoFunc)[cur_state-1] + NonTerminalNo -1)->next_state = final_state;
			}/**/
			destroyGrammer(ptrSetGoto,NULL,0);
			ptrN = ptrN->next;
			NonTerminalNo++;
		}
		
		ptrSetN = ptrSetN -> next;
		cur_state++;
	}while(ptrSetN);
	
	table->conflict = conflict;
	return table;
}

void printParsingTable(struct ParsingTable *table,int row,int column1,int column2)
{
	int i,j;
	
	printf("\n         \t");
	for(j=0;j<column1 - 1;j++)printf("T(%d)\t",j+1);
	printf("dollor\t");
	printf("|\t");
	for(j=0;j<column2;j++)printf("NT(%d)\t",j+1);
	printf("\n");
	
	for( i=0;i<row;i++)
	{
		printf("(Item %d)\t",i+1);
		for(j=0;j<column1;j++)
		{
			if(((table->ActionFunc)[i] + j)->type == SHIFT)
			{
				printf("S%d\t",((table->ActionFunc)[i] + j)->value);
			}
			else if(((table->ActionFunc)[i] + j)->type == REDUCE)
			{
				printf("R%d\t",((table->ActionFunc)[i] + j)->value);
			}
			else if(((table->ActionFunc)[i] + j)->type == ACCEPT)
			{
				printf("Acc\t");
			}
			else printf("E\t");
		}
		printf("|\t");
		for(j=0;j<column2;j++)
		{
			if(((table->GotoFunc)[i] + j)->next_state)printf("%d\t",((table->GotoFunc)[i] + j)->next_state);
			else printf("E\t");
		}
		printf("\n");
	}
	
	printf("\nConflict is%s Present in Table. So Grammer is%s SLR(1)\n\n",(table->conflict)?"":" not",(table->conflict)?" not":"");
}

void destroyParsingTable(struct ParsingTable *table,int row)
{
	int i;
	//table->ActionFunc = (struct ActionEntry **)calloc(items->count,sizeof(struct ActionEntry *));
	for(i=0;i<row;i++)
	{
		free((table->ActionFunc)[i]);
	}
	
	//table->GotoFunc = (struct GotoEntry **)calloc(items->count,sizeof(struct GotoEntry *));
	for(i=0;i<row;i++)
	{
		free((table->GotoFunc)[i]);
	}	
	free(table->ActionFunc);
	free(table->GotoFunc);
	free(table);
}

int getCurrentState(struct myStack *myStack1)
{
	if(myStack1->curpos == -1)return 0;
	else return (myStack1->Content)[myStack1->curpos].state ;
}

struct myStackEntry * myPop(struct myStack *myStack1)
{
	if(myStack1->curpos == -1)return ;
	else 
	{
		(myStack1->curpos)--;
		return (myStack1->Content) + (myStack1->curpos) + 1;
	}
	
};

int myPush(struct myStack *myStack1,int value,char* name)
{
	if(myStack1->curpos == STACK_SIZE -1)return -1;
	else
	{
		(myStack1->curpos)++;
		(myStack1->Content)[myStack1->curpos].state = value;
		strcpy((myStack1->Content)[myStack1->curpos].name,name);
	}
}

void printStack(struct myStack *myStack1)
{
	int i = 0;
	printf("\n");
	while(i< (myStack1->curpos)+1)printf("%d  ",(myStack1->Content)[i++].state);
	printf("|");
	i=1;
	while(i< (myStack1->curpos)+1)printf("%s  ",(myStack1->Content)[i++].name);
	//printf("\n");
}

int StringtoNum(char* s)
{
	int value = 0,i=0;
	while(*s)
	{
		value = value*pow(10,i) + (*s - '0');
		s++;
		i++;
	}
	return value;
}

void Capitalize(char *d,char* s)
{
	while(*s)
	{
		if((*s >=97) && (*s <= 122) )*d = *s - ('a' - 'A');
		else *d = *s;
		d++;
		s++;
	}
	*d = '\0';
}

char* identifyProgramTerminal(char *toFind,struct symbol_table *sym_table,struct SetOfTerminals *Term )
{
	char token_name[TOKEN_NAME_LENGTH],lexeme[LEXEME_MAX_LENGTH],term_name_capital[TerminalLength];
	int i,table_pos;
	struct table_entry *ptrTable ;
	struct Terminal *ptrT;
	i = tokenize(toFind,',',token_name,TOKEN_NAME_LENGTH);
	table_pos = StringtoNum(toFind+i+1);
	
	i = 1;
	ptrTable = sym_table->start;
	while(i++ < table_pos) ptrTable = ptrTable -> next;
	strcpy(lexeme,ptrTable->lexeme);
	
	ptrT = Term -> start;
	while(ptrT)
	{
		Capitalize(term_name_capital,ptrT->name);
		if(!strcmp(term_name_capital,token_name))return ptrT->name;
		else if(!strcmp(ptrT->name,lexeme))return ptrT->name;
		ptrT = ptrT -> next;
	}
	return NULL;
}

int getNextToken(FILE* fp,char* Token)
{
	char ch;
	int i;
	if(feof(fp))
	{
		return 1;
	}
	if((ch = fgetc(fp))=='<')
	{
		i = 0;
		while((ch = fgetc(fp))!='>')
		{
			Token[i++] = ch;
		}
		Token[i] = '\0';
		return 0;
	}
	else if(ch==EOF)
	{
		strcpy(Token,DOLLOR);
		return 1;
	}
	else 
	{	
		strcpy(Token,"");
		return -1;
	}
}


void Parsing(struct ParsingTable *table,struct symbol_table *sym_table,struct SetOfNonTerminals *NT,struct SetOfTerminals *Term)
{
	FILE* fp = fopen(TOKEN_PROG_FILE,"r");
	char Token[TOKEN_LENGTH + 1],*input_name;
	int i,j,input_symbol,cur_state,next_state,prod_head_no;
	struct myStack *PtrStack = (struct myStack *)calloc (1,sizeof(struct myStack));
	PtrStack->curpos = -1;
	struct myStackEntry *stEntry;
	struct ProductionTail *prod;
	
	cur_state = 1;
	myPush(PtrStack, cur_state,"");
	
	
		if( ! getNextToken(fp,Token))
		{
			input_name = identifyProgramTerminal(Token,sym_table,Term);
			if(!input_name)
			{
				printf("valid token \"<%s>\" but not recognise by Grammer.\n",Token);
				return;
			}
			input_symbol = getNoOfT(Term,input_name);
		}
		else
		{
			input_symbol = Term->count + 1;
		}
		j=0;
		while(1)
		{
			if(((table->ActionFunc)[cur_state-1] + input_symbol-1)->type == SHIFT)
			{
				printStack(PtrStack);
				printf("|\"%s\"\t",input_name);
				printf("| Shift \"%s\"\n",input_name);
				cur_state = ((table->ActionFunc)[cur_state-1] + input_symbol-1)->value;
				myPush(PtrStack, cur_state,input_name);
				if(! getNextToken(fp,Token))
				{
					input_name = identifyProgramTerminal(Token,sym_table,Term);
					if(!input_name)
					{
						printf("valid token \"<%s>\" but not recognise by Grammer.\n",Token);
						return;
					}
					input_symbol = getNoOfT(Term,input_name);					
				} 
				else
				{
					input_name = Token;
					input_symbol = Term->count + 1;
				}
			}
			else if(((table->ActionFunc)[cur_state-1] + input_symbol-1)->type == REDUCE)
			{
				prod = getProductionbyNo(NT, ((table->ActionFunc)[cur_state-1] + input_symbol-1)->value);
				printStack(PtrStack);
				printf("|\"%s\"\t",input_name);
				printf("| Reduce by Production No. %d\n",((table->ActionFunc)[cur_state-1] + input_symbol-1)->value);
				//printf("%d",prod->prod_length);
				for(i=0;i< prod->prod_length;i++)
				{
					//printf("lala");
					stEntry = myPop(PtrStack);
					//cur_state = stEntry->state;
					//printf("\"%s\" is Popped\n",stEntry->name);	
				}
				cur_state = getCurrentState(PtrStack);
				//printf("lala");
				//fflush(stdout);
				prod_head_no = getNoOfNT(NT,prod->head->name);
				//printf("%s %d",prod->head->name,prod_head_no);
				cur_state = ((table->GotoFunc)[cur_state-1] + prod_head_no -1)->next_state;
				//input_name = getNTbyNo(NT,);
				myPush(PtrStack, cur_state,prod->head->name);
				//printf("%d",cur_state);
			}
			else if(((table->ActionFunc)[cur_state-1] + input_symbol-1)->type == ACCEPT)
			{
				printStack(PtrStack);
				printf("|\"%s\"\t",input_name);
				printf("| Accept\n\n");
				break;
			}
			else
			{
				printf("Error Occured in Parsing Step... Stopping Parsing...\n");
				break;
			}
			j++;
		}

	fclose(fp);	
	free(PtrStack);
}
