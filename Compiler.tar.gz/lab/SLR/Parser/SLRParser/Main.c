#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include "lexical_analyser/lexical_analyser.h"
#include "file_names.h"
#include "slrparser.h"

void main(int argc,char* argv[])
{
	struct symbol_table *sym_table;
	
	char* GrammerName = argv[3];//GRAMMER_FILE_NAME;
	struct SetOfNonTerminals *NT = (struct SetOfNonTerminals *)calloc(1,sizeof(struct SetOfNonTerminals));
	struct SetOfNonTerminals *NTStart,*NTStartClosure,*NTnew,*NTGoto1,*NTGoto2,*NTGoto3,*NTGoto4;
	struct SetOfTerminals *T = (struct SetOfTerminals *)calloc(1,sizeof(struct SetOfTerminals));
	struct SetsOfNonTerminals * items; 
	struct ParsingTable * Table;
	scanGrammer(GrammerName,NT,T);
	//printGrammer(NT,T); 
	ExtendGrammer(NT);
	CreateFirst(NT);
	CreateFollow(NT);
	printGrammer(NT,T,1);
	items = Items(NT,T);
	printSetOfItems(items,T);
	
	Table = ConstructParsingTable(items,NT,T);
	printParsingTable(Table,items->count,T->count +1,NT->count - 1);
	
	if(! (Table->conflict))
	{
		sym_table = lexical_main(argv[1],argv[2]);
		if(sym_table)
		{
			if(sym_table->error)printf("Error occured in Program during Lexical Analysing.\n");
			else
			{
				Parsing(Table,sym_table,NT,T);	
			}
			destroySymbolTable(sym_table);
		}
		else
		printf ("Problem in Lexical Analysing\n");
	}
	//else {}
	
	
	////NTStart = StartSet(NT);
	//printGrammer(NTStart ,T,0);
	//NTStartClosure = Closure(NTStart);
	//printGrammer(NTStartClosure ,T,0);
	//NTnew = Clone(NT);
	//printGrammer(NTnew,T,0);
	//destroyGrammer(NTnew,T,0);
	//destroyGrammer(NTStart,T,0);
	//destroyGrammer(NTStartClosure,NULL,0);
	//NTStart = Clone(NT);
	//printGrammer(NTStart ,T,0);
	////NTStartClosure = Closure(NTStart);
	////printGrammer(NTStart ,T,0);
	////NTGoto1 = Goto(NTStartClosure,"if");
	////printGrammer(NTGoto1,T,0);
	////NTGoto2 = Goto(NTGoto1,"Expr");
	////printGrammer(NTGoto2,T,0);
	////NTGoto3 = Goto(NTGoto2,"then");
	////printGrammer(NTGoto3,T,0);
	////NTGoto4 = Goto(NTGoto3,"if");
	////printGrammer(NTGoto4,T,0);
	//Closure(NTGoto);
	//printGrammer(NTGoto,T,0);
	////destroyGrammer(NTGoto1,T,0);
	////destroyGrammer(NTGoto2,T,0);
	////destroyGrammer(NTGoto3,T,0);
	////destroyGrammer(NTGoto4,T,0);
	////destroyGrammer(NTStartClosure,NULL,0);
	
	destroyParsingTable(Table,items->count);
	
	destroySetOfItems(items);
	destroyGrammer(NT,T,1);
}
