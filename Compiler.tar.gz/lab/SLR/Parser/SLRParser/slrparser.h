
#define NonTerminalLength 20
#define TerminalLength 10
#define LineLength 80
#define max(a,b) (a>b?a:b)
#define NameLength max(NonTerminalLength,TerminalLength)
#define EPSILON "epsilon"
#define DOLLOR "dollar"
#define EXTENDED_START_SYMBOL "Z"

struct NonTerminal
{
	int production_count;
	struct NonTerminal_s_Productions *Productions;
	struct first *FirstSet;
	struct follow *FollowSet;
	struct NonTerminal *next;
	char ClosureMark;
	char* name;
};

struct SetOfNonTerminals
{
	struct NonTerminal *start,*tail;
	struct SetOfNonTerminals *next;
	int count;
	int production_count;
};

struct SetsOfNonTerminals
{
	struct SetOfNonTerminals *start;
	struct SetOfNonTerminals *last;
	int count;
};

struct Terminal
{
	struct Terminal *next;
	char* name;
};

struct SetOfTerminals
{
	struct Terminal *start,*tail;
	int count;
};

struct terminal_pointer_entry
{
	struct Terminal* self;
	struct terminal_pointer_entry *next;
};

struct first
{
	struct terminal_pointer_entry *start,*tail;
	int count,isepsilon;
};

struct follow
{
	struct terminal_pointer_entry *start,*tail;
	int count,isdollor;
};

struct ProductionNode
{
	union
	{ 
		struct NonTerminal *self_N;
		struct Terminal *self_T;
	};
	struct ProductionNode *next;
	enum {N,T} type;                               
};

struct ProductionTail
{
	struct ProductionNode *start,*cur,*last;
	struct NonTerminal *head;
	struct ProductionTail *nextProduction;
	int dotpos,prod_length;
};

struct NonTerminal_s_Productions
{
	struct ProductionTail *firstProduction;
	struct ProductionTail *tailProduction;
};

struct ActionEntry
{
	enum {ERROR, SHIFT, REDUCE, ACCEPT} type;
	int value;
};

struct GotoEntry
{
	int next_state;
};

struct ParsingTable
{
	struct ActionEntry **ActionFunc;
	struct GotoEntry **GotoFunc;
	int conflict;
};

#define STACK_SIZE 200

struct myStackEntry
{
	int state;
	char name[NameLength + 1];
};

struct myStack
{
	struct myStackEntry Content[STACK_SIZE];
	int curpos;
};

int tokenize(char* pt,char c,char* name,int length);
struct NonTerminal * searchNT(char* name,struct NonTerminal *startptrN);
struct NonTerminal * getPtrOfNT(char* name,struct SetOfNonTerminals * mainPtr,int inSet);
struct Terminal * searchT(char* name,struct Terminal *startptrT);
struct Terminal * getPtrOfT(char* name,struct SetOfTerminals * mainPtr);
void addProductions(struct NonTerminal* ptrN, char* pt,struct SetOfNonTerminals *SetPtrN,struct SetOfTerminals *SetPtrT);
void scanGrammer(char* filename,struct SetOfNonTerminals *mainPtrN,struct SetOfTerminals *mainPtrT);
void printGrammer(struct SetOfNonTerminals *SetPtrN,struct SetOfTerminals *SetPtrT,int detailed);
void destroyGrammer(struct SetOfNonTerminals *SetPtrN,struct SetOfTerminals *SetPtrT, int final);
void ExtendGrammer(struct SetOfNonTerminals * MainPtrN);
struct SetOfNonTerminals * StartSet(struct SetOfNonTerminals * MainPtrN);
struct SetOfNonTerminals * Clone (struct SetOfNonTerminals * SetPtrN);
void copyProduction(struct NonTerminal * ptDestination,struct NonTerminal * ptSource);
struct SetOfNonTerminals * Closure (struct SetOfNonTerminals * SetPtrN);
struct SetOfNonTerminals * Goto(struct SetOfNonTerminals * SetPtrN,char* name);
int IsCopyPresent(struct SetsOfNonTerminals * itemSet,struct SetOfNonTerminals * SetGoto);
struct SetsOfNonTerminals * Items(struct SetOfNonTerminals * mainPtrN,struct SetOfTerminals * mainPtrT);
void printSetOfItems(struct SetsOfNonTerminals * PtrSets,struct SetOfTerminals *PtrSetT);
void destroySetOfItems(struct SetsOfNonTerminals * PtrSets);
void CreateFollow(struct SetOfNonTerminals * mainPtrN);
void CreateFirst(struct SetOfNonTerminals * mainPtrN);
int getNoOfT(struct SetOfTerminals *T,char* name);
char* getTbyNo(struct SetOfTerminals *T,int n);
int getNoOfNT(struct SetOfNonTerminals *NT,char* name);
int getNoOfProduction(struct SetOfNonTerminals *NT,char* name,struct ProductionNode *start);
struct ProductionTail * getProductionbyNo(struct SetOfNonTerminals *NT,int n);
struct ParsingTable * ConstructParsingTable(struct SetsOfNonTerminals * items,struct SetOfNonTerminals *NT,struct SetOfTerminals *Term);
void printParsingTable(struct ParsingTable *table,int row,int column1,int column2);
void destroyParsingTable(struct ParsingTable *table,int row);
int getCurrentState(struct myStack *myStack1);
struct myStackEntry * myPop(struct myStack *myStack1);
int myPush(struct myStack *myStack1,int value,char* name);
void printStack(struct myStack *myStack1);
int StringtoNum(char* s);
void Capitalize(char *d,char* s);
char* identifyProgramTerminal(char *toFind,struct symbol_table *sym_table,struct SetOfTerminals *Term );
int getNextToken(FILE* fp,char* Token);
void Parsing(struct ParsingTable *table,struct symbol_table *sym_table,struct SetOfNonTerminals *NT,struct SetOfTerminals *Term);

