#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>

//create structures for creating automata
struct in_file_pos
{
	int pos[2];
	struct in_file_pos* next;
};

struct table_entry
{
	char token_name[32];
	char lexeme[256];
	int attr;
	struct in_file_pos *positions_head,*positions_last;
	struct table_entry* next; 
	struct table_entry* type_next;
};

struct symbol_table
{
	struct table_entry **categories,*start,*last;
	int count;
};

int max( int a, int b )
{
	return ( (a < b) ?  b : a );
}

struct config_file_entry
{
	char token_name[30];
	char spec[200];
};

struct automata_output
{
	char token_name[30];
	int index, lexeme_length;
};

int match_delim( char a, char** b, int n )
{
	int i;
	for( i=0; i<n; i++ )
	{
		if( b[i][0] == a) return 1;
	}
	return 0;
}

int match_char( char a, char** b, int n1, int n2 )
{
	//char start, finish;
	//printf("Input %c\n", a);
	int i, retval = 0;
	for( i=n1; i<n2; i++ )
	{
		//printf("In Match_char %s\n", b[i]);
		if( strlen(b[i]) == 1 )
		{
			//printf("YN1\n");
			if( a == b[i][0] ) { retval = 1; break; }
		}
		if( strlen(b[i]) == 3 )
		{
			//printf("YN3\n");
			if( (a>=b[i][0]) && (a<=b[i][2]) ) { retval = 1; break; }
		}
	}
	return retval;
}

int find_tab( char** a)
{
	int i=0;
	while( a[i][0] != '\t' ) i++;
	return i;
}

void append( char* a, char b)
{
	int i = strlen(a);
	a[i] = b;
	a[i+1] = 0;
}

char** space_separate( char* a, int n1, int n2, int* length )
{
	char buf[20];
	int i = 0, j=0, k;
	char** frag = (char**) malloc( sizeof(char*)*n1 );
	for( k=0; k < n1; k++ )
		frag[k] = (char*) malloc( sizeof(char)*n2 );
	
	for( k=0; k<20; k++ ) 
	{
		buf[k] = '\0';
	}
	while( *a != '\0')
	{
		if( *a != ' ')
		{
			buf[j++] = *a; 
		}
		else
		{
			strncpy( frag[i], buf, j+1 );
			i++; j=0;
			for( k=0; k<20; k++ ){ buf[k] = '\0';}
		}
		a++;
	}
	*length = i;
	return frag;
}

struct automata_output *match_lexeme( struct config_file_entry *cfe, char* lexeme_begin )
{
	struct automata_output *retval = NULL;
	char* forward = lexeme_begin, nextChar;	
	char* target = cfe->spec, **frag;
	int k, i, state, matched, length;
	if( strcmp(cfe->token_name, "ID") == 0 )
	{
		frag = space_separate( target, 20, 20, &i );
		state = 0; matched = 0; length = 0;
		int j = find_tab( frag ); //printf("tab pos %d\n", j);
		while( matched == 0 )
		{
			switch(state)
			{
				case 0:
					nextChar = *forward++;
					if( match_char( nextChar, frag, 0, j) )
					{
						state = 1; length++;
					}	
					else state = 3;
					break;
				
				case 1:
					nextChar = *forward++;
					if( match_char( nextChar, frag, j+1, i) )
					{
						state = 1; length++;
					}
					else state = 2;
					break;
					
				case 2:
					matched = 1; 
					break;
					
				case 3: 
					matched = -1;
					break;
			}
		}
		if( matched == 1)
		{
			retval = (struct automata_output*) malloc( sizeof(struct automata_output) );
			retval->lexeme_length = length;
			strcpy( retval->token_name, cfe->token_name );
		}
		/* garbage collection */
		for( k=0; k<20; k++ ) free(frag[k]);
		free(frag);
		return retval;
	}
	
	if( strcmp(cfe->token_name, "DELIM") == 0 )
	{
		frag = space_separate( target, 20, 20, &i );
		for( k=0; k<i; k++ )
		{
			//printf("%s", frag[k]);
			if( strcmp(frag[k], "tab") == 0 ) frag[k][0] = '\t';
			else if( strcmp(frag[k], "newline") == 0 ) frag[k][0] = '\n';
			else if( strcmp(frag[k], "space") == 0 ) frag[k][0] = ' ';
		}	
		//printf("a%ca%ca%ca\n", frag[0][0], frag[1][0], frag[2][0] );
		state = 0; matched = 0; length = 0;
		while( matched == 0 )
		{
			switch(state)
			{
				case 0:
					nextChar = *forward++; 
					if( match_delim( nextChar, frag, i) )
					{
						state = 1; length++;
					}
					else state = 3;
					break;
					
				case 1:
					nextChar = *forward++;
					if( match_delim( nextChar, frag, i) )
					{
						state = 1; length++;
					}
					else state = 2;
					break;
					
				case 2:
					matched = 1;
					break;	
				
				case 3: 
					matched = -1;
					break;
			}
		}
		if( matched == 1)
		{
			retval = (struct automata_output*) malloc( sizeof(struct automata_output) );
			retval->lexeme_length = length;
			strcpy( retval->token_name, cfe->token_name );
		}
		/* garbage collection */
		for( k=0; k<20; k++ ) free(frag[k]);
		free(frag);
		return retval;
	}
	
	if( strcmp(cfe->token_name, "NUM") == 0)
	{
		state = 0; matched =0; length = 0;
		//char nextChar;
		while( matched == 0 )
		{
			switch(state)
			{
				case 0: 
					nextChar = *forward++;		
					if( (nextChar >= 48) && (nextChar <= 57) )
					{
						state = 1; length++;
					}
					else state = 10;
					break;
					
				case 1:
					nextChar = *forward++;
					if( (nextChar >= 48) && (nextChar <= 57) )
					{
						state = 1; length++;
					}
					else if( nextChar == '.')
					{
						state = 2; length++;
					}
					else if( (nextChar == 'e') || (nextChar == 'E') )
					{
						state = 4; length++;
					}
					else state = 8;
					break;
					
				case 2:
					nextChar = *forward++;
					if( (nextChar >= 48) && (nextChar <= 57) )
					{
						state = 3; length++;
					}
					else state = 10;
					break;
					
				case 3:
					nextChar = *forward++;
					if( (nextChar >= 48) && (nextChar <= 57) )
					{
						state = 3; length++;
					}
					else if( (nextChar == 'e') || (nextChar == 'E') )
					{
						state = 4; length++;
					}
					else state = 9;
					break;
					
				case 4:
					nextChar = *forward++;
					if( (nextChar == '+') || (nextChar == '-') )
					{
						state = 5; length++;
					}
					else if( (nextChar >= 48) && (nextChar <= 57) )
					{
						state = 6; length++;
					}
					else state = 10;
					break;
					
				case 5: 
					nextChar = *forward++;
					if( (nextChar >= 48) && (nextChar <= 57) )
					{
						state = 6; length++;
					}
					else state = 10;
					break;
					
				case 6:
					nextChar = *forward++;
					if( (nextChar >= 48) && (nextChar <= 57) )
					{
						state = 6; length++;
					}
					else state = 7;
					break;
					
				case 7:
					matched = 1;
					break;
					
				case 8:
					matched = 1;
					break;
					
				case 9:
					matched = 1;
					break;
					
				case 10:
					matched = -1;
					break;
			}
		}
		if(matched == -1) return retval;
		retval = (struct automata_output*) malloc (sizeof(struct automata_output));
		retval->lexeme_length = length;
		strcpy( retval->token_name, cfe->token_name );
		return retval;
	}
	
	if( strcmp(cfe->token_name, "STRING") == 0)
	{
		//printf("Here\n");
		frag = space_separate( target, 20, 20, &i );
		//for(k=0; k<i; k++) printf("%d%s\n", k,frag[k]);
		state = 0; matched = 0; length = 0;
		while( matched == 0 )
		{
			switch(state)
			{
				case 0:
					nextChar = *forward++;
					if(nextChar == frag[0][0]) 
					{
						state = 1; length++;
					}
					else state = 3;
					break;
					
				case 1:
					nextChar = *forward++;
					if( match_char( nextChar, frag, 1, i) )
					{
						state = 1; length++;
					}
					else if(nextChar == frag[0][0])
					{
						state = 2; length++;
					}
					else state = 3;
					break;
					
				case 2:
					matched = 1;
					break;
					
				case 3:
					matched = -1;
					break;
			}
		}
		if( matched == 1)
		{
			retval = (struct automata_output*) malloc ( sizeof(struct automata_output));
			retval->lexeme_length = length;
			strcpy( retval->token_name, cfe->token_name );
		}
		/* garbage collection */
		for( k=0; k<20; k++ ) free(frag[k]);
		free(frag);	
		return retval;
	}
	
	if( strcmp(cfe->token_name, "CHAR") == 0)
	{
		frag = space_separate( target, 20, 20, &i );
		state = 0; matched = 0; length = 0;
		while( matched == 0 )
		{
			switch(state)
			{
				case 0:
					nextChar = *forward++;
					if(nextChar == frag[0][0]) 
					{
						state = 1; length++;
					}
					else state = 4;
					break;
					
				case 1:
					nextChar = *forward++;
					if( match_char( nextChar, frag, 1, i) )
					{
						state = 2; length++;
					}
					else state = 4;
					break;
					
				case 2:
					nextChar = *forward++;
					if( nextChar == frag[0][0] )
					{
						state = 3; length++;
					}
					else state = 4;
					break;
					
				case 3:
					matched = 1;
					break;
					
				case 4:
					matched = -1;
					break;
			}
		}
		if( matched == 1)
		{
			retval = (struct automata_output*) malloc ( sizeof(struct automata_output));
			retval->lexeme_length = length;
			strcpy( retval->token_name, cfe->token_name );
		}
		/* garbage collection */
		for( k=0; k<20; k++ ) free(frag[k]);
		free(frag);	
		return retval;
	}
	
	
	frag = space_separate( target, 20, 20, &i );

	length = 0;
	for( k=0; k<i; k++ )
	{
		if( strncmp( frag[k], lexeme_begin, strlen(frag[k]) ) == 0 )
			length = max( strlen(frag[k]), length );
	}
	
	/*garbage collection*/
	for( k=0; k<20; k++ ) free(frag[k]);
	free(frag);
	
	if( length > 0 )
	{
		retval = (struct automata_output*) malloc ( sizeof(struct automata_output));
		retval->lexeme_length = length;
		strcpy( retval->token_name, cfe->token_name );
	}
	return retval;
}

struct automata_output *get_token( char* lexeme_begin, struct config_file_entry *clist, int token_count)
{
	int i=0, j=0, max_len = 0;
	struct automata_output **alist = (struct automata_output**)malloc(sizeof(struct automata_output*)*token_count);
	for( i=0; i<token_count; i++ )
	{
		alist[i] = match_lexeme( clist + i, lexeme_begin);
		if(alist[i] != NULL)max_len = max( alist[i]->lexeme_length, max_len);
	}
	if( max_len == 0 )
	{
		for( i=0; i<token_count; i++ ) free(alist[i]);
		free(alist);
		return NULL;
	}
	int eligible[50];
	for( i=0; i<token_count; i++ )
	{
		if( alist[i] == NULL ) continue;
		if( ( (alist[i])->lexeme_length ) == max_len )
		{
			eligible[j] = i; j++;
		}
	}
	if(j > 1)
	{
		for( i=0; i<j; i++ )
		{
			if( strcmp( ((alist[eligible[i]])->token_name), "ID" ) != 0 )
			{
				break;
			}
		}
		j= eligible[i];	
	}
	else j = eligible[0];
	struct automata_output *retval = (struct automata_output*) malloc (sizeof(struct automata_output));
	strcpy( retval-> token_name, alist[j]-> token_name );
	(retval -> lexeme_length) = (alist[j] -> lexeme_length);
	retval -> index = j;
	/* garbage collection */
	for(i=0; i<token_count; i++) free(alist[i]);
	free(alist);
	return retval;	
}

struct config_file_entry *scan_config_file( char* config_file_name, int *t_c, int *p_c )
{
	char line[200];
	int token_count = 0;
	struct config_file_entry *token_names = (struct config_file_entry*)malloc(sizeof(struct config_file_entry)*50);
	FILE *config_file;
	if( (config_file = fopen(config_file_name,"r")) == NULL)
	{
		printf("Error opening config file. Exiting\n");
		return NULL;
	}
	while( fgets( line, 200, config_file) != NULL)
	{
		line[strlen(line) -1] = 0;
		if( line[0] == '#' ) 
		{
			strcpy( token_names[token_count++].token_name, line + 1);
			if(strcmp(token_names[token_count-1].token_name, "ID")==0) *p_c = token_count;
		}
		if( line[0] == '\t')
		{
			strcpy( token_names[token_count-1].spec, line + 1);
			append( token_names[token_count-1].spec, ' ' );
		}
				
	}
	*t_c = token_count;
	fclose(config_file);
	return token_names;
}

int main(int argc,char* argv[])
{
	int token_count, i,problem_index;
	//char config_filename = ""
	struct config_file_entry *token_names = scan_config_file( "config_file", &token_count,&problem_index);
	if( token_names == NULL ) return 1;
	/*for( i=0; i<token_count; i++ )
	{
		printf("Token %s Spec %s\n", token_names[i].token_name, token_names[i].spec);
	}*/
	//return 0;

	/*fp = fopen("lex_config","r");
	while(fp)
	{
		fgets(fp,buffer,100);
		// parse and create automata for each token
	}
	close(fp);*/
	
	prog_lex_analyse(token_names,token_count,problem_index,argv[1]);/**/

	free(token_names);
	return 0;	
	
}

int prog_lex_analyse(struct config_file_entry* cfe,int token_type_count,int problem_index,char filename[])
{
	//printf("checkpost : %d\n",token_type_count);	
	struct automata_output *token_info,*token_info_prev;
	int i,found,count,j=0;
	struct symbol_table table;
	struct table_entry *ptr;
	struct in_file_pos *pos_ptr;
	int error[100][2],error_count = 0,error_found=0;
	table.categories = (struct table_entry**)calloc(token_type_count,sizeof(struct table_entry*));
	table.start = NULL;
	table.last = NULL;
	table.count = 0;

	char buffer[200],*bufptr,*oldpos,temp[40];
	//int buflen;
	int line=1,column = 1, token_count = 0;

	FILE *fp,*fp_out,*ep;
	//fp = fopen(filename,"r");
	if( (fp = fopen(filename,"r")) == NULL)
	{
		printf("Error opening program file. Exiting\n");
		return 1;
	}
	fp_out = fopen("token_prog","w");
	ep = fopen("error_log","w");

	while( fgets( buffer, 200, fp) != NULL)
	{	
				//printf("checkpost : %d\n",j++);		
				bufptr = buffer;
				//printf("checkpostgettoken : %d\n",j++);	
				do{
					token_info = get_token(bufptr,cfe,token_type_count);
					
					if(token_info)
					{
						//printf("%s %d %d\n",token_info->token_name,token_info->index,token_info->lexeme_length);
						error_found = 0;
						found = 0;
						if(strcmp(token_info->token_name,"DELIM"))
						{
							i=0;
							while(i<(token_info->lexeme_length))
							{
								temp[i] = bufptr[i];
								i++;
							}temp[i] = '\0';
							//printf("checkpost1 : %d\n",j++);
							//printf("checkpost2 : %d\n",token_info->index);	
							if(table.categories[token_info->index])
							{//printf("checkpost2 : %d\n",j++);
								ptr = table.categories[token_info->index];
								if(!(strcmp(temp,ptr->lexeme))){found = 1;}
								else 
								{
									while(ptr->type_next)
									{
										if(!(strcmp(temp,(ptr->type_next)->lexeme)))
										{
											found = 1;
											ptr = ptr->type_next;
											break;
										}
										ptr = ptr->type_next;
									}
								}
								if(!found)
								{
									ptr->type_next = (struct table_entry*)calloc(1,sizeof(struct table_entry));
									ptr = ptr->type_next;
									(table.last)->next = ptr;
									table.last = ptr;
									//ptr->next = NULL;
									//ptr->type_next = NULL;
									strcpy(ptr->token_name,token_info->token_name);	
									strcpy(ptr->lexeme,temp);
									ptr->attr = ++(table.count);
									ptr -> positions_head = ptr -> positions_last = (struct in_file_pos*)calloc(1,sizeof(struct in_file_pos));		
								}
								else 
								{
									(ptr->positions_last)->next = (struct in_file_pos*)calloc(1,sizeof(struct in_file_pos));
									ptr->positions_last = (ptr->positions_last)->next;
								}
								ptr->positions_last->pos[0] = line;
								ptr->positions_last->pos[1] = column;
							}
							else
							{//printf("checkpost : %d\n",j++);	
								ptr = (struct table_entry*)calloc(1,sizeof(struct table_entry));
								if(table.count!=0)(table.last)->next = ptr;
								else table.start = ptr;
								table.last = ptr;
								strcpy(ptr->token_name,token_info->token_name);	
								strcpy(ptr->lexeme,temp);
								ptr -> positions_head = ptr -> positions_last = (struct in_file_pos*)calloc(1,sizeof(struct in_file_pos));		
								ptr->positions_last->pos[0] = line;
								ptr->positions_last->pos[1] = column;
								table.categories[token_info->index] = ptr;	
								ptr->attr = ++(table.count);
							}
				
							if(!error_count)fprintf(fp_out,"<%s,%d>",ptr->token_name,ptr->attr);
						}
						oldpos = bufptr;
						column += token_info->lexeme_length;
						bufptr += token_info->lexeme_length;
					}
					else 
					{
						//printf("checkposterror : %d\n",j++);	
						if(!error_found)
						{		
							i=0;
							while(i<10&&bufptr[i]!='\n')
							{
								temp[i] = bufptr[i];
								i++;
							}temp[i] = '\0';
				
							error[error_count][0] = line;
							error[error_count][1] = column;	
							error_count++;
							if(error_count == 1)fprintf(ep,"there was following possible errors during the lexical analysis\n");		
							fprintf(ep,"position %d,%d : error around here \"%s...\" \n",line,column,temp);
						}
						oldpos = bufptr;
						bufptr++;
						error_found++;
						if(error_found>=10){printf("bbye");fprintf(ep,"continously error coming so exiting");exit(0);}		
						continue;
					}/**/
					//printf("checkpost do while: %d\n",token_info->lexeme_length);	
				}while(token_info && (oldpos[(token_info->lexeme_length)-1] != '\n'));
				//printf("checkpost do while end: %d\n",j++);	
				line++;			
				column = 1;
	}
	fclose(fp);
	fclose(fp_out);
	fclose(ep);

	if(!error_count)
	{
		fp_out = fopen("symbol_table","w");
		ptr = table.start;
		while(ptr!=NULL)
		{
			count = sprintf(temp,"%d",ptr->attr);
			while((6-count++)>0)strcat(temp," ");
			fprintf(fp_out,"%s",temp);
			
			count = sprintf(temp,"%s",ptr->token_name);
			while((15-count++)>0)strcat(temp," ");
			fprintf(fp_out,"%s",temp);

			count = sprintf(temp,"%s",ptr->lexeme);
			while((20-count++)>0)strcat(temp," ");
			fprintf(fp_out,"%s",temp);

			pos_ptr = ptr ->positions_head;		
			while(pos_ptr)
			{
				fprintf(fp_out,"%d,%d ",pos_ptr->pos[0],pos_ptr->pos[1]);
				pos_ptr = pos_ptr->next;
			}
			fputc('\n',fp_out);
			ptr = ptr->next;
		}
		fclose(fp_out);
	}
	//printf("checkpost func end step 1: %d\n",j++);	
	ptr = table.start;
	while(ptr)
	{
		pos_ptr = ptr->positions_head;
		while(pos_ptr)
		{
			pos_ptr = pos_ptr -> next;
			free(ptr->positions_head);
			ptr->positions_head = pos_ptr;
		}
		ptr = ptr->next;
		free(table.start);
		table.start = ptr;	
	}
	free(table.categories);
	//printf("checkpost func end: %d\n",j++);	
	/*else
	{
		fp_out = fopen("error_log","w");
		i = 0;
		while(i<error_count)
		{		
			fprintf(fp_out,"")
	}*/

	return 0;
}
