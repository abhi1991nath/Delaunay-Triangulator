#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>

int max( int a, int b )
{
	return ( (a < b) ?  b : a );
}

struct config_file_entry
{
	char token_name[30];
	char spec[200];
};

struct automata_output
{
	char token_name[30];
	int index, lexeme_length;
};

int match_delim( char a, char** b, int n )
{
	int i;
	for( i=0; i<n; i++ )
	{
		if( b[i][0] == a) return 1;
	}
	return 0;
}

int match_char( char a, char** b, int n1, int n2 )
{
	//char start, finish;
	//printf("Input %c\n", a);
	int i, retval = 0;
	for( i=n1; i<n2; i++ )
	{
		//printf("In Match_char %s\n", b[i]);
		if( strlen(b[i]) == 1 )
		{
			//printf("YN1\n");
			if( a == b[i][0] ) { retval = 1; break; }
		}
		if( strlen(b[i]) == 3 )
		{
			//printf("YN3\n");
			if( (a>=b[i][0]) && (a<=b[i][2]) ) { retval = 1; break; }
		}
	}
	return retval;
}

int find_tab( char** a)
{
	int i=0;
	while( a[i][0] != '\t' ) i++;
	return i;
}

void append( char* a, char b)
{
	int i = strlen(a);
	a[i] = b;
	a[i+1] = 0;
}

char** space_separate( char* a, int n1, int n2, int* length )
{
	char buf[20];
	int i = 0, j=0, k;
	char** frag = (char**) malloc( sizeof(char*)*n1 );
	for( k=0; k < n1; k++ )
		frag[k] = (char*) malloc( sizeof(char)*n2 );
	
	for( k=0; k<20; k++ ) 
	{
		buf[k] = '\0';
	}
	while( *a != '\0')
	{
		if( *a != ' ')
		{
			buf[j++] = *a; 
		}
		else
		{
			strncpy( frag[i], buf, j+1 );
			i++; j=0;
			for( k=0; k<20; k++ ){ buf[k] = '\0';}
		}
		a++;
	}
	*length = i;
	return frag;
}

struct automata_output *match_lexeme( struct config_file_entry *cfe, char* lexeme_begin )
{
	struct automata_output *retval = NULL;
	char* forward = lexeme_begin, nextChar;	
	char* target = cfe->spec, **frag;
	int k, i, state, matched, length;
	if( strcmp(cfe->token_name, "ID") == 0 )
	{
		frag = space_separate( target, 20, 20, &i );
		state = 0; matched = 0; length = 0;
		int j = find_tab( frag ); //printf("tab pos %d\n", j);
		while( matched == 0 )
		{
			switch(state)
			{
				case 0:
					nextChar = *forward++;
					if( match_char( nextChar, frag, 0, j) )
					{
						state = 1; length++;
					}	
					else state = 3;
					break;
				
				case 1:
					nextChar = *forward++;
					if( match_char( nextChar, frag, j+1, i) )
					{
						state = 1; length++;
					}
					else state = 2;
					break;
					
				case 2:
					matched = 1; 
					break;
					
				case 3: 
					matched = -1;
					break;
			}
		}
		if( matched == 1)
		{
			retval = (struct automata_output*) malloc( sizeof(struct automata_output) );
			retval->lexeme_length = length;
			strcpy( retval->token_name, cfe->token_name );
		}
		/* garbage collection */
		for( k=0; k<20; k++ ) free(frag[k]);
		free(frag);
		return retval;
	}
	
	if( strcmp(cfe->token_name, "DELIM") == 0 )
	{
		frag = space_separate( target, 20, 20, &i );
		for( k=0; k<i; k++ )
		{
			//printf("%s", frag[k]);
			if( strcmp(frag[k], "tab") == 0 ) frag[k][0] = '\t';
			else if( strcmp(frag[k], "newline") == 0 ) frag[k][0] = '\n';
			else if( strcmp(frag[k], "space") == 0 ) frag[k][0] = ' ';
		}	
		//printf("a%ca%ca%ca\n", frag[0][0], frag[1][0], frag[2][0] );
		state = 0; matched = 0; length = 0;
		while( matched == 0 )
		{
			switch(state)
			{
				case 0:
					nextChar = *forward++; 
					if( match_delim( nextChar, frag, i) )
					{
						state = 1; length++;
					}
					else state = 3;
					break;
					
				case 1:
					nextChar = *forward++;
					if( match_delim( nextChar, frag, i) )
					{
						state = 1; length++;
					}
					else state = 2;
					break;
					
				case 2:
					matched = 1;
					break;	
				
				case 3: 
					matched = -1;
					break;
			}
		}
		if( matched == 1)
		{
			retval = (struct automata_output*) malloc( sizeof(struct automata_output) );
			retval->lexeme_length = length;
			strcpy( retval->token_name, cfe->token_name );
		}
		/* garbage collection */
		for( k=0; k<20; k++ ) free(frag[k]);
		free(frag);
		return retval;
	}
	
	if( strcmp(cfe->token_name, "NUM") == 0)
	{
		state = 0; matched =0; length = 0;
		//char nextChar;
		while( matched == 0 )
		{
			switch(state)
			{
				case 0: 
					nextChar = *forward++;		
					if( (nextChar >= 48) && (nextChar <= 57) )
					{
						state = 1; length++;
					}
					else state = 10;
					break;
					
				case 1:
					nextChar = *forward++;
					if( (nextChar >= 48) && (nextChar <= 57) )
					{
						state = 1; length++;
					}
					else if( nextChar == '.')
					{
						state = 2; length++;
					}
					else if( (nextChar == 'e') || (nextChar == 'E') )
					{
						state = 4; length++;
					}
					else state = 8;
					break;
					
				case 2:
					nextChar = *forward++;
					if( (nextChar >= 48) && (nextChar <= 57) )
					{
						state = 3; length++;
					}
					else state = 10;
					break;
					
				case 3:
					nextChar = *forward++;
					if( (nextChar >= 48) && (nextChar <= 57) )
					{
						state = 3; length++;
					}
					else if( (nextChar == 'e') || (nextChar == 'E') )
					{
						state = 4; length++;
					}
					else state = 9;
					break;
					
				case 4:
					nextChar = *forward++;
					if( (nextChar == '+') || (nextChar == '-') )
					{
						state = 5; length++;
					}
					else if( (nextChar >= 48) && (nextChar <= 57) )
					{
						state = 6; length++;
					}
					else state = 10;
					break;
					
				case 5: 
					nextChar = *forward++;
					if( (nextChar >= 48) && (nextChar <= 57) )
					{
						state = 6; length++;
					}
					else state = 10;
					break;
					
				case 6:
					nextChar = *forward++;
					if( (nextChar >= 48) && (nextChar <= 57) )
					{
						state = 6; length++;
					}
					else state = 7;
					break;
					
				case 7:
					matched = 1;
					break;
					
				case 8:
					matched = 1;
					break;
					
				case 9:
					matched = 1;
					break;
					
				case 10:
					matched = -1;
					break;
			}
		}
		if(matched == -1) return retval;
		retval = (struct automata_output*) malloc (sizeof(struct automata_output));
		retval->lexeme_length = length;
		strcpy( retval->token_name, cfe->token_name );
		return retval;
	}
	
	if( strcmp(cfe->token_name, "STRING") == 0)
	{
		//printf("Here\n");
		frag = space_separate( target, 20, 20, &i );
		//for(k=0; k<i; k++) printf("%d%s\n", k,frag[k]);
		state = 0; matched = 0; length = 0;
		while( matched == 0 )
		{
			switch(state)
			{
				case 0:
					nextChar = *forward++;
					if(nextChar == frag[0][0]) 
					{
						state = 1; length++;
					}
					else state = 3;
					break;
					
				case 1:
					nextChar = *forward++;
					if( match_char( nextChar, frag, 1, i) )
					{
						state = 1; length++;
					}
					else if(nextChar == frag[0][0])
					{
						state = 2; length++;
					}
					else state = 3;
					break;
					
				case 2:
					matched = 1;
					break;
					
				case 3:
					matched = -1;
					break;
			}
		}
		if( matched == 1)
		{
			retval = (struct automata_output*) malloc ( sizeof(struct automata_output));
			retval->lexeme_length = length;
			strcpy( retval->token_name, cfe->token_name );
		}
		/* garbage collection */
		for( k=0; k<20; k++ ) free(frag[k]);
		free(frag);	
		return retval;
	}
	
	if( strcmp(cfe->token_name, "CHAR") == 0)
	{
		frag = space_separate( target, 20, 20, &i );
		state = 0; matched = 0; length = 0;
		while( matched == 0 )
		{
			switch(state)
			{
				case 0:
					nextChar = *forward++;
					if(nextChar == frag[0][0]) 
					{
						state = 1; length++;
					}
					else state = 4;
					break;
					
				case 1:
					nextChar = *forward++;
					if( match_char( nextChar, frag, 1, i) )
					{
						state = 2; length++;
					}
					else state = 4;
					break;
					
				case 2:
					nextChar = *forward++;
					if( nextChar == frag[0][0] )
					{
						state = 3; length++;
					}
					else state = 4;
					break;
					
				case 3:
					matched = 1;
					break;
					
				case 4:
					matched = -1;
					break;
			}
		}
		if( matched == 1)
		{
			retval = (struct automata_output*) malloc ( sizeof(struct automata_output));
			retval->lexeme_length = length;
			strcpy( retval->token_name, cfe->token_name );
		}
		/* garbage collection */
		for( k=0; k<20; k++ ) free(frag[k]);
		free(frag);	
		return retval;
	}
	
	
	frag = space_separate( target, 20, 20, &i );

	length = 0;
	for( k=0; k<i; k++ )
	{
		if( strncmp( frag[k], lexeme_begin, strlen(frag[k]) ) == 0 )
			length = max( strlen(frag[k]), length );
	}
	
	/*garbage collection*/
	for( k=0; k<20; k++ ) free(frag[k]);
	free(frag);
	
	if( length > 0 )
	{
		retval = (struct automata_output*) malloc ( sizeof(struct automata_output));
		retval->lexeme_length = length;
		strcpy( retval->token_name, cfe->token_name );
	}
	return retval;
}

struct automata_output *get_token( char* lexeme_begin, struct config_file_entry *clist, int token_count)
{
	int i=0, j=0, max_len = 0;
	struct automata_output **alist = (struct automata_output**)malloc(sizeof(struct automata_output*)*token_count);
	for( i=0; i<token_count; i++ )
	{
		alist[i] = match_lexeme( clist + i, lexeme_begin);
		if(alist[i] != NULL)max_len = max( alist[i]->lexeme_length, max_len);
	}
	if( max_len == 0 )
	{
		for( i=0; i<token_count; i++ ) free(alist[i]);
		free(alist);
		return NULL;
	}
	int eligible[50];
	for( i=0; i<token_count; i++ )
	{
		if( alist[i] == NULL ) continue;
		if( ( (alist[i])->lexeme_length ) == max_len )
		{
			eligible[j] = i; j++;
		}
	}
	if(j > 1)
	{
		for( i=0; i<j; i++ )
		{
			if( strcmp( ((alist[eligible[i]])->token_name), "ID" ) != 0 )
			{
				break;
			}
		}
		j= eligible[i];	
	}
	else j = eligible[0];
	struct automata_output *retval = (struct automata_output*) malloc (sizeof(struct automata_output));
	strcpy( retval-> token_name, alist[j]-> token_name );
	(retval -> lexeme_length) = (alist[j] -> lexeme_length);
	retval -> index = j;
	/* garbage collection */
	for(i=0; i<token_count; i++) free(alist[i]);
	free(alist);
	return retval;	
}

struct config_file_entry *scan_config_file( char* config_file_name, int *t_c, int *p_c )
{
	char line[200];
	int token_count = 0;
	struct config_file_entry *token_names = (struct config_file_entry*)malloc(sizeof(struct config_file_entry)*50);
	FILE *config_file;
	if( (config_file = fopen(config_file_name,"r")) == NULL)
	{
		printf("Error opening config file. Exiting\n");
		return NULL;
	}
	while( fgets( line, 200, config_file) != NULL)
	{
		line[strlen(line) -1] = 0;
		if( line[0] == '#' ) 
		{
			strcpy( token_names[token_count++].token_name, line + 1);
			if(strcmp(token_names[token_count-1].token_name, "ID")==0) *p_c = token_count;
		}
		if( line[0] == '\t')
		{
			strcpy( token_names[token_count-1].spec, line + 1);
			append( token_names[token_count-1].spec, ' ' );
		}
				
	}
	*t_c = token_count;
	fclose(config_file);
	return token_names;
}

int main( int argc, char* argv[] )
{
	int token_count, i, problem_index;
	struct config_file_entry *token_names = scan_config_file( "config_file", &token_count, &problem_index);
	printf("problem_index %d\n", problem_index);
	if( token_names == NULL ) return 1;
	/*for( i=0; i<token_count; i++ )
	{
		printf("Token %s Spec %s\n", token_names[i].token_name, token_names[i].spec);
	}*/
	char* b, a[20];
	gets(a); //a[0] = '\n';
	//printf("a%sa", a);
	b = a;
	struct automata_output *c_token = get_token(b, token_names, token_count);
	if( c_token != NULL ) printf("%s %d %d", c_token->token_name, c_token->lexeme_length, c_token->index);
	return 0;
}
