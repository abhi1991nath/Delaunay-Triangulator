#include<stdio.h>
#include<string.h>
main()
{char q[10] = "\"ab\"" ;
/*q[0] = '"';
q[1]='a';
q[2]='b';
q[3]='"';
q[4]=0;*/

printf("      %s    \n",q);}
