#ifndef lint
static char yysccsid[] = "@(#)yaccpar	1.8 (Berkeley) 01/20/90";
#endif
#define YYBYACC 1
#line 9 "bas2.y"
    #include <stdio.h>
    #include<string.h>
    
    void yyerror(char *);
    void terror();
    int yylex(void);
    int sym[26];
    typedef struct
    {
	char *val;
    	char name[10];
    	/*char type[10];*/
    	int type;
    } node;
    typedef node * nodeptr;
    nodeptr head=NULL,current;
    int match=0;
    int chk=0,set=0,tp[100];
/*    FILE *fp1=fopen("output.txt","w");*/
    char *vr[]={"t1","t2","t3","t4","t5","t6","t7"};
    char *ct[]={"int","float","double","char"};
    int mod=0,q1,q2;
#line 29 "y.tab.c"
#define NUMBER 257
#define VARIABLE 258
#define WHILE 259
#define IF 260
#define PRINT 261
#define INT 262
#define FLOAT 263
#define DOUBLE 264
#define INTEGER 265
#define CHAR 266
#define GE 267
#define LE 268
#define EQ 269
#define NE 270
#define IFX 271
#define ELSE 272
#define YYERRCODE 256
short yylhs[] = {                                        -1,
    0,    0,    1,    1,    1,    3,    3,    5,    5,    4,
    4,    4,    4,    2,    2,    2,    2,    2,    2,
};
short yylen[] = {                                         2,
    3,    0,    1,    3,    1,    2,    0,    1,    0,    1,
    1,    1,    1,    1,    1,    3,    3,    3,    3,
};
short yydefred[] = {                                      2,
    0,   14,    0,   10,   11,   12,   13,    0,    0,    5,
    0,    0,    1,    0,    0,    0,    0,    8,    6,   15,
    0,    0,    0,   18,   19,
};
short yydgoto[] = {                                       1,
    8,    9,   10,   11,   19,
};
short yysindex[] = {                                      0,
 -255,    0,  -57,    0,    0,    0,    0,   -4,  -26,    0,
 -238, -233,    0, -233, -233, -233, -233,    0,    0,    0,
  -26,  -24,  -24,    0,    0,
};
short yyrindex[] = {                                      0,
   12,    0,  -10,    0,    0,    0,    0,    0,   16,    0,
   17,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   18,   -9,   -5,    0,    0,
};
short yygindex[] = {                                      0,
    0,   -2,    0,    0,    0,
};
#define YYTABLESIZE 40
short yytable[] = {                                      15,
   16,    2,    3,   12,   17,   13,    4,    5,    6,   21,
    7,   22,   23,   24,   25,   16,   14,   16,   15,   18,
   17,    7,   17,    2,   20,    3,    9,    4,    0,    0,
    0,   15,   15,   16,   15,   16,   15,   17,    0,   17,
};
short yycheck[] = {                                      10,
   10,  257,  258,   61,   10,   10,  262,  263,  264,   12,
  266,   14,   15,   16,   17,   42,   43,   42,   45,  258,
   47,   10,   47,  257,  258,   10,   10,   10,   -1,   -1,
   -1,   42,   43,   43,   45,   45,   47,   43,   -1,   45,
};
#define YYFINAL 1
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 272
#if YYDEBUG
char *yyname[] = {
"end-of-file",0,0,0,0,0,0,0,0,0,"'\\n'",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,"'*'","'+'",0,"'-'",0,"'/'",0,0,0,0,0,0,0,0,0,0,0,0,"'<'",
"'='","'>'",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
"NUMBER","VARIABLE","WHILE","IF","PRINT","INT","FLOAT","DOUBLE","INTEGER",
"CHAR","GE","LE","EQ","NE","IFX","ELSE",
};
char *yyrule[] = {
"$accept : program",
"program : program statement '\\n'",
"program :",
"statement : expr",
"statement : VARIABLE '=' expr",
"statement : decstmt",
"decstmt : type var",
"decstmt :",
"var : VARIABLE",
"var :",
"type : INT",
"type : FLOAT",
"type : DOUBLE",
"type : CHAR",
"expr : NUMBER",
"expr : VARIABLE",
"expr : expr '+' expr",
"expr : expr '-' expr",
"expr : expr '*' expr",
"expr : expr '/' expr",
};
#endif
#ifndef YYSTYPE
typedef int YYSTYPE;
#endif
#define yyclearin (yychar=(-1))
#define yyerrok (yyerrflag=0)
#ifdef YYSTACKSIZE
#ifndef YYMAXDEPTH
#define YYMAXDEPTH YYSTACKSIZE
#endif
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 500
#define YYMAXDEPTH 500
#endif
#endif
int yydebug;
int yynerrs;
int yyerrflag;
int yychar;
short *yyssp;
YYSTYPE *yyvsp;
YYSTYPE yyval;
YYSTYPE yylval;
short yyss[YYSTACKSIZE];
YYSTYPE yyvs[YYSTACKSIZE];
#define yystacksize YYSTACKSIZE
#line 85 "bas2.y"

void yyerror(char *s) {
   printf("%s\n", s);
   yyparse();
}

void terror()
{
printf("\n type error");

}

int main(void) {
    yyparse();
    //fclose(fp1);
    return 0;
}

#line 176 "y.tab.c"
#define YYABORT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR goto yyerrlab
int
yyparse()
{
    register int yym, yyn, yystate;
#if YYDEBUG
    register char *yys;
    extern char *getenv();

    if (yys = getenv("YYDEBUG"))
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = (-1);

    yyssp = yyss;
    yyvsp = yyvs;
    *yyssp = yystate = 0;

yyloop:
    if (yyn = yydefred[yystate]) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("yydebug: state %d, reading %d (%s)\n", yystate,
                    yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("yydebug: state %d, shifting to state %d (%s)\n",
                    yystate, yytable[yyn],yyrule[yyn]);
#endif
        if (yyssp >= yyss + yystacksize - 1)
        {
            goto yyoverflow;
        }
        *++yyssp = yystate = yytable[yyn];
        *++yyvsp = yylval;
        yychar = (-1);
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;
#ifdef lint
    goto yynewerror;
#endif
yynewerror:
    yyerror("syntax error");
#ifdef lint
    goto yyerrlab;
#endif
yyerrlab:
    ++yynerrs;
yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yyssp]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("yydebug: state %d, error recovery shifting\
 to state %d\n", *yyssp, yytable[yyn]);
#endif
                if (yyssp >= yyss + yystacksize - 1)
                {
                    goto yyoverflow;
                }
                *++yyssp = yystate = yytable[yyn];
                *++yyvsp = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("yydebug: error recovery discarding state %d\n",
                            *yyssp);
#endif
                if (yyssp <= yyss) goto yyabort;
                --yyssp;
                --yyvsp;
            }
        }
    }
    else
    {
        if (yychar == 0) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("yydebug: state %d, error recovery discards token %d (%s)\n",
                    yystate, yychar, yys);
        }
#endif
        yychar = (-1);
        goto yyloop;
    }
yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("yydebug: state %d, reducing by rule %d (%s)\n",
                yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    yyval = yyvsp[1-yym];
    switch (yyn)
    {
case 3:
#line 41 "bas2.y"
{ printf("%d\n", yyvsp[0]); }
break;
case 4:
#line 42 "bas2.y"
{ sym[yyvsp[-2]] = yyvsp[0];
							if(set!=0)
							{ if(chk!=tp[yyvsp[-2]]) terror();

							else {printf("\n%c=t%d",97+yyvsp[-2],set-1); set=0;chk=0;}
							}
							else
							printf("\n%c=%d",97+yyvsp[-2],yyvsp[0]);
							
        						}
break;
case 5:
#line 52 "bas2.y"
{
							 
						        }
break;
case 6:
#line 58 "bas2.y"
{tp[yyvsp[0]]=yyvsp[-1];}
break;
case 8:
#line 63 "bas2.y"
{printf("%c \n",97+yyvsp[0]);}
break;
case 10:
#line 67 "bas2.y"
{printf("int ");}
break;
case 11:
#line 68 "bas2.y"
{printf("float ");}
break;
case 12:
#line 69 "bas2.y"
{printf("double ");}
break;
case 13:
#line 70 "bas2.y"
{printf("char ");}
break;
case 14:
#line 73 "bas2.y"
{ }
break;
case 15:
#line 74 "bas2.y"
{ yyval = sym[yyvsp[0]]; if(mod==0) {q1=yyvsp[0];mod++;} else{q2=yyvsp[0];mod--;}               if((tp[yyvsp[0]]==1)||(chk==1)) chk=1; else chk=0;}
break;
case 16:
#line 75 "bas2.y"
{ 
        				 if(set==0)printf("\n%s t%d=%c+%c",ct[chk],set,97+q1,97+q2);
					else{ if(mod==0){printf("\n%s t%d=t%d+%c",ct[chk],set,set-1,97+q2);mod++;}if(mod==1){printf("\n%s t%d=t%d+%c",ct[chk],set,set-1,97+q1);mod--;}}
					set++;
					yyval = yyvsp[-2] + yyvsp[0];
        			  }
break;
case 17:
#line 81 "bas2.y"
{ yyval = yyvsp[-2] - yyvsp[0]; }
break;
case 18:
#line 82 "bas2.y"
{ yyval = yyvsp[-2] * yyvsp[0]; }
break;
case 19:
#line 83 "bas2.y"
{ yyval = yyvsp[-2] / yyvsp[0]; }
break;
#line 392 "y.tab.c"
    }
    yyssp -= yym;
    yystate = *yyssp;
    yyvsp -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("yydebug: after reduction, shifting from state 0 to\
 state %d\n", YYFINAL);
#endif
        yystate = YYFINAL;
        *++yyssp = YYFINAL;
        *++yyvsp = yyval;
        if (yychar < 0)
        {
            if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
            if (yydebug)
            {
                yys = 0;
                if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
                if (!yys) yys = "illegal-symbol";
                printf("yydebug: state %d, reading %d (%s)\n",
                        YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == 0) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("yydebug: after reduction, shifting from state %d \
to state %d\n", *yyssp, yystate);
#endif
    if (yyssp >= yyss + yystacksize - 1)
    {
        goto yyoverflow;
    }
    *++yyssp = yystate;
    *++yyvsp = yyval;
    goto yyloop;
yyoverflow:
    yyerror("yacc stack overflow");
yyabort:
    return (1);
yyaccept:
    return (0);
}
