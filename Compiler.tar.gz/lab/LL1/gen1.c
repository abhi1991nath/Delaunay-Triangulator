//******************************************
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>

void dtob(int num, char *b)
{
   short i;
   //char b[12];

   //short num = 128;

    for( i = 99; i >= 0; i--)        
   {
        if( (1 << i) & num)
           b[99 - i] = '1';
        else
           b[99 - i] = '0';                   
   }
   
   b[100] = 0; // ascii terminating character
  
  //printf("\n %d  %x  %s\n", num, num, b); // decimal, hex, binary formats
   
  	
  //return 0;
}

//***********************************************

void gen(char * st)
{
int i,k=0,j,p=0;
char bin[100],temp[1000];
//char *pro[pow(2,strlen(st))];
char *pro[1000];
char *tmp;

for(i=1;i<pow(2,strlen(st));i++)
{
	dtob(i,bin);
	for(j=0;j<strlen(st);j++)
		{
			if(isupper(st[j]))
				{
				if(bin[99-j]=='1')
					temp[k++]=st[j];
				}
			else
				temp[k++]=st[j];

		}
	temp[k]='\0';
	k=0;
	tmp=(char *)malloc(strlen(temp)*sizeof(char));
	strcpy(tmp,temp);
	while(k<p&&(strcmp(pro[k],tmp)!=0)) k++;
	
	if(k>=p)
	{
		pro[p]=tmp;
		printf("*%s\n",pro[p++]);
	}
	k=0;
}
}

int main()
{

char s[]="AbgdsbhWHjhlw";
gen(s);
return 0;
}



void permuteAndAddBody( grammar* cfg, int i, char* a, int pos, int* result )
{
	char temp1[2]; temp1[1] = 0; temp1[0] = a[pos]; 
	if( pos == strlen(a) ) return;
	if( pos == strlen(a)-1 )
	{
		addBody( cfg, i, a );
		if(isNonTerminal(cfg, temp1, 0, cfg->headCount-1))
		{
			if(isNullable(cfg, result, temp1))
			{
				a[pos] = 0;
				addBody( cfg, i, a);
			}
		}
		return;
	}
	permuteAndAddBody( cfg, i, a, pos+1, result );
	if(isNonTerminal(cfg, temp1, 0, cfg->headCount-1))
	{
		if(isNullable(cfg, result, temp1))
		{
			char temp[100];
			strncpy( temp, a, pos );
			strcat( temp, a+pos+1 );
			permuteAndAddBody( cfg, i, temp, pos, result );
		}
	}
}


void removeEpsilonProductions( grammar *cfg, int* result )
{
	//int* result = (int*)malloc(sizeof(int)*(cfg->headCount));
	getNullableNonTerminals( cfg, result );
	if( sum( result, cfg->headCount ) == 0 ) return;
	int i,j, count, count2;
	for( i=0; i<cfg->headCount; i++ )
	{
		count = 0;
		count2 = cfg->productions[i]->bodyCount;
		for( j=0; j<count2; j++ )
		{
			if( hasOnlyNonTerminals( cfg, cfg->productions[i]->body[j]))
			{
				if( isNullable( cfg, result, cfg->productions[i]->body[j]))
					count++;
			}
			permuteAndAddBody( cfg, i, cfg->productions[i]->body[j], 0, result );
			cfg->productions[i]->body[j][0] = 0;
		}
		reposition( cfg->productions[i]->body, cfg->productions[i]->bodyCount, count2 + count );
		cfg->productions[i]->bodyCount -= count2 + count;
	}
}

