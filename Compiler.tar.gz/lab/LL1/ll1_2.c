#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<ctype.h>
#include "lexical_analyser/lexical_analyser.c"

struct stackElem
{
	char str[20];
	struct stackElem *next;
};

struct stack
{
	struct stackElem *bottom, *top;
};

void push( struct stack* Stack, char* temp )
{
	struct stackElem *elem = Stack->bottom;
	if( !elem )
	{
		Stack->bottom = (struct stackElem*)malloc(sizeof(struct stackElem));
		Stack->bottom->next = NULL;
		strcpy( Stack->bottom->str, temp);
		Stack->top = Stack->bottom;
		return;
	}
	while( elem->next )
	{
		elem = elem->next;
	}
	elem->next = (struct stackElem*)malloc(sizeof(struct stackElem));
	strcpy( elem->next->str, temp );
	elem->next->next = NULL;
	Stack->top =  elem->next;
}

void pop( struct stack* Stack )
{
	struct stackElem *temp1 = Stack -> bottom, *temp2;
	if( !temp1 ) 
	{
		printf("Error : Trying to pop from empty stack\n");
		return;
	}
	temp2 = temp1;
	while( temp1->next )
	{
		temp2 = temp1;
		temp1 = temp1->next;
	}
	if( temp2 == temp1 )
	{
		free(temp1); Stack->bottom = NULL; Stack->top = NULL;
	}
	else
	{
		temp2 -> next = NULL; Stack->top = temp2;
		free(temp1);
	}
}

void printStack( struct stack* Stack )
{
	struct stackElem* elem = Stack->bottom;
	while( elem )
	{
		printf("%s ", elem->str);
		elem = elem->next;
	}
}

typedef struct
{
	char *head, **body;
	int bodyCount;
} production;

typedef struct
{
	char* startSymbol;
	int headCount;
	production* productions[30];
} grammar;

void toLower ( char* str )
{
	char* a = str;
	while(*a)
	{
		*a = tolower(*a); a++;
	}
}

void toUpper ( char* str )
{
	char* a = str;
	while(*a)
	{
		*a = toupper(*a); a++;
	}
}

int stringToInt ( char* temp )
{
	int n = 0; char* a = temp;
	while(*a)
	{
		n += (*a++ -48 );
		n *=10;
	}
	return n/10;
}

void printGrammar( grammar* cfg2 )
{
	int i,j;
	for( i = 0; i<cfg2->headCount; i++ )
	{
		printf( "%s -> ", cfg2->productions[i]->head );
		for( j = 0; j<cfg2->productions[i]->bodyCount; j++ )
		{
			printf("%s |", cfg2->productions[i]->body[j]);
		}
		printf("\n");
	}
}

int scanConfigFile ( char* fileName, grammar* cfg )
{
	FILE* fp;
	if(!(fp = fopen(fileName, "r"))) return 1;
	char line[200], line2[200], *wrapper, *temp; 
	int count = 0, bodyCount, i;
	while( fgets( line, 200, fp ) )
	{
		line[strlen(line)-1] = 0;
		strcpy( line2, line );
		bodyCount = 0;
		wrapper = line;
		if( !(temp = strtok( wrapper, " \t|" )) ) continue;
		if( count == 0 )
		{
			cfg->startSymbol = (char*)malloc(sizeof(char)*(strlen(temp) + 1));
			strcpy( cfg->startSymbol, temp );
		}
		do
		{
			bodyCount++;
		} while( strtok( NULL, " \t|" ) );
		--bodyCount;
		cfg->productions[count] = (production*)malloc(sizeof(production));
		wrapper = line2;
		temp = strtok( wrapper, " \t|" );
		cfg->productions[count]->head = (char*)malloc(sizeof(char)*(strlen(temp) + 1));
		strcpy(cfg->productions[count]->head, temp);
		cfg->productions[count]->body = (char**)malloc(sizeof(char*)*100);
		cfg->productions[count]->bodyCount = bodyCount;
		i=0;
		while( temp = strtok( NULL, " \t|" ) )
		{
			cfg->productions[count]->body[i] = (char*)malloc(sizeof(char)*(strlen(temp) + 1));
			strcpy( cfg->productions[count]->body[i], temp );
			i++;
		}
		count++;
	}
	fclose(fp);
	cfg->headCount = count;
	return 0;
}

int isNonTerminal( grammar* cfg, char* testString, int i, int j )
{
	if( (i>=cfg->headCount) || (j>=cfg->headCount) || (i<0) || (j<0) )
		return -1;
	int k;
	for( k=i; k<=j; k++ )
	{
		if(strcmp(testString, cfg->productions[k]->head)==0) return 1;
	}
	return 0;
}

int getNonTerminalIndex( grammar *cfg, char* testString )
{
	int i;
	for( i=0; i<cfg->headCount; i++ )
	{
		if( strcmp( cfg->productions[i]->head, testString ) == 0 )
			return i;
	}
}

int sum2D( int** a, int n1, int n2 )
{
	int i, j, sum=0;
	for( i=0; i<n1; i++ )
		for( j=0; j<n2; j++ )
			sum+=a[i][j];
	return sum;
}

int sum( int* a, int n )
{
	int i, sum=0;
	for(i=0;i<n;i++)
		sum += a[i];
	return sum;
}

int hasOnlyNonTerminals( grammar* cfg, char* testString )
{
	char temp[2]; temp[1] = 0;
	int i;
	for( i=0; i<strlen(testString); i++ )
	{
		temp[0] = testString[i];
		if( !isNonTerminal(cfg, temp, 0, cfg->headCount -1) )
			return 0;
	}
	return 1;
}

int isPresent( char** temp, int i )
{
	if( strlen(temp[i]) == 0 ) return 1;
	int k;
	for( k=0; k<i; k++ )
	{
		if( strcmp(temp[k],temp[i])==0 )
			return 1;
	}
	return 0;
}

void writeGrammarToFile( grammar* cfg, char* fileName )
{
	FILE* fp = fopen( fileName, "w" );
	int i, j;
	for( i=0; i<cfg->headCount; i++ )
	{
		fprintf( fp, "%s\t", cfg->productions[i]->head );
		for( j=0; j<cfg->productions[i]->bodyCount; j++ )
		{
			fprintf( fp, " %s | ", cfg->productions[i]->body[j] );
		}
		fprintf(fp, "\n");
	}
	fclose(fp);
}

char* extractWord( char* target, char d1, char d2, int* len )
{
	char* temp1, *temp2; int n;
	temp1 = strchr( target, d1 );
	if(!temp1) 
	{
		*len = 0;	return NULL;
	}
	temp2 = strchr( target, d2 );
	n = (temp2-temp1-1);
	//printf("n=%d",n);
	if( n>=1 )
	{
		*len = n;
		//return temp2+1;
	}
	if( n== 0 )
	{
		if( *(temp2+1) != d2 )
		{
			*len = 2;
			//return temp2 + 3;
		}
		else if( *(temp2+2) == d2 )
		{
			*len = 2;
			//return temp2 + 3;
		}
		else *len = 1;
		//return temp2 + 2;
	}
	return temp1+1;
}

int exists( char** a, char* b, int n )
{
	int i;
	for( i=0; i<n; i++ )
		if( strcmp(b,a[i])== 0 ) return 1;
	return 0;
}

int extractTerminals( grammar* cfg, char** terminals )
{
	int count=0, i,j, len; 
	char *temp, *temp1, temp2[100];
	for( i=0; i<cfg->headCount; i++ )
	{
		for( j=0; j<cfg->productions[i]->bodyCount; j++ )
		{
			temp = cfg->productions[i]->body[j];
			while( temp1 = extractWord( temp, '<', '>', &len ) )
			{
				strncpy( temp2, temp1, len );
				temp2[len] = 0;
				if(!exists(terminals, temp2, count))
				{
					terminals[count] = (char*)malloc(sizeof(char)*(len+1));
					strcpy( terminals[count], temp2 );
					count++;
				}
				temp = temp1+len+1;
			}
		}
	}
	return count;
}

int getSymbolIndex( char* test, char** terminals, char** nonTerminals, int terminalCount, int nonTerminalCount )
{
	if( strcmp(test, "#")==0 ) return terminalCount + nonTerminalCount;
	int i;
	for( i=0; i<nonTerminalCount; i++ )
	{
		if( strcmp( test, nonTerminals[i] ) == 0)
			return i;
	}
	for( i=0; i<terminalCount; i++ )
	{
		if( strcmp( test, terminals[i]) == 0 )
			return nonTerminalCount + i;
	}
	return -1;
}

int matchNonTerminal ( char* test, char** nonTerminals, int nonTerminalCount )
{
	int len = 0, i, retval;
	for( i=0; i<nonTerminalCount; i++ )
	{
		if( strncmp(test, nonTerminals[i], strlen(nonTerminals[i])) == 0 )
		{
			if( strlen(nonTerminals[i]) > len )
			{
				retval = i; len = strlen(nonTerminals[i]);
			}
		}
	}
	return retval;
}

int getSymbols( char* test, char** terminals, char** nonTerminals, int terminalCount, int nonTerminalCount, int* symbolList )
{
	int k, len, i=0, j;
	char* temp1 = test, temp[20];
	while(*temp1)
	{
		//printf("test = %s ", temp1);
		if(*temp1 == '<')
		{
			temp1 = extractWord( temp1, '<', '>', &len);
			//printf("len = %d", len);
			strncpy( temp, temp1, len ); temp[len] = 0;
			//printf("here dkfjdk\n");
			symbolList[i++] = getSymbolIndex( temp, terminals, nonTerminals, terminalCount, nonTerminalCount );
			temp1 = temp1 + len + 1;
		}
		else if(*temp1 == '#')
		{
			symbolList[i++] = terminalCount+nonTerminalCount;
			temp1++;
		}
		else
		{
			len = 0;
			k = matchNonTerminal(temp1, nonTerminals, nonTerminalCount);	
			//printf("here %s\n", nonTerminals[k]); 
			temp1 += strlen( nonTerminals[k] );
			symbolList[i++] = k;
			//printf("there %s\n", temp1);
		}
	}
	return i;
}

void fillBodySymbolInformation( grammar* cfg, char** terminals, char** nonTerminals, int terminalCount,
								int nonTerminalCount, int**** bodySymbolList, int*** bodySymbolCount )
{
	*bodySymbolList = (int***)malloc(sizeof(int**)*(cfg->headCount));
	*bodySymbolCount = (int**)malloc(sizeof(int*)*(cfg->headCount));
	int i, j, len, k;
	for( i=0; i<cfg->headCount; i++ )
	{
		(*bodySymbolList)[i] = (int**)malloc(sizeof(int*)*(cfg->productions[i]->bodyCount));
		(*bodySymbolCount)[i] = (int*)malloc(sizeof(int)*(cfg->productions[i]->bodyCount));
		for( j=0; j<cfg->productions[i]->bodyCount; j++ )
		{
			(*bodySymbolList)[i][j] = (int*)malloc(sizeof(int)*30);
			(*bodySymbolCount)[i][j] = getSymbols( cfg->productions[i]->body[j], terminals, nonTerminals,
						terminalCount, nonTerminalCount, (*bodySymbolList)[i][j] );
		}
	}
}

void addFirst( int to, int from, int** first, int terminalCount )
{
	int i;
	for( i=0; i< terminalCount + 1; i++ )
	{
		if( first[from][i] )
			first[to][i] = 1;
	}
}

void addFollow( int to, int from, int** follow, int terminalCount )
{
	addFirst( to, from, follow, terminalCount );
}

void addFirstToFollow( int to, int* temp, int** follow, int terminalCount)
{
	int i;
	for( i=0; i<terminalCount; i++ )
	{
		if( temp[i] )
			follow[to][i] = 1;
		//printf( "hdg %d ", follow[to][i] );
	}
}

void calcFirst( int* symbolList, int* temp, int begin, int end, int** first, 
				int terminalCount, int nonTerminalCount )
{
	int i,j;
	for( i=0; i<terminalCount+1; i++ )
		temp[i] = 0;
	for( i=begin; i<end; i++ )
	{
		if( symbolList[i] < nonTerminalCount )
		{
			for( j=0; j<terminalCount+1; j++ )
			{
				if( first[symbolList[i]][j] )
					temp[j] = 1;
			}
			if( first[symbolList[i]][terminalCount] == 0 )
				break;
		}
		else
		{
			temp[symbolList[i]-nonTerminalCount] = 1;
			break;
		}
	}
}

void calculateFirst( grammar* cfg, int** first, int*** bodySymbolList, int** bodySymbolCount,
					 int terminalCount, int nonTerminalCount )
{
	int count_old, count_new,i,j,k;
	count_new = 0;//sum2D( first, nonTerminalCount, nonTerminalCount + terminalCount + 1 );
	again: count_old = count_new;
	for( i=0; i<cfg->headCount; i++ )
	{
		for( j=0; j<cfg->productions[i]->bodyCount; j++ )
		{
			for( k=0; k<bodySymbolCount[i][j]; k++ )
			{
				if( bodySymbolList[i][j][k] >= nonTerminalCount )
				{
					first[i][bodySymbolList[i][j][k] - nonTerminalCount] = 1; break;
				}
				else
				{
					addFirst( i, bodySymbolList[i][j][k], first, terminalCount);
					if( first [bodySymbolList[i][j][k]] [terminalCount] == 0 )
						break;
				}
			}
		}
	}
	count_new = sum2D( first, nonTerminalCount, terminalCount + 1 );
	if( count_new > count_old ) goto again;
}

void calculateFollow( grammar* cfg, int** follow, int** first, int*** bodySymbolList, int** bodySymbolCount,
					 int terminalCount, int nonTerminalCount, char** terminals, char** nonTerminals )
{
	int startSymbolIndex =  getSymbolIndex( cfg->startSymbol, terminals, nonTerminals, terminalCount, nonTerminalCount );
	//printf("start = %d", startSymbolIndex);
	follow[startSymbolIndex][terminalCount] = 1;
	int count_old, count_new=0, i,j,k;
	int* temp = (int*)malloc(sizeof(int)*(terminalCount + 1));
	again1: count_old = count_new;
	for( i=0; i<cfg->headCount; i++ )
	{
		for( j=0; j<cfg->productions[i]->bodyCount; j++ )
		{
			for( k=0; k<bodySymbolCount[i][j]; k++ )
			{
				if( k==bodySymbolCount[i][j]-1 )
				{
					if( bodySymbolList[i][j][k] < nonTerminalCount )
					{
						addFollow( bodySymbolList[i][j][k], i, follow, terminalCount );
					}
				}
				else
				{
					if( bodySymbolList[i][j][k] < nonTerminalCount )
					{
						calcFirst( bodySymbolList[i][j], temp, k+1, bodySymbolCount[i][j], 
									first, terminalCount, nonTerminalCount );
						addFirstToFollow( bodySymbolList[i][j][k], temp, follow, terminalCount);
						if( temp[terminalCount] )
							addFollow( bodySymbolList[i][j][k], i, follow, terminalCount );
					}
				}
			}
		}
	}
	count_new = sum2D( first, nonTerminalCount, terminalCount + 1 );
	if( count_new > count_old ) goto again1;
	free(temp);
}

void fillParsingTable( grammar* cfg, int** parsingTable, int** first, int** follow, char** terminals, char** nonTerminals,
		int terminalCount, int nonTerminalCount, int*** bodySymbolList, int** bodySymbolCount )
{
	int i,j,k;
	for( i=0; i<nonTerminalCount; i++ )
		for( j=0; j<terminalCount+1; j++ )
			parsingTable[i][j] = -1;
	int* temp = (int*)malloc(sizeof(int)*(terminalCount+1));
	for( i=0; i<cfg->headCount; i++ )
	{
		for( j=0; j<cfg->productions[i]->bodyCount; j++ )
		{
			calcFirst( bodySymbolList[i][j], temp, 0, bodySymbolCount[i][j], first, terminalCount, nonTerminalCount );
			for( k=0; k<terminalCount; k++ )
			{
				if(temp[k])
				{
					if( parsingTable[i][k] == -1 )
						parsingTable[i][k] = j;
					else
						printf("Parsing table entry [%s,%s] has multipe entries: extra %s\n", 
									nonTerminals[i], terminals[k], cfg->productions[i]->body[j]);
				}
			}
			if(temp[terminalCount])
			{
				for( k=0; k<terminalCount; k++ )
				{
					if(follow[i][k])
					{
						if( parsingTable[i][k] == -1 )
							parsingTable[i][k] = j;
						else
							printf("Parsing table entry [%s,%s] has multiple entries: extra %s\n", 
									nonTerminals[i], terminals[k], cfg->productions[i]->body[j]);
					}
				}
				if(follow[i][terminalCount])
				{
					if( parsingTable[i][terminalCount] == -1 )
					{
						parsingTable[i][terminalCount] = j;
					}
					else
						printf("Parsing table entry [%s,$] has multiple entries: extra %s\n", 
									nonTerminals[i], cfg->productions[i]->body[j]);
				}
			}
		}
	}

}

void printParsingTable( grammar* cfg, int** parsingTable, char** terminals, char** nonTerminals,
					int terminalCount, int nonTerminalCount )
{
	int i,j;
	printf("************PARSING TABLE***************\n");
	printf("NON TERMINAL\t\tINPUT SYMBOL\n");
	printf("            \t");
	for( i=0; i<terminalCount; i++ )
		printf("%s\t\t",terminals[i]);
	printf("$\n");
	for( i=0; i<nonTerminalCount; i++ )
	{
		printf("%s\t\t", nonTerminals[i]);
		for( j=0; j<terminalCount+1; j++ )
		{
			if( parsingTable[i][j] != -1 )
			{
				printf("%s\t\t", cfg->productions[i]->body[parsingTable[i][j]]);
			}
			else printf("\t\t");
		}
		printf("\n");
	}
	printf("****************************************\n");
}

void getTerminalToken( FILE* fp, char* temp )
{
	char* a = temp, c;
	//c = fgetc(fp);
	while( (c = fgetc(fp)) != '>' )
		*a++ = c;
	*a = 0;
}

void scanSymbolTable( struct table_entry *start, int n, char* temp )
{
	while(--n)
	{
		start = start->next;
	}
	strcpy( temp, start->lexeme );
}

int getActualSymbolIndex( char* test, char** a, int n )
{
	if( strcmp(test,"$") == 0 ) return n+1;
	int i;
	for( i=0; i<n; i++ )
		if( strcmp( test, a[i]) == 0 )
			return i;
}

void parseFile ( int** parsingTable, struct table_entry *start, grammar* cfg, char** terminals, char** nonTerminals,
				 int terminalCount, int nonTerminalCount, int*** bodySymbolList, int** bodySymbolCount )
{
	char temp[20], *temp1, *temp2; int aux, i, j, k;
	struct stack Stack; Stack.bottom = Stack.top = NULL;
	FILE *fp = fopen( "token_prog", "r" );
	if(fgetc(fp) == EOF) return;
	printf("PARSING STACK AND ACTIONS\n");
	printf("****************************************\n");
	getTerminalToken( fp, temp );
	toLower( temp );
	temp2 = temp;
	temp1 = strtok( temp2, "," );
	if( !exists( terminals, temp1, terminalCount ) )
	{
		//printf("%s", temp1 );
		temp1 = strtok( NULL, "," );
		scanSymbolTable( start, stringToInt(temp1), temp );
		//printf("%s", temp);
	}
	else strcpy( temp, temp1 );
	toLower( temp ); // temp has the input symbol

	push( &Stack, "$" );
	push( &Stack, cfg->startSymbol );
	while( strcmp(Stack.top->str, "$") )
	{
		printf("STACK : ");
		printStack( &Stack );
		printf("\n");
			//printf("%s ", temp );
		if( strcmp(Stack.top->str, temp) == 0 )
		{
			pop( &Stack );
			printf("ACTION: match %s\n\n", temp ); 
			if(fgetc(fp) == EOF)
			{
				strcpy(temp, "$"); continue;
			}
			getTerminalToken( fp, temp );
			toLower( temp );
			temp2 = temp;
			temp1 = strtok( temp2, "," );
			if( !exists( terminals, temp1, terminalCount ) )
			{
				//printf("%s", temp1 );
				temp1 = strtok( NULL, "," );
				scanSymbolTable( start, stringToInt(temp1), temp );
				//printf("%s", temp);
			}
			else strcpy( temp, temp1 );
			toLower( temp ); // temp has the input symbol
			continue;
		}
		else if( exists( terminals, Stack.top->str, terminalCount ) )
		{
			printf("Syntax errror in file\n"); return;
		}
		i = getActualSymbolIndex(Stack.top->str, nonTerminals, nonTerminalCount);
		if( strcmp(temp,"$") == 0 ) j = terminalCount;
		else j = getActualSymbolIndex(temp, terminals, terminalCount);
		if( (aux = parsingTable[i][j]) == -1 )
		{
			printf("Syntax error in file\n"); return;
		}
		else
		{
			printf("ACTION: output %s -> %s\n\n", Stack.top->str, cfg->productions[i]->body[aux]);
			pop( &Stack );
			for( k = bodySymbolCount[i][aux]-1; k>=0; k-- )
			{
				if( bodySymbolList[i][aux][k] < nonTerminalCount )
					push( &Stack, nonTerminals[bodySymbolList[i][aux][k]] );
				else if( bodySymbolList[i][aux][k] < nonTerminalCount + terminalCount )
					push( &Stack, terminals[bodySymbolList[i][aux][k] - nonTerminalCount] );
			}
		}
		//printf("%s\n", temp );
		//pop( &Stack);
		//push( &Stack, temp );
		//printf("%s", Stack.top->str);
		//printf("\n");
	}
	//pop( &Stack );
	//printf("After popping\n");
	printf("STACK: ");
	printStack( &Stack );
	fclose(fp);
}

int main( int argc, char* argv[] )
{
	if( (argc != 3) && (argc != 2) )
	{
		printf("Usage : executable inputProgram(optional) grammarFile\n");
		return 1;
	}
	int token_count, problem_index;
	struct config_file_entry *token_names = scan_config_file( "config_file", &token_count,&problem_index);
	if( token_names == NULL ) return 1;
	struct table_entry* start;
	if(argc == 3) start = prog_lex_analyse(token_names,token_count,problem_index,argv[1]);
	
	int i, j;
	grammar cfg;
	if( argc==3 )
		scanConfigFile( argv[2], &cfg );
	else
		scanConfigFile( argv[1], &cfg );
	//printGrammar( &cfg );
	char** terminals = (char**)malloc(sizeof(char*)*100);
	int terminalCount, nonTerminalCount=cfg.headCount;
	char** nonTerminals = (char**)malloc(sizeof(char*)*nonTerminalCount);
	for( i=0; i<nonTerminalCount; i++ )
		nonTerminals[i] = cfg.productions[i]->head;
	terminalCount = extractTerminals( &cfg, terminals );
	/*printf("terminals :\n");
	for( i=0; i<terminalCount; i++ )
		printf("%s ", terminals[i] );
	printf("\nNonTerminals :\n");
	for(i=0;i<nonTerminalCount;i++)
		printf("%s ", nonTerminals[i]);*/
	int symbolList[30];
	for( i=0; i<30; i++ )
		symbolList[i] = -1;
	//char test[20];
	//scanf("%s", test);
	//printf("\nhere: ");
	/*int n = getSymbols(  test, terminals, nonTerminals, terminalCount, nonTerminalCount, symbolList );
	for( i=0; i<n; i++ )
	{
		//printf("%d ", symbolList[i]);
		if( symbolList[i] < nonTerminalCount ) printf("%s ", nonTerminals[symbolList[i]] );
		else if( symbolList[i] < (nonTerminalCount + terminalCount) )
			printf("%s ", terminals[symbolList[i]-nonTerminalCount]);
		else printf("# ");
	}*/
	//for( i=0; i
	int ***bodySymbolList, **bodySymbolCount, k;
	fillBodySymbolInformation( &cfg, terminals, nonTerminals, terminalCount, nonTerminalCount, &bodySymbolList, &bodySymbolCount );
	/*for( i=0; i<cfg.headCount; i++ )
	{
		for( j=0; j<cfg.productions[i]->bodyCount; j++ )
		{
			//printf("%d ", bodySymbolCount[i][j]);
			for( k=0; k<bodySymbolCount[i][j]; k++ )
			{
				//printf("%d ", bodySymbolList[i][j][k]);
				if( bodySymbolList[i][j][k] < nonTerminalCount ) printf("%s ", nonTerminals[bodySymbolList[i][j][k]] );
				else if( bodySymbolList[i][j][k] < (nonTerminalCount + terminalCount) )
					printf("%s ", terminals[bodySymbolList[i][j][k]-nonTerminalCount]);
				else printf("# ");
			}
			printf("\n");
		}
	}*/
	int **first = (int**)malloc(sizeof(int*)*nonTerminalCount);
	int **follow = (int**)malloc(sizeof(int*)*nonTerminalCount);
	for( i=0; i<nonTerminalCount; i++ )
	{
		first[i] = (int*)malloc(sizeof(int)*(terminalCount + 1));
		follow[i] = (int*)malloc(sizeof(int)*(terminalCount + 1));
		for( j=0; j<terminalCount + 1; j++)
		{
			first[i][j] = 0; follow[i][j] = 0;
		}
	}
	calculateFirst( &cfg, first, bodySymbolList, bodySymbolCount, terminalCount, nonTerminalCount );
 	calculateFollow( &cfg, follow, first, bodySymbolList, bodySymbolCount, terminalCount, 
						nonTerminalCount, terminals, nonTerminals );
	printf("\n**************");
	printf("\nFirst table:\n");
	printf("**************\n");
	for( i=0; i<cfg.headCount; i++ )
	{
		printf("%s : ", cfg.productions[i]->head );
		for( j=0; j < terminalCount + 1; j++ )
		{
			if( first[i][j] )
			{
				if( j!=terminalCount ) printf("%s ", terminals[j]);
				else printf("# ");
			}
		}
		printf("\n");
	}
	printf("\n**************\n");
	printf("Follow table:\n");
	printf("**************\n");
	for( i=0; i<cfg.headCount; i++ )
	{
		printf("%s : ", cfg.productions[i]->head );
		for( j=0; j < terminalCount + 1; j++ )
		{
			if( follow[i][j] )
			{
				if( j!=terminalCount ) printf("%s ", terminals[j]);
				else printf("$ ");
			}
		}
		printf("\n");
	}
	printf("\n");
	int** parsingTable = (int**)malloc(sizeof(int)*nonTerminalCount);
	for( i=0; i<nonTerminalCount; i++ )
		parsingTable[i] = (int*)malloc(sizeof(int)*(terminalCount + 1));
	fillParsingTable( &cfg, parsingTable, first, follow, terminals, nonTerminals, terminalCount, nonTerminalCount,
						bodySymbolList, bodySymbolCount );
	printf("\n");
	printParsingTable( &cfg, parsingTable, terminals, nonTerminals, terminalCount, nonTerminalCount );
	if( argc == 3 )
	parseFile( parsingTable, start, &cfg, terminals, nonTerminals, terminalCount, nonTerminalCount,
				bodySymbolList, bodySymbolCount);
	return 0;
}
