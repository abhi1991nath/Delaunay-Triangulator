//******************************************
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
void dtob(int num, char *b)
{
   short i;
   //char b[12];

   //short num = 128;

    for( i = 11; i >= 0; i--)        
   {
        if( (1 << i) & num)
           b[11 - i] = '1';
        else
           b[11 - i] = '0';                   
   }
   
   b[12] = 0; // ascii terminating character
  
  //printf("\n %d  %x  %s\n", num, num, b); // decimal, hex, binary formats
   
  	
  //return 0;
}

//***********************************************

void gen(char * st)
{
int i,k=0,j;
char bin[12],temp[1000];
//char *pro[pow(2,strlen(st))];
char *pro[1000];
char *tmp;

for(i=0;i<pow(2,strlen(st));i++)
{
	dtob(i,bin);
	for(j=0;j<strlen(st);j++)
		{
			if(1)
				{
				if(bin[11-j]=='1')
					temp[k++]=st[j];
				}
			else
				temp[k++]=st[j];

		}
	temp[k]='\0';
	k=0;
	tmp=(char *)malloc(strlen(temp)*sizeof(char));
	strcpy(tmp,temp);
	pro[i]=tmp;
	printf("\n%s",pro[i]);

}
}

void generateBinary( char* str, int n, int i )
{
	int k;
	for( k=0; k<n; k++ )
	{
		if(i%2) str[k] = '1';
		else str[k] = '0';
		i /= 2;
	}
}

int main()
{
	char a[8];
	a[7] = 0;
	generateBinary(a, 7, 32); 
	printf("%s\n", a );
}
