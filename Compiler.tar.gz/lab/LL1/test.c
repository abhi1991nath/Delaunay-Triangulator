#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int findLongestPrefix( char** a, int n, int* len )
{
	int index, length=0,i,j,k;
	char temp[200];
	for( i=0; i<n-1; i++ )
	{
		strcpy( temp, a[i] );
		for( j=strlen(a[i]); j>0; j-- )
		{
			temp[j] = 0;
			for( k = i+1; k<n; k++ )
			{
				if( (strstr( a[k], temp) == a[k]) && (strlen(temp) > length) )
				{
					length = strlen(temp); index = i;
				}
			}
		}
	}
	if(length == 0) return -1;
	*len = length;
	return index;
}

void reposition( char** a, int n, int j )
{
	int i, k;
	while( (j--)!=0 )
	{
		for(i=0; i<n; i++)
		{
			if( a[i][0] == '\0' )
			{
				free(a[i]);
				for( k = i+1; k<n; k++ )
					a[k-1] = a[k];
				n--;
				break;
			}
		}
	}
}

int main()
{
	/*char a[100];
	gets(a);
	char *b = a, *c;
	if( (c = strtok( b, " " )) == NULL ) printf("no tokens");
	else
	{
		printf("%s\n", c );
		while( (c=strtok( NULL, " " )) )
			printf("%s\n", c);
	}
	gets(a); b = a;
	if( (c = strtok( b, " " )) == NULL ) printf("no tokens");
	else
	{
		printf("%s\n", c );
		while( (c=strtok( NULL, " " )) )
			printf("%s\n", c);
	}*/
	char** a; int i,j=0;
	a = (char**)malloc( sizeof(char*)*10);
	for( i = 0; i<10; i++ )
	{
		a[i] = (char*)malloc(sizeof(char)*20);
		gets(a[i]);
		if(strlen(a[i])==0) j++;
	}
	int l; 
	//char** c = a;
	//int b = findLongestPrefix( a, 3, &l );
	reposition( a, 10, j);
	for( i =0; i<10; i++ )
		printf("%s\n", a[i]);
	//printf("%d %d", b, l);
	return 0;
}
