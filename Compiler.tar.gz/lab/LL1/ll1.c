#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>

typedef struct
{
	char *head, **body;
	int bodyCount;
} production;

typedef struct
{
	char* startSymbol;
	int headCount;
	production* productions[30];
} grammar;

void trim( char* a )
{
	char* b = (char*)malloc(sizeof(char)*(strlen(a)+1));
	strcpy(b,a);
	if( (a[0] == '#') && (strlen(a)>1) )
		strcpy(a,b+1);
	free(b);
}

void printGrammar( grammar* cfg2 )
{
	int i,j;
	for( i = 0; i<cfg2->headCount; i++ )
	{
		printf( "%s -> ", cfg2->productions[i]->head );
		for( j = 0; j<cfg2->productions[i]->bodyCount; j++ )
		{
			printf("%s |", cfg2->productions[i]->body[j]);
		}
		printf("\n");
	}
}

int scanConfigFile ( char* fileName, grammar* cfg )
{
	FILE* fp;
	if(!(fp = fopen(fileName, "r"))) return 1;
	char line[200], line2[200], *wrapper, *temp; 
	int count = 0, bodyCount, i;
	while( fgets( line, 200, fp ) )
	{
		line[strlen(line)-1] = 0;
		strcpy( line2, line );
		bodyCount = 0;
		wrapper = line;
		if( !(temp = strtok( wrapper, " \t|" )) ) continue;
		if( count == 0 )
		{
			cfg->startSymbol = (char*)malloc(sizeof(char)*(strlen(temp) + 1));
			strcpy( cfg->startSymbol, temp );
		}
		do
		{
			bodyCount++;
		} while( strtok( NULL, " \t|" ) );
		--bodyCount;
		cfg->productions[count] = (production*)malloc(sizeof(production));
		wrapper = line2;
		temp = strtok( wrapper, " \t|" );
		cfg->productions[count]->head = (char*)malloc(sizeof(char)*(strlen(temp) + 1));
		strcpy(cfg->productions[count]->head, temp);
		cfg->productions[count]->body = (char**)malloc(sizeof(char*)*100);
		cfg->productions[count]->bodyCount = bodyCount;
		i=0;
		while( temp = strtok( NULL, " \t|" ) )
		{
			cfg->productions[count]->body[i] = (char*)malloc(sizeof(char)*(strlen(temp) + 1));
			strcpy( cfg->productions[count]->body[i], temp );
			i++;
		}
		count++;
	}
	fclose(fp);
	cfg->headCount = count;
	return 0;
}

int findLongestPrefix( char **a, int n, int* len )
{
	int index, length=0,i,j,k;
	char temp[200];
	for( i=0; i<n-1; i++ )
	{
		strcpy( temp, a[i] );
		for( j=strlen(a[i]); j>0; j-- )
		{
			temp[j] = 0;
			for( k = i+1; k<n; k++ )
			{
				if( (strstr( a[k], temp) == a[k]) && (strlen(temp) > length) )
				{
					length = strlen(temp); index = i;
				}
			}
		}
	}
	if(length == 0) return -1;
	*len = length;
	return index;
}

void reposition( char** a, int n, int j )
{
	int i, k;
	while( (j--)!=0 )
	{
		for(i=0; i<n; i++)
		{
			if( a[i][0] == '\0' )
			{
				//free(a[i]);
				for( k = i+1; k<n; k++ )
					a[k-1] = a[k];
				//free(a[k-1]); //change here
				n--;
				break;
			}
		}
	}
}

void leftFactorProduction( grammar* cfg, int i )
{
	production* prod = cfg->productions[i];
	char temp[10];
	int j, len=-1, index, extra=0;
	char prefix[200];
	while(1)
	{
		index = findLongestPrefix( prod->body, prod->bodyCount, &len );
		if( index == -1 ) break;
		//extra++;
		//change here due to '<' and '>' (delimiters of terminals)
		if( (prod->body[index][len-1] == '<') )
		{
			if( len == 1 ) break;
			if( len != 1 ) len--;
		}
		//change complete
		extra++;
		strncpy( prefix, prod->body[index], len );
		prefix[len] = 0;
		printf("Left factoring required due to production having head '%s'. The culprit 'prefix' is\n\t'%s'\n",
					prod->head, prefix);
		j=0;
		for( i=0; i<prod->bodyCount; i++ )
		{
			if( strstr( prod->body[i], prefix) == prod->body[i] ) j++;
		}
		cfg->productions[cfg->headCount] = (production*)malloc(sizeof(production));
		cfg->productions[cfg->headCount]->bodyCount = j;
		cfg->productions[cfg->headCount]->body = (char**)malloc(sizeof(char*)*100);
		sprintf( temp, "%d", extra );
		cfg->productions[cfg->headCount]->head = (char*)malloc(sizeof(char)*(strlen(temp)+strlen(prod->head)+1));
		strcpy( cfg->productions[cfg->headCount]->head, prod->head);
		strcat( cfg->productions[cfg->headCount]->head, temp );
		j=0;
		for( i=0; i<prod->bodyCount; i++ )
		{
			if( strstr( prod->body[i], prefix) == prod->body[i] )
			{
				if( strlen(prod->body[i]) == len )
				{
					cfg->productions[cfg->headCount]->body[j] = (char*)malloc(sizeof(char)*2);
					strcpy(cfg->productions[cfg->headCount]->body[j], "#");
				}
				else
				{
					cfg->productions[cfg->headCount]->body[j] = (char*)malloc(sizeof(char)*(strlen(prod->body[i])-len+1));
					strcpy(cfg->productions[cfg->headCount]->body[j], (prod->body[i]+len));
				}
				(prod->body[i])[0] = '\0';
				j++;
			}
		}
		reposition( prod->body, prod->bodyCount, j);
		prod->bodyCount -= j-1;
		//free(prod->body[prod->bodyCount-1]);
		prod->body[prod->bodyCount-1] = (char*)malloc(sizeof(char)*(len+strlen(cfg->productions[cfg->headCount]->head)+1));
		strcpy( prod->body[prod->bodyCount-1], prefix);
		strcat( prod->body[prod->bodyCount-1], cfg->productions[cfg->headCount]->head );
		cfg->headCount++;
	}
}

void leftFactor( grammar* cfg )
{
	int count = cfg->headCount, i;
	for( i=0; i<count; i++ )
	{
		leftFactorProduction( cfg, i );
	}
}

int isNonTerminal( grammar* cfg, char* testString, int i, int j )
{
	if( (i>=cfg->headCount) || (j>=cfg->headCount) || (i<0) || (j<0) )
		return -1;
	int k;
	for( k=i; k<=j; k++ )
	{
		if(strcmp(testString, cfg->productions[k]->head)==0) return 1;
	}
	return 0;
}

void removeImmediateLeftRecursion( grammar* cfg, int j )
{
	production* prod = cfg->productions[j];
	char head[20]; strcpy( head, cfg->productions[j]->head ); strcat( head, "'" ); 
	int count=0, i;
	for( i=0; i<prod->bodyCount; i++ )
	{
		if( strstr( prod->body[i], prod->head ) == prod->body[i] ) count++;
	}
	if( count==0 ) return;
	cfg->productions[cfg->headCount] = (production*)malloc(sizeof(production));
	cfg->productions[cfg->headCount]->body = (char**)malloc(sizeof(char*)*100);
	cfg->productions[cfg->headCount]->bodyCount = count + 1;
	cfg->productions[cfg->headCount]->head = (char*)malloc(sizeof(char)*(strlen(head)+1));
	strcpy( cfg->productions[cfg->headCount]->head, head );
	count = 0;
	for( i=0; i<prod->bodyCount; i++ )
	{
		if( strstr( prod->body[i], prod->head ) == prod->body[i] ) 
		{
			cfg->productions[cfg->headCount]->body[count] = 
				(char*)malloc(sizeof(char)*(strlen(prod->body[i])+2));
			strcpy(cfg->productions[cfg->headCount]->body[count], prod->body[i] + strlen(prod->head));
			strcat(cfg->productions[cfg->headCount]->body[count], cfg->productions[cfg->headCount]->head); 
			prod->body[i][0] = 0;
			count++;
		}
		else
		{
			realloc(prod->body[i], strlen(prod->body[i])+strlen(cfg->productions[cfg->headCount]->head)+1);
			strcat(prod->body[i], cfg->productions[cfg->headCount]->head);
			trim( prod->body[i] );
		}
	}
	cfg->productions[cfg->headCount]->body[count] = (char*)malloc(sizeof(char));
	strcpy(cfg->productions[cfg->headCount]->body[count], "#");
	reposition( prod->body, prod->bodyCount, count );
	prod->bodyCount -= count;
	cfg->headCount++;
}

int checkForPrefix( grammar* cfg, int i, char* test )
{
	int k;
	for( k=0; k<cfg->productions[i]->bodyCount; k++ )
	{
		if( strstr( cfg->productions[i]->body[k], test )
					== cfg->productions[i]->body[k] )
		{
			return k;
		}
	}
	return -1;
}

void addBody( grammar* cfg, int i, char* temp )
{
	//printf("addBody called\n");
	//if(!realloc( cfg->productions[i]->body, cfg->productions[i]->bodyCount + 1 ))
		//printf("realloc failed");
	if( (strlen(temp)>1) && (temp[0]=='#') )
	{
		cfg->productions[i]->body[cfg->productions[i]->bodyCount]
					= (char*)malloc(sizeof(char)*(strlen(temp)));	
		strcpy(cfg->productions[i]->body[cfg->productions[i]->bodyCount],
				temp+1);
	}
	else
	{
		cfg->productions[i]->body[cfg->productions[i]->bodyCount]
					= (char*)malloc(sizeof(char)*(strlen(temp)+1));
		strcpy(cfg->productions[i]->body[cfg->productions[i]->bodyCount],
					temp);
	}
	cfg->productions[i]->bodyCount++;
}

void removeLeftRecursion( grammar* cfg )
{
	production** prods = cfg->productions;
	int count = cfg->headCount;
	int i,j,k;
	char temp[100], temp2[200];
	for( i=0; i<count; i++ )
	{
		for( j=0; j<i; j++ )
		{
			while( (k=checkForPrefix( cfg, i, prods[j]->head )) != -1 )
			{
				strcpy( temp, prods[i]->body[k] + strlen(prods[j]->head) );
				prods[i]->body[k][0] = 0;
				reposition( prods[i]->body, prods[i]->bodyCount, 1 );
				prods[i]->bodyCount--;
				for( k=0; k<prods[j]->bodyCount; k++ )
				{
					strcpy( temp2, prods[j]->body[k] );
					strcat( temp2, temp );
					addBody( cfg, i, temp2 );
				}
			}
		}
		removeImmediateLeftRecursion( cfg, i );
	}
}

int isDirectlyNullable( grammar* cfg, int i )
{
	production* prod = cfg->productions[i];
	int k;
	for( k=0; k<prod->bodyCount; k++ )
	{
		if( strcmp(prod->body[k], "#") == 0 ) return 1;
	}
	return 0;
}

int getNonTerminalIndex( grammar *cfg, char* testString )
{
	int i;
	for( i=0; i<cfg->headCount; i++ )
	{
		if( strcmp( cfg->productions[i]->head, testString ) == 0 )
			return i;
	}
}

int isNullable( grammar* cfg, int* result, char* testString )
{
	char temp[2]; temp[1] = 0;
	int i;
	for( i=0; i<strlen(testString); i++ )
	{
		temp[0] = testString[i];
		if( !result[getNonTerminalIndex(cfg,temp)] )
			return 0;
	}
	return 1;
}

int unitProduction( grammar* cfg, int i, int j )
{
	production* prod = cfg->productions[i];
	int k;
	for( k=0; k<prod->bodyCount; k++ )
	{
		if( strcmp(prod->body[k], cfg->productions[j]->head) == 0 )
			return 1;
	}
	return 0;
}

int sum2D( int** a, int n1, int n2 )
{
	int i, j, sum=0;
	for( i=0; i<n1; i++ )
		for( j=0; j<n2; j++ )
			sum+=a[i][j];
	return sum;
}

void getUnitPairs( grammar *cfg, int** result )
{
	int i, j, k,count;
	for( i=0; i<cfg->headCount; i++ )
		for( j=0; j<cfg->headCount; j++ )
		{
			if( i==j ) result[i][j] = 1;
			else result[i][j] = 0;
		}
	here1: count = sum2D( result, cfg->headCount, cfg->headCount );
	for( i=0; i<cfg->headCount; i++ )
	{
		for( j=0; j<cfg->headCount; j++ )
		{
			for( k=0; k<cfg->headCount; k++ )
			{
				if( result[i][j] && unitProduction( cfg, j, k ) )
					result[i][k] = 1;
			}
		}
	}
	if( sum2D( result, cfg->headCount, cfg->headCount ) > count )
		goto here1;
}

int sum( int* a, int n )
{
	int i, sum=0;
	for(i=0;i<n;i++)
		sum += a[i];
	return sum;
}

int hasOnlyNonTerminals( grammar* cfg, char* testString )
{
	char temp[2]; temp[1] = 0;
	int i;
	for( i=0; i<strlen(testString); i++ )
	{
		temp[0] = testString[i];
		if( !isNonTerminal(cfg, temp, 0, cfg->headCount -1) )
			return 0;
	}
	return 1;
}

void getNullableNonTerminals( grammar *cfg, int *result )
{
	int i, j, count;
	for( i=0; i<cfg->headCount; i++ )
		result[i] = 0;
	for( i=0; i<cfg->headCount; i++ )
	{
		if( isDirectlyNullable( cfg, i ) )
			result[i] = 1;
	}
	here: count = sum( result, cfg->headCount );
	for( i=0; i<cfg->headCount; i++ )
	{
		if( result[i] ) continue;
		for( j=0; j<cfg->productions[i]->bodyCount; j++ )
		{
			if( !(hasOnlyNonTerminals( cfg, cfg->productions[i]->body[j] ) ) )
				continue;
			if( isNullable( cfg, result, cfg->productions[i]->body[j]) )
			{
				result[i] = 1; break;
			}
		}
	}
	if( sum( result, cfg->headCount ) > count )
		goto here;
}

void generateBinary( char* str, int n, int i )
{
	int k;
	for( k=0; k<n; k++ )
	{
		if(i%2) str[k] = '1';
		else str[k] = '0';
		i /= 2;
	}
}

int isPresent( char** temp, int i )
{
	if( strlen(temp[i]) == 0 ) return 1;
	int k;
	for( k=0; k<i; k++ )
	{
		if( strcmp(temp[k],temp[i])==0 )
			return 1;
	}
	return 0;
}

void fillByPattern( char* target, char* src, char* pattern, grammar* cfg, int* result )
{
	int i=0,j=0; char temp[2]; temp[1] = 0;
	//printf("patter = %s\n", pattern);
	while( i!= strlen(src) )
	{
		//printf("*");
		if( pattern[i] == '1' )
		{
			target[j] = src[i]; j++;
		}
		else
		{
			temp[0] = src[i];
			if( isNonTerminal( cfg, temp, 0, cfg->headCount-1 ) )
			{
				if( isNullable( cfg, result, temp ) )
				{
					i++;
					continue;
				}
				else
				{
					target[j] = src[i]; j++;
				}
			}
			else
			{
				target[j] = src[i]; j++;
			}
		}
		i++;
	}
	//printf("out\n");
	target[j] = 0;
}

void permuteAndAdd( grammar* cfg2, grammar* cfg, int k, char* str, int* result )
{
	//printf("permuteAdd %s ", str);
	if( strcmp(str,"#")==0 ) return;
	int n = strlen(str), i,j;
	int m = pow(2,n);
	//printf("pow = %d ", m);
	char** temp = (char**)malloc(sizeof(char*)*pow(2,n));
	char* temp1 = (char*)malloc(sizeof(char)*(n+1));
	temp1[n] = 0;
	for( i=0; i<m; i++ )
	{
		generateBinary( temp1, n, i );
		temp[i] = (char*)malloc(sizeof(char)*(n+1));
		fillByPattern( temp[i], str, temp1, cfg, result );
		if( isPresent( temp, i ) ) continue;
		addBody( cfg2, k, temp[i] );
	}
	for( i=0; i<m; i++ )
		free(temp[i]);
	free(temp);
	free(temp1);
}

grammar* removeEpsilonProductions( grammar* cfg, int* result )
{
	int i,j;
	getNullableNonTerminals( cfg, result );
	if( sum(result, cfg->headCount) == 0 ) return cfg;
	grammar* cfg2 = (grammar*)malloc(sizeof(grammar));
	cfg2->headCount = cfg->headCount;
	cfg2->startSymbol = cfg->startSymbol; //careful here
	for( i=0; i<cfg2->headCount; i++ )
	{
		cfg2->productions[i] = (production*)malloc(sizeof(production));
		cfg2->productions[i]->head = cfg->productions[i]->head; //careful here
		cfg2->productions[i]->bodyCount = 0;
		cfg2->productions[i]->body = (char**)malloc(sizeof(char*)*100);//required due to realloc in addBody
	}
	for( i=0; i<cfg2->headCount; i++ )
	{
		for( j=0; j<cfg->productions[i]->bodyCount; j++ )
		{
			//printf("here\n");
			permuteAndAdd( cfg2, cfg, i, cfg->productions[i]->body[j], result );
		}
	}
	return cfg2;
}

grammar* removeUnitProductions( grammar* cfg, int** result )
{
	int i,j,k;
	grammar* cfg2 = (grammar*)malloc(sizeof(grammar));
	cfg2->headCount = cfg->headCount;
	cfg2->startSymbol = cfg->startSymbol; //careful here
	for( i=0; i<cfg2->headCount; i++ )
	{
		cfg2->productions[i] = (production*)malloc(sizeof(production));
		cfg2->productions[i]->head = cfg->productions[i]->head; //careful here
		cfg2->productions[i]->bodyCount = 0;
		cfg2->productions[i]->body = (char**)malloc(sizeof(char*)*100);//required due to realloc in addBody
	}
	for( i=0; i<cfg2->headCount; i++ )
		for( j=0; j<cfg2->headCount; j++ )
			if( result[i][j] )
			{
				for( k=0; k<cfg->productions[j]->bodyCount; k++ )
				{
					if(!isNonTerminal( cfg, cfg->productions[j]->body[k], 0, cfg->headCount-1))
					{
						addBody( cfg2, i, cfg->productions[j]->body[k] );
					}
				}
			}
	return cfg2;
}

void writeGrammarToFile( grammar* cfg, char* fileName )
{
	FILE* fp = fopen( fileName, "w" );
	int i, j;
	for( i=0; i<cfg->headCount; i++ )
	{
		fprintf( fp, "%s\t", cfg->productions[i]->head );
		for( j=0; j<cfg->productions[i]->bodyCount; j++ )
		{
			fprintf( fp, " %s | ", cfg->productions[i]->body[j] );
		}
		fprintf(fp, "\n");
	}
	fclose(fp);
}

int main( int argc, char* argv[] )
{
	if( argc != 3 )
	{
		printf("Usage: program configFileName outputFile\n");
		return 1;
	}
	grammar cfg;
	if( scanConfigFile( argv[1], &cfg ) !=0 )
	{
		printf("Error reading config file. Exiting...\n");
		return 1;
	}
	int i, j;
	printGrammar( &cfg );
	/*leftFactor(&cfg);
	printf("After left factoring\n");
	printGrammar(&cfg);*/
	/*removeLeftRecursion( &cfg );
	//addBody( &cfg, 0, "edfehdf" ); 
	printf("After removing left recursion\n");
	printGrammar( &cfg );
	*/
	int *result = (int*)malloc(sizeof(int)*(cfg.headCount)); 
	grammar* cfg2 = removeEpsilonProductions( &cfg, result );
	printf("Nullable non-terminals :\n");
	for( i=0; i<cfg.headCount; i++ )
	{
		if(result[i])
			printf("%s\n", cfg.productions[i]->head);
	}
	printf("After removing epsilon productions\n");
	printGrammar( cfg2 );
	int** result1 = (int**)malloc(sizeof(int*)*(cfg2->headCount));
	for( i=0; i<cfg2->headCount; i++ )
		result1[i] = (int*)malloc(sizeof(int)*(cfg2->headCount));
	getUnitPairs( cfg2, result1 );
	printf("Unit pairs \n");
	for( i=0; i<cfg2->headCount; i++ )
	{
		for( j=0; j<cfg2->headCount; j++ )
		{
			if( result1[i][j] )
				printf("(%s,%s)\n", cfg2->productions[i]->head, cfg2->productions[j]->head );
		}
	}
	grammar* cfg3 = removeUnitProductions( cfg2, result1 );
	printf("Grammar after removing unit productions\n");
	printGrammar( cfg3 );
	removeLeftRecursion( cfg3 );
	printf("After removing left recursion\n");
	printGrammar( cfg3 );
	leftFactor( cfg3 );
	printf("After left factoring\n");
	printGrammar( cfg3 );
	writeGrammarToFile( cfg3, argv[2] );
	return 0;
}
