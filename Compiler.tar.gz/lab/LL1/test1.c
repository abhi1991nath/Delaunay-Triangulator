#include<stdio.h>
#include<string.h>
#include<ctype.h>

void toLower ( char* str )
{
	char* a = str;
	while(*a)
	{
		*a = tolower(*a); a++;
	}
}

int stringToInt ( char* temp )
{
	int n = 0; char* a = temp;
	while(*a)
	{
		n += (*a++ -48 );
		n *=10;
	}
	return n/10;
}

char* extractWord( char* target, char d1, char d2, int* len )
{
	char* temp1, *temp2; int n;
	temp1 = strchr( target, d1 );
	if(!temp1) 
	{
		*len = 0;	return NULL;
	}
	temp2 = strchr( target, d2 );
	n = (temp2-temp1-1);
	printf("n=%d",n);
	if( n>=1 )
	{
		*len = n;
		//return temp2+1;
	}
	if( n== 0 )
	{
		if( *(temp2+1) != d2 )
		{
			*len = 2;
			//return temp2 + 3;
		}
		else if( *(temp2+2) == d2 )
		{
			*len = 2;
			//return temp2 + 3;
		}
		else *len = 1;
		//return temp2 + 2;
	}
	return temp1+1;
}

int main()
{
	char a[20];
	gets(a);
	printf("%d", stringToInt(a));
	//printf("%s\n", a);
	/*int len,i; char* b;
	b = extractWord( a, '<', '>', &len );
	printf("len = %d\n",len);
	for(i=0;i<len;i++)
		printf("%c", b[i]);*/
}
