/************************************************************************** 
   UDP client written by Abhinandan Nath, Roll no. 09010101.
   The client queries a server for the timestamp of the requested file 
   and sends the request to server 
**************************************************************************/

#include "./header.h"
	
int main(int argc, char* argv[])
{
	if( argc != 3 )
	{
		printf("Usage : %s server_ip file_path\n", argv[0] );
		exit(1);
	}
	
	struct sockaddr_in server_sockaddr; /* structure to hold server address */
	int client_sock, sockaddr_len = sizeof(server_sockaddr), i;
	short connection_id, REQUEST=0, REQUEST_ACK=1, DONE=2, DONE_ACK=3;
	char buf[BUFLEN], timestamp[256], server_ip[128], *ip;
	
	ip = get_ip(argv[1]);
	if(ip == NULL) {printf("Error in server hostname"); return 1;}
	i=0;
	while( ip[i] != '\0' )
	{
		server_ip[i] = ip[i]; i++;
	} server_ip[i] = ip[i];
	
	/* create datagram client socket in Internet domain,
	   the client uses UDP protocol */
	if( (client_sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP))==-1 )
		exit_gracefully("socket");

	server_sockaddr.sin_family = AF_INET;
	server_sockaddr.sin_port = htons(SERVER_PORT);
	if( inet_aton(server_ip, &(server_sockaddr.sin_addr))==0 ) 
	{
    		fprintf(stderr, "server IP address does not exist\n");
		exit(2);
	}
	
	//memset(buf, 0, buflen)	
	/*request_packet.type = htons(REQUEST);
	request_packet.status = htons(0);
	request_packet.connection_id = htons(-1);*/
	//strcpy(request_packet.buffer, argv[2]);
	//clear_buffer(buf);
	
	/* fill REQUEST packet */
	fill_packet( 0, REQUEST, 0, argv[2], buf );	

	printf("\nTrying %s ...\n", argv[1]);
	/* send REQUEST ti server */
	if( sendto(client_sock, (void*)buf , BUFLEN, 
		0, (struct sockaddr*) &server_sockaddr, sizeof(server_sockaddr)) == -1 )
	{
		exit_gracefully("REQUEST not sent");		
	}
	else
	{
		printf("Server %s querying the timestamp of %s ...\n", argv[1], argv[2]);
	}
	
	/* receive REQUEST_ACK from server */
	clear_buffer(buf);
	if( recvfrom( client_sock, (void*)buf, BUFLEN, 0, (struct sockaddr*) &server_sockaddr, &sockaddr_len ) == -1)
		exit_gracefully("REQUEST_ACK not received");
	
	//if( ntohs(*(buf + sizeof(short))) != REQUEST_ACK ) printf("WRONG");
	sockaddr_len = sizeof(server_sockaddr);
	//printf("Request ack %hd\n", ntohs(*(buf + sizeof(short))));
	
	if( (extract_type(buf) != REQUEST_ACK) || (extract_status(buf) != 0) )
	{
		fprintf(stderr, "error in REQUEST_ACK. Exiting\n"); 	
		//exit(2);
	}
	//printf("type = %hd\n", extract_type(buf) );
	connection_id = extract_cid(buf);              // get connection id from REQUEST_ACK packet
	//printf("\ncid = %hd\n", connection_id );
	clear_buffer(buf);                  // fill buf with zeroes
	
	/* receive DONE from server */
	if( recvfrom( client_sock, (void*)buf, BUFLEN, 0, (struct sockaddr*) &server_sockaddr, &sockaddr_len ) == -1)
		exit_gracefully("DONE not received");

	sockaddr_len = sizeof(server_sockaddr);
	//printf("Done %hd\n", ntohs(*(buf + sizeof(short))));	
	
	if( (connection_id != extract_cid(buf)) || (extract_type(buf) != DONE) 
	    || ( extract_status(buf) != 0 ) )
	{
		fprintf(stderr, "Error : could not compute timestamp. Exiting\n");
		//exit(2);
	}
	else
	{
		i=0;
		while( buf[3*sizeof(short) + i] != 0 )    // getting the timestamp of file from DONE packet
		{
			timestamp[i] = buf[3*sizeof(short) + i];
			i++;
		}
		timestamp[i] = 0;
		printf("Timestamp of %s is %s\n", argv[2], timestamp);
	}
	/*memset((void *) &done_ack_packet, 0, sizeof(done_ack_packet));
	done_ack_packet.type = htons(DONE_ACK);
	done_ack_packet.status = htons(0);
	done_ack_packet.connection_id = htons(connection_id);*/

	/* fill DONE_ACK packet, then send it */
	//printf("type = %hd\n", extract_type(buf));
	fill_packet(connection_id, DONE_ACK, 0, NULL, buf);
	if( sendto(client_sock, (void*) buf, BUFLEN, 
		0, (struct sockaddr*) &server_sockaddr, sizeof(server_sockaddr)) == -1 )
		exit_gracefully("DONE_ACK not sent");
	
	return 0;
}
	
	
