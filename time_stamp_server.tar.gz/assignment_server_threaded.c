/************************************************************************** 
   Multi-threaded UDP server written by Abhinandan Nath, Roll no. 09010101
   The server creates one thread per new request, calculates the timestamp
   of the requested file and sends it to client 
**************************************************************************/
#include "./header.h"

/* main thread that handles incoming datagrams
   and dispatches them to appropriate threads starts here */
int main()
{
	pthread_t tid;
	struct sockaddr_in server_sockaddr, client_sockaddr;
	int sockaddr_len = sizeof(client_sockaddr);
	short connection_id; 
	
	/* create a socket in the Internet domain, which uses UDP protocol */
	if( (server_sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP))==-1 )
		exit_gracefully("socket");
	
	memset((char*) &server_sockaddr, 0, sizeof(server_sockaddr));
	server_sockaddr.sin_family = AF_INET;
	server_sockaddr.sin_port = htons(SERVER_PORT);
	server_sockaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	
	/* bind the socket to the server address defined above */
	if( bind(server_sock, (struct sockaddr*)&server_sockaddr, sizeof(server_sockaddr))==-1 )
		exit_gracefully("bind");	
	
	while(1)
	{
		clear_buffer(buf);
		
		/* receive packet, store received data in buf. The address of source is stored in client_sockaddr */
		if( recvfrom( server_sock, (void*)buf, BUFLEN, 0, (struct sockaddr*) &client_sockaddr, &sockaddr_len ) == -1)
			continue; //exit_gracefully("packet not received");
		sockaddr_len = sizeof(client_sockaddr);
		
		/* the following condition checks if received packet is a request. If it is, a new
		   thread is created to process the request, else the appropriate thread is woken up */
		if(check_if_request(buf))
		{
			/* the connection_id is set as the index of the first free trade in thread_pool*/
			connection_id = get_free_thread(thread_pool);
			initialise_worker_thread( thread_pool + connection_id, connection_id, client_sockaddr );
			printf("creating thread");
			if( pthread_create( &tid, NULL, worker_function, (void*)(thread_pool + connection_id) ) != 0)
			{
				fprintf(stderr, "error in thread creation. Exiting\n");
				continue;
			}
			/* copy received data to local buffer of thread created */
			memcpy( thread_pool[connection_id].buf, buf, BUFLEN );
		}
		else
		{
			/* extract connection id from received packet, so as to identify
			   for which thread the packet is meant */
			connection_id = extract_cid(buf);
			pthread_mutex_lock(&(thread_pool[connection_id].worker_mutex));
			/* copy the packet to the respective thread's local buffer, then
			   wake up the thread */
			memcpy( thread_pool[connection_id].buf, buf, BUFLEN );
			pthread_cond_signal(&(thread_pool[connection_id].worker_cond_var));
			pthread_mutex_unlock(&(thread_pool[connection_id].worker_mutex));
		}
		//pthread_mutex_unlock(&socket_mutex);
	}
	printf("Shutting down server ....\n");
	return 0;
}
			

