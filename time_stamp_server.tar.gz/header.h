#include <pthread.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#define SERVER_PORT 9930
#define SERVER_IP 127.0.0.1
#define BUFLEN 512        /* size of input and output buffer */
#define POOL_SIZE 100     /* maximum no. of threads in the server program, i.e.,
			     maximum no. of simultaneous connections possible
			     If no. of requests exceed, then server crashes */

#define FILENAME_SIZE 128 /* maximum no. of characters in path of file */

const short REQUEST = 0, REQUEST_ACK = 1, DONE = 2, DONE_ACK = 3; /* codes for frame types */
char buf[BUFLEN];
pthread_mutex_t socket_mutex = PTHREAD_MUTEX_INITIALIZER; /* mutex to ensure mutually exclusive
							     use of socket while sending */
int server_sock;          /* socket for server */

/* function to check if a packet is a REQUEST,
   returns 1 if yes, 0 if not */
int check_if_request( char* buffer ) 
{
	short check = *(buffer + sizeof(short));
	if(check == 0) return 1;
	return 0;
}

/* function to extract connection_id from packet */
short extract_cid( char* buffer )
{
	short cid;
	memcpy( &cid, buffer, sizeof(short) );
	return ntohs(cid);
}

/* function to extact type from packet */
short extract_type( char* buffer )
{
	short type; 
	memcpy( &type, buffer + sizeof(short), sizeof(short));
	return ntohs(type);
}

/*function to extract status from packet*/
short extract_status( char* buffer )
{
        short status;
        memcpy( &status, buffer + 2*sizeof(short), sizeof(short));
        return ntohs(status);
}

/* structure of a worker thread, one thread per connection
   contains data required for processing packets
   main processing of packets is done by a worker thread */
struct worker_thread
{
	short connection_id;
	struct sockaddr_in client_sockaddr; /* address of client serviced by
					       this thread */

	pthread_mutex_t worker_mutex;       /* mutexes & cond_vars used by this */
	pthread_cond_t worker_cond_var;     /* thread for sleeping & waking up */

	int active;                         /* active is used to check if struct is free,
					       is 1 free */
	char buf[BUFLEN];                   /* local buffer for each thread */
};

/* function to initialise worker_thread structure */
void initialise_worker_thread( struct worker_thread *wt, 
		short connection_id, struct sockaddr_in cs)
{
	wt->connection_id = connection_id;
	wt->client_sockaddr = cs;
	pthread_mutex_init(&(wt->worker_mutex), NULL);
	pthread_cond_init(&(wt->worker_cond_var), NULL); 
	memset( wt->buf, 0, BUFLEN );       /* fill local buffer with 0's */
	wt->active = 1;                     /* mark struct as busy or active */
}

/* function to get free worker_thread struct from thread_pool */
short get_free_thread( struct worker_thread *thread_pool )
{
	short i=0;
	while( (thread_pool++)->active == 1)
	{ 
		i++;
		if(i== POOL_SIZE)
		{
			printf("Server crashed...\n");
			exit(1);
		}
	} 
	return i;
}
	
/* function to exit gracefully */
void exit_gracefully( char* s )
{
	perror(s);
	exit(1);
}

void thread_exit_gracefully( char* s )
{
	perror(s);
	pthread_exit(NULL);
}

/* function to fill buffer with appropriate fields 
   Use data as NULL pointer if we want to fill a control packet
   with no data */
void fill_packet( short cid, short type, short status, const char* data, char* buf )
{
	memset( buf, 0, BUFLEN );
	short n_cid = htons(cid), n_type = htons(type), n_status = htons(status);
	memcpy( (void*)buf, (void*)&n_cid, sizeof(short) );
	memcpy( (void*)(buf + sizeof(short)), (void*)&n_type, sizeof(short) );
	memcpy( (void*)(buf + 2*sizeof(short)), (void*) &n_status, sizeof(short) );
	if(data != NULL) strcpy(buf + 3*sizeof(short), data);
	//printf("Inside fill_packet ci %hd type %hd status %hd data %s\n", 
		//(*buf), (*(buf + sizeof(short))), (*(buf + 2*sizeof(short))), buf + 3*sizeof(short));
}

/* function to clear a buffer and fill it with 0's */
void clear_buffer( char* buffer )
{
	memset( buffer, 0, BUFLEN );
}

/* function to get IP address from hostname */
char* get_ip( const char* hn )
{
	struct hostent *he;
	struct in_addr **addr_list;
	int i; char* a;
	if( (he = gethostbyname(hn)) == NULL )
	{
		herror("gethostbyname");
		return NULL;
	}
	addr_list = (struct in_addr **) he->h_addr_list;
	a = inet_ntoa(*(struct in_addr*)(he->h_addr_list[0]));
	//printf("%s", a);
	i=0;
	char* ip = (char*)malloc(sizeof(char)*128);
	while( a[i] != '\0' )
	{
		ip[i] = a[i]; i++;
	} ip[i] = a[i];
	/*i=0;
	while( ip[i] != 0 )
	{printf("%c\n", ip[i] ); i++;}*/
	return ip;
}

/* function that does actual processing of packets */
void* worker_function( void* w_thread )
{
	struct worker_thread* w_th = (struct worker_thread *) w_thread;
	short c_id = w_th->connection_id;
	char filename[FILENAME_SIZE], *timestamp;
	struct stat file_stats;
	int i;
	
	//printf("Request %hd\n", ntohs(*(buf + sizeof(short))));
	strcpy( filename, w_th->buf + 3*sizeof(short) );
	//printf( "file %s\n", filename ); 
	
	/* acquire mutex lock on the socket before sending REQUEST_ACK */
	pthread_mutex_lock(&socket_mutex);
	/* fill the REQUEST_ACK packet, then send it */
	fill_packet( c_id, REQUEST_ACK, 0, NULL, w_th->buf );
	if( sendto(server_sock, (void*) (w_th->buf), BUFLEN,  0, 
		(struct sockaddr*) &(w_th->client_sockaddr), sizeof(w_th->client_sockaddr)) == -1 )
		thread_exit_gracefully("REQUEST_ACK not sent");
	/* unlock mutex lock on socket */
	pthread_mutex_unlock(&socket_mutex);

	/* get modified timestamp of file using stat */
	bzero(&file_stats, sizeof(file_stats));
	if (stat(filename,&file_stats) != 0) /* failed to get timestamp*/ 
	{	
		fill_packet( c_id, DONE, 1, NULL, w_th->buf );
		//thread_exit_gracefully("stat failed");
	}
	else
	{
		timestamp = ctime(&(file_stats.st_mtime));
		//printf("timestamp = %s\n", timestamp);

		/* fill DONE packet */
		fill_packet( c_id, DONE, 0, NULL, w_th->buf);
		i=0;
		while( *(timestamp + i) != 0 )
		{
			(w_th->buf)[3*sizeof(short) + i] = *(timestamp + i);
			i++;
		}
	}

	/* acquire mutex lock on socket before sending DONE, then send it */
	pthread_mutex_lock(&socket_mutex);
	if( sendto(server_sock, (void*) (w_th->buf), sizeof(buf), 
		0, (struct sockaddr*) &(w_th->client_sockaddr), sizeof(w_th->client_sockaddr)) == -1 )
		thread_exit_gracefully("DONE not sent");
	/* unlock lock on socket */	
	pthread_mutex_unlock(&socket_mutex);
	
	/* wait till main thread wakes up to receive DONE_ACK */
	pthread_mutex_lock(&(w_th->worker_mutex));
	pthread_cond_wait(&(w_th->worker_cond_var), &(w_th->worker_mutex));
	pthread_mutex_unlock(&(w_th->worker_mutex));
	if(extract_type(w_th->buf)!=DONE_ACK)
	{
		fprintf( stderr, "DONE_ACK not received properly. Exiting" );
	}
	/* make the thread entry free in pool buffer */
	w_th->active = 0;
	pthread_exit(NULL);
}

/* thread pool at disposal of server */
struct worker_thread thread_pool[POOL_SIZE];

