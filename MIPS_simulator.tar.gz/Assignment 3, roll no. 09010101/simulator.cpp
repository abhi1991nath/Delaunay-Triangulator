#include<iostream>
#include<fstream>
#include<string.h>
using namespace std;

int data_mem[1024], inst_mem[1024], reg[32];

class label
{
	public:
	string name;
	int pos;
};

int calc( string& s )
{
	int i,j=1,num=0;
	for( i = s.length()-1; i>=0; i-- )
	{
		num+=(s[i]-48)*j;
		j*=10;
	}
	return num;
}

label label_array[200], label_array_d[200];
int reg_map( string& s)
{
	int i = -2;
	if( s == "$0") i = 0;
   	else if( s == "$at" ) i = 1;
	else if( s == "$v0") i = 2;
 	else if( s == "$v1")  i = 3;
        else if( s == "$a0")  i= 4;
        else if( s == "$a1") i = 5;
        else if( s == "$a2") i = 6;
        else if( s == "$a3") i = 7;
        else if( s == "$t0") i = 8;
        else if( s == "$t1") i = 9;
        else if( s == "$t2") i = 10;
        else if( s == "$t3") i = 11;
        else if( s == "$t4") i = 12;
        else if( s == "$t5") i = 13;
        else if( s == "$t6") i = 14;
        else if( s == "$t7") i = 15;
        else if( s == "$s0") i = 16;
        else if( s == "$s1") i = 17;
        else if( s == "$s2") i = 18;
        else if( s == "$s3") i = 19;
        else if( s == "$s4") i = 20;
        else if( s == "$s5") i = 21;
        else if( s == "$s6") i = 22;
        else if( s == "$s7") i = 23;
        else if( s == "$t8") i = 24;
        else if( s == "$t9") i = 25;
        else if( s == "$k0") i = 26;
        else if( s == "$k1") i = 27;
        else if( s == "$gp") i = 28;
        else if( s == "$sp") i = 29;
        else if( s == "$fp") i = 30;
        else if ( s == "$ra") i = 31;
//	cout << "\nReg " << s << " map " << i << endl;
	return i;
}

int inst_map( string& s )
{
	int i=-2;
	if( s == "add" ) i = 1;
	else if( s == "sub" ) i = 2;
        else if( s == "and" ) i = 3;
        else if( s == "or" ) i = 4;
        else if( s == "slt" ) i = 5;
        else if( s == "lw" ) i = 6;
        else if( s == "sw" ) i = 7;
        else if( s == "beq" ) i = 8;
        else if( s == "j" ) i = 9;
        else if( s == "li" ) i = 10;
        else if( s == "syscall" ) i = 11;
//	cout << "\n Ins " << s << " map " << i << endl;
	return i;
}

void remove_blanks( string& dummy, string& dummy2 )
{
	int i;
	dummy2.clear();
	for( i=0; i<dummy.length(); i++ )
	{
		if( (dummy[i] == ' ') || (dummy[i] == '\t') || (dummy[i] == '\n') ) continue;
		dummy2.append(1, dummy[i]);
	}
} 

void execute( int PC )
{
	reg[0] = 0;
	int a = inst_mem[PC], b = inst_mem[PC + 1], c = inst_mem[PC + 2], d = inst_mem[PC + 3];
	if( a == 1 )
	{
		reg[b] = reg[c] + reg[d];	PC = PC + 4;
		execute(PC);
	}
	if( a == 2 )
        {
                reg[b] = reg[c] - reg[d];       PC = PC + 4;
                execute(PC);
        }
	if( a == 3 )
        {
                reg[b] = reg[c] & reg[d];       PC = PC + 4;
                execute(PC);
        }
	if( a == 4 )
        {
                reg[b] = reg[c] | reg[d];       PC = PC + 4;
                execute(PC);
        }
	if( a == 5 )
        {
                reg[b] = (reg[c] < reg[d]) ? 1 : 0;       PC = PC + 4;
                execute(PC);
        }
	if( a == 6 )
        {
                reg[b] = data_mem[c];       PC = PC + 4;
                execute(PC);
        }
	if( a == 7 )
        {
                data_mem[c] = reg[b];      PC = PC + 4;
                execute(PC);
        }
	if( a == 8 )
        {
                if( reg[b] == reg[c] ) PC = d;
		else PC = PC + 4;
                execute(PC);
        }
	if( a == 9 )
        {
                PC = b;
                execute(PC);
        }
	if( a == 10 )
        {
                reg[b] = c;       PC = PC + 4;
                execute(PC);
        }
	if( a == 11 )
	{
		if( reg[2] == 10 ) cout << "\nProgram terminated\n";
		else
		{
			if( reg[2] == 1 ) 
			{
				cout << reg[4] ;	PC = PC + 4;
				execute(PC);
			}
			else cout << "\nInstruction out of scope. Program terminated incorrectly\n";
		}
	}	
}			

int main()
{
//	int data_mem[1024], inst_mem[1024], reg[32];
	char input_file_name[30], ch;
	string dummy, dummy1, dummy2;
 	int inst_pos = 0, data_pos = 0, j, i, check, k, label_counter = 0, label_counter_d = 0, num;
	cout << "Enter name of assembly file : ";
	cin.getline( input_file_name, 30);
	ifstream input_file;
	input_file.open(input_file_name);
//	while( input_file.eof() != 1 )
	if( input_file.is_open() )
	{
	//	cout << "OK 1, at start, tellg() = \n\n" << input_file.tellg();	
		getline( input_file, dummy );
		remove_blanks(dummy, dummy2);
//		cout << endl << dummy2 << endl;
		dummy.clear();
		while( dummy2 != ".text" )
		{
	//		cout << "OK 2\n";
			getline( input_file, dummy );
			remove_blanks(dummy, dummy2);
		//	cout << endl << dummy2 << endl;
			if( dummy2 == ".text" ) break;
			if( dummy2[0] == '#' ) continue;                  // change for comments
			dummy.clear();
			i=0;
			while( dummy2[i] != ':' ) 
			{	
				dummy1.append( 1, dummy2[i] );
				i++;
			}
			label_array_d[label_counter_d].name.assign( dummy1 );
			label_array_d[label_counter_d].pos = data_pos;
			label_counter_d++;
			dummy1.clear();
			i = i + 6;
			while( (dummy2[i] != '#') && (i < dummy2.length() ) )  //change for comments
			{
				dummy1.append( 1, dummy2[i] ); i++;
			}
			data_mem[data_pos] = calc( dummy1 );
			dummy1.clear(); 
			data_pos++;
		}
		int data_mem_size = data_pos;
//		int inst_pos = 0, j, i, check, k, label_counter=0, num;
		while( input_file.eof()!=1 )	
		{
	//		cout << "OK 3\n";
			getline( input_file, dummy );
			remove_blanks(dummy, dummy2);
			dummy.clear();
			if( (dummy2.length() == 0) || (dummy2[0] == '#') ) continue;    //change for comments
			j=0; check = 0;
			while( (j != dummy2.length()) && (dummy2[j] != '#') )		//change for comments
			{
	//			cout << "OK 6\n";
				if( dummy2[j] == ':' )
				{
					check = 1; break;
				}
				j++;
			}
			if( check == 1 )
			{
	//			cout << "OK 7";
				k = j+1;
				for( i=0; i<k-1; i++ ) dummy1.append( 1, dummy2[i] );
				label_array[label_counter].name.assign( dummy1 );
				label_array[label_counter].pos = inst_pos;
				label_counter++;
				dummy1.clear();
			}
			inst_pos = inst_pos + 4;
		}
	//	cout << "OK 8\n";
		int inst_mem_size = inst_pos;
		input_file.clear();
		input_file.seekg ( 0 );
	//	input_file.seekg ( 1, ios::cur );
	//	cout <<  " \ntellg() = "<< input_file.tellg();
		inst_pos = 0;
	//	cout << "\nOK 9\n";
	//	while( input_file.eof() != 1 )
	//	{
		getline( input_file, dummy );
		remove_blanks(dummy, dummy2);
		dummy.clear();
	//	cout << "\nOK 10-\n";
		while( dummy2.compare(".text") != 0 )
		{
	//		cout << "OK 10\n";
			getline( input_file, dummy );
			remove_blanks(dummy, dummy2);
			dummy.clear();
		}
		dummy1.clear();
		while( input_file.eof() !=1 )
		{
	//		cout << "OK 11\n";
			getline( input_file, dummy );
	//		cout << "strlen" << dummy.length();
			remove_blanks(dummy, dummy2);
		//	cout << "\nIns = " << dummy2 << endl;
			dummy.clear();
	//		cout << "OK mid\n";
//			cout << dummy;
	//		cout << "OK 13";
			if( (dummy2.length() == 0) || (dummy2[0] == '#') ) continue; //change for comments
			j=0; check = 0;
			while( (j != dummy2.length()) && (dummy2[j] != '#') )        //change for comments
			{
	//			cout << "OK 12";
				if( dummy2[j] == ':' ) 
				{
					check = 1; break;
				}
				j++;
			}
			if( check == 1 ) 
			{
				k = j+1; 
			}
			if( check == 0 )  k=0;
			if( (dummy2[k] == 's') && (dummy2[k+1] == 'y') )
			{
				inst_mem[inst_pos] = 11;
				inst_mem[inst_pos + 1] = 0;
				inst_mem[inst_pos + 2] = 0;
				inst_mem[inst_pos + 3] = 0;
				inst_pos = inst_pos + 4;
			}
			else if( dummy2[k] == 'j' )
			{
				inst_mem[inst_pos] = 9;
				i = 0;
				k++;
				while( (k != dummy2.length()) && (dummy2[k] != '#') )   //change for comments
				{
					dummy1.append( 1, dummy2[k] );
					k++; i++;
				}
				for( i=0; i<label_counter; i++ )
				{
					if( dummy1.compare(label_array[i].name) == 0 )
					{
						inst_mem[inst_pos+1] = label_array[i].pos;
						break;
					}
				}
				dummy1.clear();
				inst_pos = inst_pos + 4;
			}
				
			else if( dummy2[k] != 'j' )
			{
				j=k; i=0;
				while( (j < dummy2.length()) && (dummy2[j] != '$') && (dummy2[j] != '#') )    // might be a source of trouble
				{									// change for comments
					dummy1.append( 1,dummy2[j] ); j++; i++;
				} 
		//		cout << "\nMnemonics = " << dummy1 << endl;
				inst_mem[inst_pos] = inst_map(dummy1);
				// cout << inst_mem[inst_pos] << endl;
	/*		if( dummy1 == "syscall" )
				{
					dummy1.clear();
					inst_mem[inst_pos + 1] = 0;
					inst_mem[inst_pos + 2] = 0;
					inst_mem[inst_pos + 3] = 0;
				}*/
				if( dummy1.compare( "syscall" ) != 0 )
				{
					dummy1.clear();
					i=0;
					while( dummy2[j] != ',' )              // 1st argument
					{
						dummy1.append(1, dummy2[j]); i++; j++;
					} 
					inst_mem[inst_pos+1] = reg_map(dummy1);
					dummy1.clear();
					if( (inst_mem[inst_pos] != 6) && (inst_mem[inst_pos]!=7) && (inst_mem[inst_pos]!=10) )
					{
						i=0; j++;
						while( dummy2[j] != ',' )       // 2nd argument
						{
							dummy1.append(1,dummy2[j]); i++; j++;
						} 
						inst_mem[inst_pos + 2] = reg_map(dummy1);
						dummy1.clear();
						if( inst_mem[inst_pos] != 8 ) 
						{
							i=0; j++;		// 3rd argument for R-type
							while( (j < dummy2.length()) && ( dummy2[j] != '#') )  //change for comments
							{
								dummy1.append(1,dummy2[j]); i++; j++;
							} 
							inst_mem[inst_pos + 3] = reg_map(dummy1);
							dummy1.clear();
						}
						else
						{
							i=0; j++; 		// 3rd argument for I-type ( beq )
							while( (j < dummy2.length()) && ( dummy2[j] != '#' ) ) //change for comments
							{
								dummy1.append(1,dummy2[j]); i++; j++;
							} 
							for( i=0; i< label_counter; i++ )
							{
								if( dummy1.compare(label_array[i].name) == 0 )
								{
									inst_mem[inst_pos + 3] = label_array[i].pos;
									break;
								}
							}
							dummy1.clear();
						}
					}
					if( (inst_mem[inst_pos] == 6) || (inst_mem[inst_pos] == 7) )
					{
						i=0; j++;
						while( ( j< dummy2.length() ) && (dummy2[j] != '#') )
						{
							dummy1.append(1, dummy2[j]);
							i++; j++;
						}
						for( i=0; i< data_mem_size; i++ )
						{
							if( dummy1.compare(label_array_d[i].name) == 0 )
							{
								inst_mem[inst_pos + 2] = label_array_d[i].pos;
								break;
							}
						}	
						dummy1.clear();		
					}
					if(inst_mem[inst_pos] == 10)
					{
						i=0; j++;
						while( (j < dummy2.length()) && (dummy2[j] != '#') ) //change for comments
						{
							dummy1.append(1, dummy2[j]);
							i++; j++;
						}
						inst_mem[inst_pos + 2] = calc(dummy1);
						dummy1.clear();
					}
							
				}
				inst_pos = inst_pos + 4;			
			}		
		}			
		input_file.close();
/*		cout << "\nInstruction memory\n";
		for( i=0; i< inst_mem_size; i++ )
		{
			cout << inst_mem[i]; cout << "  ";
			if( (i+1)%4 == 0 ) cout << endl;
		}*/
		cout << "\n\n";
		execute(0);
	}
	else cout << "File does not exist.";
	return 0;
}
