from pprint import pprint as pp
from glob import glob
from collections import Counter
import pickle
try: reduce
except: from functools import reduce
try:    raw_input
except: raw_input = input
 

 
def termsearch(terms): # Searches simple inverted index
    if not set(terms).issubset(words):
        return set()
    return reduce(set.intersection,
                  (set(x[0] for x in txtindx)
                   for term, txtindx in unpickledlist.items()
                   if term in terms),
                  set(texts.keys()) )

def phrasesearch(phrase):
    wordsinphrase = phrase.strip().strip('"').split()
    if not set(wordsinphrase).issubset(words):
        return set()
    #firstword, *otherwords = wordsinphrase # Only Python 3
    firstword, otherwords = wordsinphrase[0], wordsinphrase[1:]
    found = []
    for txt in termsearch(wordsinphrase):
        # Possible text files
        for firstindx in (indx for t,indx in unpickledlist[firstword]
                          if t == txt):
            # Over all positions of the first word of the phrase in this txt
            if all( (txt, firstindx+1 + otherindx) in unpickledlist[otherword]
                    for otherindx, otherword in enumerate(otherwords) ):
                found.append(txt)
    return found

unpicklefile = open('index.txt', 'r')
unpickle_textfile = open('text_list.txt', 'r')
unpickle_wordfile = open('word_list.txt', 'r')
# now load the list that we pickled into a new object
unpickledlist = pickle.load(unpicklefile)
texts = pickle.load(unpickle_textfile)
words = pickle.load(unpickle_wordfile)
unpickle_wordfile.close()
unpickle_textfile.close()
unpicklefile.close()

'''terms = ["is"]
print('\nTerm Search for: ' + repr(terms))
pp(orted(termsearch(terms)))'''

phrase = '"is abhinandan"'
print('\nPhrase Search for: ' + phrase)
phrase_ans = phrasesearch(phrase)
for x in phrase_ans:
    print x

#print(ans)
#ans = Counter(ans)
#print('  The phrase is found most commonly in text: ' + repr(ans.most_common(1)[0][0]))

terms = ["is", "abhinandan" ]
ans = termsearch(terms)
print('\nTerm Search on full inverted index for: ' + repr(terms))
for x in sorted(ans):
    if x in phrase_ans:
        pass
    else:
        print x


