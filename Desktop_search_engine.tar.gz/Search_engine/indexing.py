from pprint import pprint as pp
from glob import glob
from collections import Counter
import pickle
import string
try: reduce
except: from functools import reduce
try:    raw_input
except: raw_input = input

def is_punct_char(char):
     '''check if char is punctuation char'''
     if char in string.punctuation:
         return 1
     else:
         return 0

 
def is_not_punct_char(char):
     '''check if char is not punctuation char'''
     return not is_punct_char(char)
 

def parsetexts(fileglob='corpus\*.txt'):
    texts, words = {}, set()
    new_string = ''
    for txtfile in glob(fileglob):
        with open(txtfile, 'r') as f:
            new_string = ''
            for char in f.read().lower():
                if is_not_punct_char(char):
                    new_string = new_string+char
            txt = new_string.split()
            words |= set(txt)
            texts[txtfile.split('\\')[-1]] = txt
    return texts, words

texts, words = parsetexts()
print "texts" ,texts
print "words", words

finvindex = {word:set((txt, wrdindx)
                      for txt, wrds in texts.items()
                      for wrdindx in (i for i,w in enumerate(wrds) if word==w)
                      if word in wrds)
             for word in words}

index_file = open("index.txt", 'w' )
pickle.dump(finvindex,index_file)
print('\nFull Inverted Index')
pp({k:sorted(v) for k,v in finvindex.items()})
index_file.close()


word_file = open("word_list.txt", "w" )
text_file = open("text_list.txt", "w" )
pickle.dump(words,word_file)
pickle.dump(texts,text_file)
text_file.close()
word_file.close()
