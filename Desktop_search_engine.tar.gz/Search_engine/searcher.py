from pprint import pprint as pp
from glob import glob
from collections import Counter
import pickle
try: reduce
except: from functools import reduce
try:    raw_input
except: raw_input = input
import string
import parameters
from math import sqrt

def avg(data):
    sum = 0
    for x in data :
        sum += x
    mean = (1.0*sum)/len(data)
    return mean

def variance(data):
    mean = avg(data)
    var = 0
    for x in data :
        var += 1.0*(x-mean)**2
    var = (1.0*var)/len(data)
    return sqrt(var)

def avg_index(array, value):
    i = 0
    array1 = []
    for x in array:
        if x == value:
            array1.append(i)
        i += 1
    return avg(array1)

def termsearch(terms): # Searches simple inverted index
    if not set(terms).issubset(words):
        return set()
    return reduce(set.intersection,
                  (set(x[0] for x in txtindx)
                   for term, txtindx in unpickledlist.items()
                   if term in terms),
                  set(texts.keys()) )

def termsearch_ranked(terms):
    ans = termsearch(terms)
    a = sorted(ans)
    rank_dict = {}
    for files in a:
        rank = 0
        for tokens in terms:
             #min = texts[files].index(tokens)
             #texts[files].reverse()
             #max = len(texts[files]) - texts[files].index(tokens) -1
             #texts[files].reverse()
             rank = rank + texts[files].count(tokens)*parameters.freq
             #if max > global_max:
              #   rank = rank + parameters.rank
             #global_max = min
        rank_dict[files] = rank;
    return sorted(rank_dict, key=rank_dict.__getitem__, reverse=True)

def phrasesearch(phrase):
    wordsinphrase = phrase.strip().strip('"').split()
    if not set(wordsinphrase).issubset(words):
        return set()
    #firstword, *otherwords = wordsinphrase # Only Python 3
    firstword, otherwords = wordsinphrase[0], wordsinphrase[1:]
    found = []
    for txt in termsearch(wordsinphrase):
        # Possible text files
        for firstindx in (indx for t,indx in unpickledlist[firstword]
                          if t == txt):
            # Over all positions of the first word of the phrase in this txt
            if all( (txt, firstindx+1 + otherindx) in unpickledlist[otherword]
                    for otherindx, otherword in enumerate(otherwords) ):
                found.append(txt)
    return found

def ranked_terms(terms):
    ans = termsearch(terms)
    a = sorted(ans)
    variance_list = []
    for files1 in a:
        mean_arr1 = []
        for tokens in terms:
             mean_arr1.append(avg_index(texts[files1], tokens))
        variance_list.append(variance(mean_arr1))
    #print "Variance_list" , max(variance_list)
    rank_dict = {}
    for files in a:
        rank = 0
        global_max = -1
        mean_arr = []
        for tokens in terms:
             mean_arr.append(avg_index(texts[files], tokens))
             Min = texts[files].index(tokens)
             texts[files].reverse()
             Max = len(texts[files]) - texts[files].index(tokens) -1
             texts[files].reverse()
             rank = rank + texts[files].count(tokens)*parameters.freq
             if Max > global_max:
                 rank = rank + parameters.order
             global_max = Min
        if not max(variance_list) == 0:   
            rank -= (variance(mean_arr)*parameters.variance*(1.0))/max(variance_list)
        rank_dict[files] = rank;
    return sorted(rank_dict, key=rank_dict.__getitem__, reverse=True)

def is_punct_char(char):
     '''check if char is punctuation char'''
     if char in string.punctuation:
         return 1
     else:
         return 0

 
def is_not_punct_char(char):
     '''check if char is not punctuation char'''
     return not is_punct_char(char)
    
def trim(a):
    stop_words = ['a', 'an', 'and', 'are', 'as', 'at', 'be', 'by', 'for', 'from', 'has', 'he', 'is', 'in', 'its', 'it', 'of', 'on', 'that', 'the', 'to', 'was', 'where', 'will', 'with']
    new_string = ''
    return_string = ''
    for char in a.lower():
        if is_not_punct_char(char):
             new_string = new_string+char
        else:
             new_string = new_string + ' '
    #print new_string
    y = new_string
    new_string = new_string.split()
    #print new_string
    for word in new_string:
        if word in stop_words:
            continue
        return_string = return_string + word + " "
    return_string = return_string[0:len(return_string)-1]
    return y , return_string

unpicklefile = open('index.txt', 'r')
unpickle_textfile = open('text_list.txt', 'r')
unpickle_wordfile = open('word_list.txt', 'r')
# now load the list that we pickled into a new object
unpickledlist = pickle.load(unpicklefile)
texts = pickle.load(unpickle_textfile)
words = pickle.load(unpickle_wordfile)
unpickle_wordfile.close()
unpickle_textfile.close()
unpicklefile.close()

'''terms = ["is"]
print('\nTerm Search for: ' + repr(terms))
pp(orted(termsearch(terms)))'''
