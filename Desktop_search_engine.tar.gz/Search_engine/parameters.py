order = 5
freq = 0.3
variance = 100
