import sys, pickle, os, re, collections
from PyQt4 import QtCore, QtGui
import search_engine, spell_check
import searcher

class MyForm(QtGui.QMainWindow):
    def __init__(self, parent=None):
        QtGui.QWidget.__init__(self, parent)
        self.ui = search_engine.Ui_Form()
        self.ui.setupUi(self)
        self.connect(self.ui.pushButton, QtCore.SIGNAL("pressed()"), self.back)
        self.connect(self.ui.lineEdit, QtCore.SIGNAL("textChanged(QString)"), self.search)
        #self.connect(self.ui.textBrowser, QtCore.SIGNAL("backwardAvailable()"), QtCore.SLOT('backward()'))
        # self.connect(self.ui.lineEdit, QtCore.SIGNAL("returnPressed()"), self.ui.textBrowser.backward)
        #self.connect(self.ui.textBrowser, QtCore.SIGNAL("linkClicked()"), self.back)

    def back(self):
         self.ui.lineEdit.insert(' ')

    def search(self):
      self.ui.textBrowser.clear()
      self.ui.textBrowser.clearHistory()
      if len(str(self.ui.lineEdit.text())) == 0:
          self.ui.textBrowser.append("<p>Enter search string</p>")
      if len(str(self.ui.lineEdit.text())) > 0:
        word = str(self.ui.lineEdit.text())
        word, phrase =  searcher.trim(word)
        terms = phrase.split()
        dummy = ''
        dummy1 = ''
        dummy2 = ''
        i = 0
        check = 0
        self.ui.textBrowser.append("<p>Searching for: " + phrase +"</p>")
        if len(terms) >1:
            phrase_ans = searcher.phrasesearch(phrase)
            for x in phrase_ans:
                 self.ui.textBrowser.append("<a href ='"+x+"'>"+x+"</a>")        
            for x in searcher.ranked_terms(terms):
                if x in phrase_ans:
                    pass
                else:
                    self.ui.textBrowser.append("<a href ='"+x+"'>"+x+"</a>")
        if len(terms) == 1:
            for x in searcher.termsearch_ranked(terms):
                self.ui.textBrowser.append("<a href ='"+x+"'>"+x+"</a>")
        while (i < len(word) ):
            if word[i] != ' ':
                dummy = dummy + word[i]
            if word[i] == ' ' or i == (len(word) - 1):
                dummy2 = spell_check.correct(dummy)
                if dummy2 != dummy :
                    check = 1
                dummy1 = dummy1 + dummy2
                if i != (len(word) - 1) :
                    dummy1 += ' '
                dummy = ''
                dummy2 = ''
            i = i+1     
        if check == 1 :
            #self.ui.label_4.setEnabled(True)
            self.ui.textBrowser.append("<p>Did you mean '" + dummy1 + "' ?</p>")
            #self.ui.textBrowser.append(' ')
            dummy1, phrase = searcher.trim(dummy1)
            terms = phrase.split()
            if len(terms) >1:
                phrase_ans = searcher.phrasesearch(phrase)
                for x in phrase_ans:
                     self.ui.textBrowser.append("<a href ='"+x+"' target = '_blank'>"+x+"</a>")        
                for x in searcher.ranked_terms(terms):
                    if x in phrase_ans:
                        pass
                    else:
                       self.ui.textBrowser.append("<a href ='"+x+"' target = '_blank'>"+x+"</a>")
            if len(terms) == 1:
                for x in searcher.termsearch_ranked(terms):
                    self.ui.textBrowser.append("<a href ='"+x+"' target = '_blank'>"+x+"</a>")    
                terms = phrase.split()
            
        else:
            if len(word)!=0:
                self.ui.textBrowser.append("<p>No Spell Check suggestions for '" + dummy1 + "'</p>")
        
if __name__ == "__main__":
  app = QtGui.QApplication(sys.argv)
  myapp = MyForm()
  myapp.show()
  sys.exit(app.exec_())
