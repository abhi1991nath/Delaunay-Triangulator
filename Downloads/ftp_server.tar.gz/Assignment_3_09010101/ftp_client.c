#include "common.c"
#include "ftp_client_header.c"

int main(int argc, char* argv[])
{
	int c_sock, l_sock, d_sock;
	char cmsg[CNTRL_PACKET_LEN];
	short CLIENT_LISTEN_PORT = generate_random_port();
	if( argc != 2 )
	{
		printf("Usage : %s server_ip\n", argv[0] );
		exit(1);
	}
	
	if( (c_sock = socket(AF_INET, SOCK_STREAM, 0)) == -1 )
	{
		perror("client-side control socket failed");
		exit(1);
	}

	struct sockaddr_in server_addr;
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(SERVER_LISTEN_PORT);
	if( inet_aton(argv[1], &(server_addr.sin_addr))==0 ) 
	{
    		fprintf(stderr, "Error in IP address\n");
		exit(1);
	}

	printf("Connecting to server %s ...\n", argv[1]);
	int server_addr_len = sizeof(server_addr);
	
	/* client sending connection request to server on designated listening
	   port of server, here referred to as SERVER_LISTEN_PORT */
	if( connect(c_sock, (struct sockaddr *)&server_addr, server_addr_len)<0 )
	{
		perror("client -> server control connection failed");
		exit(1);
	}

	struct sockaddr_in client_addr;
	client_addr.sin_family = AF_INET;
	client_addr.sin_port = htons(CLIENT_LISTEN_PORT);
	client_addr.sin_addr.s_addr = htonl(INADDR_ANY);

	/* this is FTP in active mode. Control connection is now up.
	   Data connection will be initiated by the server, and so 
	   the client has to listen on a designated 
	   port, here referred to as CLIENT_LISTEN_PORT  */
	if( (l_sock = socket(AF_INET, SOCK_STREAM, 0)) == -1  )
	{
		perror("client listen socket failed");
		exit(1);
	} 
	if( bind(l_sock, (struct sockaddr*)&client_addr, sizeof(client_addr))==-1 )
	{
		perror("bind failed");
		exit(1);
	}
	
	/* client starts listening for data connection request by server */
	if( listen( l_sock, 5 ) == -1 )
	{
		perror("client listen failed");
		exit(1);
	}
	
	fill_control_packet( cmsg, PORT, CLIENT_LISTEN_PORT, NULL );
	/* client sends the server the port on which the client is 
	   listening, so that the server may initiate the data 	
	   connection on the listening port of client */
	if( send( c_sock, (void*) cmsg, CNTRL_PACKET_LEN, 0 ) == -1 )
	{
		perror("send failed");
		exit(1);
	}
	
	/* client accepts data connection request of server */
	if( (d_sock = accept( l_sock, NULL, NULL )) == -1 )
	{
		perror("accept failed");
		exit(1);
	}

	/* stop listening amd close the listening socket, 
	   as the client expects only one data connection from the server */
	close( l_sock );

	/* both the data and control connections are up and running.
	   We can now start the ftp session */	
	start_session_client_side( c_sock, d_sock, cmsg );
	return 0;
}
	
