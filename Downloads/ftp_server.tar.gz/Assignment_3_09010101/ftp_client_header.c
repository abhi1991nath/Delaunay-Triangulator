/* generate a random port no. lying in the range 1025-9999 */
short generate_random_port()
{
	srand( time(NULL) );
	int random = rand();
	random = 1025 + random%(10000-1025);
	if( (short)random == SERVER_LISTEN_PORT ) return generate_random_port(); 	
	return random;
}

/* tokenise a string with delimiters as spaces or tabs */
char** remove_blanks( char* line, int* count )
{
	char *begin = line, *word_begin, *word_end;
	int word_count = 0, i, word_length, j;
	while( (*line) != '\0' )
	{
		if( ((*line) != ' ') && ((*line) != '\t') )
		{
			word_count++;
			while( ((*line) != ' ') && ((*line) != '\t') && ((*line) != '\0') )
				line++;
		}
		else
		{
			while( ((*line) == ' ') || ((*line) == '\t') )
				line++;
		}
	}
	*count = word_count;
	char** words = (char**)malloc(sizeof(char*)*word_count);
	i = 0;
	if( word_count == 0 ) return NULL;
	while( (*begin) != '\0' )
	{
		while( ((*begin) == ' ') || ((*begin) == '\t') )
			begin++;
		if( (*begin) != '\0' )
		{
			word_begin = begin;
			while( ((*begin) != ' ') && ((*begin) != '\t') && ((*begin) != '\0') )
			{
				begin++;
			}
			word_end = begin;
			word_length = (word_end-word_begin)/sizeof(char*);
			words[i] = (char*)malloc(1 + word_length);
 			j = 0;
			while( word_begin != word_end )
			{
				words[i][j] = *(word_begin);
				j++; word_begin++;
			}
			words[i][j] = '\0'; i++;
		}
	}
	/*for( i =0; i< *count; i++ )
		printf("%s ",words[i]);*/
	return words;		
}

/* function for client to receive a file from server 
   d_sock is data socket and c_sock is control socket */
void receive_file_client( FILE* fp, int d_sock, int c_sock, const char* data, const char* cmsg )
{
	int i, c, eof_check = 0;
	while(1)
	{
		//printf("inside while receive file\n");
		memset( data, 0, DATA_PACKET_LEN );
		if( recv( d_sock, data, DATA_PACKET_LEN, 0 ) == -1 )
		{
			perror("recv failed");
			fclose(fp);
			exit(1);
		}
		for( i=0; i<DATA_PACKET_LEN; i++ )
		{
			if( (c=data[i]) == 3)
			{
				eof_check = 1; break;
			}
			//printf("inside receive file %c", data[i]);
			fputc(c, fp); 
		}
		fill_control_packet( cmsg, ACK, 0, NULL );
		if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0) == -1 )
		{
			perror("send failed");
			fclose(fp); exit(1);
		} 
		if( eof_check ) break;
	}
	fclose(fp);
}

/* function for client to send a file to server */
void send_file_client( FILE* fp, int d_sock, int c_sock, char* data, const char* cmsg )
{
	int i, c, eof_check = 0;
	//printf("get file pos %ld\n", ftell(fp));
	while(1)
	{
		//printf("while send file\n");
		memset( data, 0, DATA_PACKET_LEN );
		for( i=0; i<DATA_PACKET_LEN; i++ )
		{
			//printf("inside for");
			if( (c=fgetc(fp)) == EOF )
			{
				//printf("inside EOF\n");
				data[i] = 3; /*ascii value of ETX is 3 */
				eof_check = 1; break;
			}
			data[i] = (char)c;	
			//printf("inside send file %c", data[i]);
		}
		if( send( d_sock, data, DATA_PACKET_LEN, 0 ) == -1 )
		{
			perror("send failed");
			fclose(fp);
			exit(1);
		} 
		memset( data, 0, DATA_PACKET_LEN );
		if( recv( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1 )
		{
			perror("recv failed");
			fclose(fp);
			exit(1);
		}
		if( get_cntrl_packet_type(cmsg) != ACK ) 
		{
			printf("file transfer failed");
			fclose(fp); return;
		}
		if( eof_check ) break;
	}
	fclose(fp);	
}

void execute_command( char* command, int c_sock, int d_sock, const char* cmsg )
{
	int word_count, error;
	char** com_frag;
	short type;
	char data[DATA_PACKET_LEN];
	short info; int i;
	char output[50];
	FILE* fp;
	char temp[500];
	struct dirent *entry;
	com_frag = remove_blanks( command, &word_count );
	DIR *dirp;
	if( word_count == 0 )
	{
		collect_garbage( com_frag, word_count );
		return;
	}
	else if( (strcmp( com_frag[0], "rput" ) == 0) && (word_count == 2) )
	{
		if( is_directory(com_frag[1]) )
		{
			rput_client( com_frag[1], NULL, c_sock, d_sock, cmsg );
			collect_garbage( com_frag, word_count );
		}
		else
		{
			printf("Cannot put %s : not a directory\n", com_frag[1]);
			collect_garbage( com_frag, word_count );
			return;
		}
	}
	else if( (strcmp( com_frag[0], "rget" ) == 0) && (word_count == 2) )
	{
		fill_control_packet( cmsg, RGET, 0, com_frag[1] );
		if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1)
		{
			perror("send failed");
			collect_garbage( com_frag, word_count );
			exit(1);
		}
		memset( cmsg, 0, CNTRL_PACKET_LEN );
		if( recv( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1 )
		{
			perror("receive failed");
			collect_garbage( com_frag, word_count );
			exit(1);
		}
		type = get_cntrl_packet_type( cmsg );
		if( type != ACK )
		{
			printf("Command failed\n");
			collect_garbage( com_frag, word_count );
			return;
		}
		rget_client( com_frag[1], NULL, c_sock, d_sock, cmsg );
		collect_garbage( com_frag, word_count );	
	}
	else if( (strcmp( com_frag[0], "pwd" ) == 0) && (word_count==1) )
	{
		fill_control_packet( cmsg, PWD, 0, NULL );
		if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1)
		{
			perror("send failed");
			collect_garbage( com_frag, word_count );
			exit(1);
		}
		memset( cmsg, 0, CNTRL_PACKET_LEN );
		if( recv( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1 )
		{
			perror("receive failed");
			collect_garbage( com_frag, word_count );
			exit(1);
		}
		type = get_cntrl_packet_type( cmsg );
		if( type != ACK )
		{
			printf("Command failed\n");
			collect_garbage( com_frag, word_count );
			return;
		}
		printf("%s\n", cmsg + 2*sizeof(short) );
		return;
	}
	else if( (strcmp( com_frag[0], "lpwd" ) == 0) && (word_count==1) )
	{
		if( getcwd( temp, 500 ) )
			printf("%s\n", temp );
		else printf("lpwd failed\n");
		return;
	} 
	else if( (strcmp( com_frag[0], "quit" ) == 0) && (word_count==1) )
	{
		collect_garbage( com_frag, word_count );
		fill_control_packet( cmsg, FIN, 0, NULL ); 
		send( c_sock, cmsg, CNTRL_PACKET_LEN, 0 );
		close(c_sock); close(d_sock);
		printf("Good Bye ...\n");
		exit(0);
	}
	else if( (strcmp( com_frag[0], "help" ) == 0) && (word_count==1) )
	{
		collect_garbage( com_frag, word_count );
		printf("\t****************************************HELP MENU******************************************************\n");
		printf("\tquit : logout and close program\n");
		printf("\thelp : display this help menu\n");
		printf("\tpwd : display server current directory\n");
		printf("\tlpwd : display client current directory\n");
		printf("\tcd <path> : change server current directory to that specified by <path>\n");
		printf("\tlcd <path> : change local current directory to that specified by <path>\n");
		printf("\t\tNOTE : please do not use . and .. in <path>, it will lead to program error\n");
		printf("\t\tNOTE : spaces not allowed in <path>\n");
		printf("\tdir : show contents of server current directory\n");
		printf("\tldir : show contents of local current directory\n");
		printf("\tget <file> : get <file> from server current directory to client current directory\n");
		printf("\tput <file> : put <file> from client current directory to server current directory\n");
		printf("\tmget <file1> <file2> ... : get multiple files from server current directory to client current directory\n");
		printf("\tmput <file1> <file2> ... : put multiple files from client current directory to server current directory\n");
		printf("\t\tNOTE : mget and mput also have wildcard support\n");
		printf("\trget <directory_name> : recursively get a directory and all its contents from server current directory\n");
		printf("\t		          to client current directory\n");
		printf("\trput <directory_name> : recursively put a directory and all its contents from client current directory\n");
		printf("\t		          to server current directory\n");
		printf("\t*******************************************************************************************************\n");
		return;
	}
	else if( (strcmp( com_frag[0], "cd" ) == 0) && (word_count==2) )
	{
		fill_control_packet( cmsg, CD, 0, com_frag[1] );
		if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1 )
		{
			perror("send failed");
			collect_garbage( com_frag, word_count );
			exit(1);
		}
		memset( cmsg, 0, CNTRL_PACKET_LEN );
		if( recv( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1 )
		{
			perror("recv failed");
			collect_garbage( com_frag, word_count );
			exit(1);
		}
		type = get_cntrl_packet_type(cmsg);
		//printf( "%d", type);
		if( type != ACK ) printf("Error : cannot change directory\n");
		collect_garbage( com_frag, word_count ); 
		return;
	}	
	else if( (strcmp( com_frag[0], "lcd" ) == 0) && (word_count==2) )
	{
		if( error = chdir( com_frag[1] ) ) perror("error : ");
		collect_garbage( com_frag, word_count );
		return;
	}
	else if( (strcmp( com_frag[0], "dir" ) == 0) && (word_count==1) )
	{
		collect_garbage( com_frag, word_count );
		fill_control_packet( cmsg, LS, 0, NULL );
		if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0) == -1 )
		{
			perror("send failed");
			exit(1);
		}
		memset( cmsg, 0, CNTRL_PACKET_LEN );
		if( recv( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1 )
		{
			perror("recv failed");
			exit(1);
		}
		type = get_cntrl_packet_type(cmsg);
		if( type != ACK ) 
		{
			printf("Error : cannot display directory contents\n");
			return;
		}
		//char data[DATA_PACKET_LEN];
		//short info; int i;
		memcpy( (void*)&info, (void*)(cmsg+sizeof(short)), sizeof(short) );
		info = ntohs(info);
		//printf("Client info %d\n", info);
		for( i = 0; i<info; i++ )
		{
			memset( data, 0, DATA_PACKET_LEN );
			if( recv( d_sock, data, DATA_PACKET_LEN, 0 ) == -1 )
			{
				perror("recv failed");
				//collect_garbage( com_frag, word_count );
				exit(1);
			}
			printf("%s\n", data);
		}
		return;
	}
	else if( (strcmp( com_frag[0], "ldir" ) == 0) && (word_count==1) )
	{
		/*char output[50];
		FILE**/
		memset(output, 0, 50);
		if(fp = popen( "ls", "r"))
		{
			while( fgets( output, 50, fp) )
			{
				printf("%s", output);
			}
			pclose(fp);
		}
		else printf("Cannot display contents\n");
		collect_garbage( com_frag, word_count );
		return;
	}
	else if( (strcmp( com_frag[0], "get" ) == 0) && (word_count==2) )
	{
		/*FILE* fp; char data[DATA_PACKET_LEN];*/
		fill_control_packet( cmsg, GET, 0, com_frag[1] );
		if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0) == -1 )
		{
			perror("send failed");
			collect_garbage( com_frag, word_count );
			exit(1);
		}
		memset( cmsg, 0, CNTRL_PACKET_LEN );
		if( recv( c_sock, cmsg, CNTRL_PACKET_LEN, 0) == -1 )
		{
			perror("recv failed");
			collect_garbage( com_frag, word_count );
			exit(1);
		}
		type = get_cntrl_packet_type( cmsg );
		if( type != ACK )
		{
			printf("Error: Could not get file\n");
			collect_garbage( com_frag, word_count );
			return;
		}
		if( !(fp = fopen( com_frag[1], "w" )) )
		{
			perror("GET failed");
			collect_garbage( com_frag, word_count );
			return;
		}
		//printf("before calling receive file\n");
		memset( data, 0, DATA_PACKET_LEN );
		receive_file_client( fp, d_sock, c_sock, data, cmsg );
		collect_garbage( com_frag, word_count ); 
	}
	else if( (strcmp( com_frag[0], "mget" ) == 0) && (word_count >= 2) )
	{
		//int i;
		//char temp[500];
		memset( temp, 0,500);
		if( is_wildcard( com_frag[1] ) && (word_count == 2) )
		{
			fill_control_packet( cmsg, MGET_W, 0, com_frag[1] );
			if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0) == -1 )
			{
				perror("send failed");
				collect_garbage( com_frag, word_count );
				exit(1);
			}
			memset( cmsg, 0, CNTRL_PACKET_LEN );
			if( recv( c_sock, cmsg, CNTRL_PACKET_LEN, 0) == -1 )
			{
				perror("recv failed");
				collect_garbage( com_frag, word_count );
				exit(1);
			}
			type = get_cntrl_packet_type( cmsg );
			if( type != ACK )
			{
				printf("Error: Could not get files\n");
				collect_garbage( com_frag, word_count );
				return;
			}
			strcpy( temp, "mget " );
			strcat( temp, cmsg + 2*sizeof(short) );
			execute_command( temp, c_sock, d_sock, cmsg );
		}
		else
		{
			for( i=1; i<word_count; i++ )
			{
				memset( temp, 0, 500 );
				strcpy( temp, "get " );
				strcat( temp, com_frag[i] );	
				execute_command( temp, c_sock, d_sock, cmsg ); 
			}
		}
		collect_garbage( com_frag, word_count ); 
	}
	/*else if( (strcmp( com_frag[0], "rget" ) == 0) && (word_count == 2) )
	{
		fill_control_packet( cmsg, RGET, 0, com_frag[1] );
		if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0) == -1 )
		{
			perror("send failed");
			exit(1);
		}
		memset( cmsg, 0, CNTRL_PACKET_LEN );
		if( recv( c_sock, cmsg, CNTRL_PACKET_LEN, 0) == -1 )
		{
			perror("recv failed");
			exit(1);
		}
		type = get_cntrl_packet_type( cmsg );
		if( type != ACK )
		{
			printf("Error: Could not get directory\n");
			return;
		}
		char temp[500];
		strcpy( temp, "get ");
		strcpy( temp, cmsg + 2*sizeof(short));
		execute_command( temp, c_sock, d_sock, cmsg);
	}*/
	else if( (strcmp( com_frag[0], "put" ) == 0) && (word_count==2) )
	{
		//FILE *fp; char data[DATA_PACKET_LEN];
		if( is_directory( com_frag[1] ) )
		{
			printf("PUT failed : Check if %s exists or is a regular file\n", com_frag[1]);
			collect_garbage( com_frag, word_count );
			return;
		}
		if( !(fp = fopen( com_frag[1], "r" )) )
		{
			//printf("%s\n", com_frag[1]);
			perror("PUT failed");
			collect_garbage( com_frag, word_count );
			return;
		}
		fill_control_packet( cmsg, PUT, 0, com_frag[1] );
		if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0) == -1 )
		{
			perror("send failed");
			collect_garbage( com_frag, word_count );
			exit(1);
		}
		memset( cmsg, 0, CNTRL_PACKET_LEN );
		if( recv( c_sock, cmsg, CNTRL_PACKET_LEN, 0) == -1 )
		{
			perror("recv failed");
			collect_garbage( com_frag, word_count );
			exit(1);
		}
		type = get_cntrl_packet_type( cmsg );
		if( type != ACK )
		{
			printf("Error: Could not put file\n");
			collect_garbage( com_frag, word_count );
			return;
		}
		memset( data, 0, DATA_PACKET_LEN);
		send_file_client( fp, d_sock, c_sock, data, cmsg );
		collect_garbage( com_frag, word_count );
	}
	else if( (strcmp( com_frag[0], "mput" ) == 0) && (word_count >= 2) )
	{
		//int i;
		//char temp[500];
		memset(temp, 0, 500);
		if( is_wildcard(com_frag[1]) && (word_count == 2) )
		{
			//DIR *dirp;
			if( dirp = opendir( "./" ) )
			{
				//struct dirent *entry;
				strcpy( temp, "mput " );
				while( entry = readdir(dirp) )
				{
					if( (entry->d_type == DT_REG) && (wildcard(entry->d_name,com_frag[1])) )
					{	
						strcat( temp, " ");
						strcat( temp, entry->d_name );
					}
				}
				//printf("temp %s\n", temp);
				execute_command( temp, c_sock, d_sock, cmsg );
			}
	
		}
		else
		{
			for( i=1; i<word_count; i++ )
			{
				memset( temp, 0, 500 );
				strcpy( temp, "put " );
				strcat( temp, com_frag[i] );	
				execute_command( temp, c_sock, d_sock, cmsg ); 
			}
		}
		collect_garbage( com_frag, word_count ); 
	}
	else printf("Wrong command.\nType 'help' to get a list of available commands\n");
}

/* function for client to recursively put a directory to server */
void rput_client( const char* file, const char* prefix, int c_sock, int d_sock, const char* cmsg )
{
	char path[300];
	if( prefix != NULL )
	{
		strcpy( path, prefix );
		strcat( path, file );	
	}
	else strcpy( path, file );
	if( is_directory( path ) )
	{
		fill_control_packet( cmsg, RPUT, 0, path );
		if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1 )
		{
			perror("send failed");
			exit(1);
		}
		memset( cmsg, 0, CNTRL_PACKET_LEN );
		if( recv( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1 )
		{
			perror("recv failed");
			exit(1);
		}
		if( get_cntrl_packet_type(cmsg) == ACK )
		{
			DIR* dirp; struct dirent* entry;
			if(dirp = opendir(path))
			{
				strcat( path, "/" );
				while( entry = readdir(dirp) )
				{
					if( (strcmp(entry->d_name, ".") != 0) && (strcmp(entry->d_name, "..")!=0) )
					{
						rput_client( entry->d_name, path, c_sock, d_sock, cmsg );  	
					}
				}
				closedir( dirp );
			}
			else
			{
				printf("RPUT failed\n"); return;
			}
		}
		else
		{
			printf("RPUT failed\n");
			return;
		}
	}
	else
	{
		char command[300]; 
		strcpy( command, "put ");
		strcat( command, path );
		execute_command( command, c_sock, d_sock, cmsg );	
	}
}

/* function for client to recursively get a directory from server */
void rget_client( const char* file, const char* prefix, int c_sock, int d_sock, const char* cmsg )
{
	//printf("Inside rget %s", file);
	char path[300];
	if( prefix != NULL )
	{
		strcpy( path, prefix );
		strcat( path, "/" );
		strcat( path, file );
	}
	else strcpy( path, file );
	fill_control_packet( cmsg, RGET, 0, path );
	if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0) == -1 )
	{
		perror("send failed");
		//collect_garbage( com_frag, word_count );
		exit(1);
	}
	memset( cmsg, 0, CNTRL_PACKET_LEN );
	if( recv( c_sock, cmsg, CNTRL_PACKET_LEN, 0) == -1 )
	{
		perror("recv failed");
		//collect_garbage( com_frag, word_count );
		exit(1);
	}
	if( get_cntrl_packet_type(cmsg) == ACK )
	{
		mode_t process_mask = umask(0); int count;int i;
		char** list = remove_blanks( cmsg + 2*sizeof(short), &count );
		if( mkdir(path, S_IRWXU | S_IRWXG | S_IRWXO) == -1 )
		{
			perror("RGET failed ");umask(process_mask);
			collect_garbage( list, count );
 			return;
		}
		umask( process_mask );
		strcat( path, "/" );
		//printf("here %s", cmsg + 2*sizeof(short) );
		for( i = 0; i<count; i++ )
		{
			//printf("%s\n", list[i]);
			if( (strcmp( list[i], ".." ) != 0) && (strcmp(list[i],".")!=0) )
				rget_client( list[i], path, c_sock, d_sock, cmsg );
		}
		collect_garbage( list, count );
	}
	else
	{
		char command[300]; strcpy( command, "get " );
		strcat( command, path ); 
		execute_command( command, c_sock, d_sock, cmsg );
	}
}

void start_session_client_side( int c_sock, int d_sock, const char* cmsg )
{
	printf("*****************************************************\n");
	printf("*        Welcome to Abhinandan's ftp server         *\n");
	printf("*  Type 'help' to get a list of available commands  *\n");
	printf("*****************************************************\n\n\n> ");
	char command[500];
	while(1)
	{
		gets(command);
		execute_command(command, c_sock, d_sock, cmsg);
		printf("> ");
		memset( command, 0, 500 );
	}
}
