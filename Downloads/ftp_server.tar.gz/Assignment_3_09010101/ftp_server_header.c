/* default current directory at server side
   Only relative path is allowed as value for default_dir */
char default_dir[] = "ftp/";

struct client_info
{
	int control_socket;
	struct sockaddr_in client_addr;
};

/* function for server to send file to client */
void send_file_server( FILE* fp, int d_sock, int c_sock, char* data, const char* cmsg )
{
	int i, c, eof_check = 0;
	//printf("get file pos %ld\n", ftell(fp));
	while(1)
	{
		//printf("while send file\n");
		memset( data, 0, DATA_PACKET_LEN );
		for( i=0; i<DATA_PACKET_LEN; i++ )
		{
			//printf("inside for");
			if( (c=fgetc(fp)) == EOF )
			{
				//printf("inside EOF\n");
				data[i] = 3; /*ascii value of ETX is 3 */
				eof_check = 1; break;
			}
			data[i] = (char)c;	
			//printf("inside send file %c", data[i]);
		}
		if( send( d_sock, data, DATA_PACKET_LEN, 0 ) == -1 )
		{
			perror("send failed");
			fclose(fp);
			pthread_exit(NULL);
		} 
		memset( data, 0, DATA_PACKET_LEN );
		if( recv( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1 )
		{
			perror("recv failed");
			fclose(fp);
			pthread_exit(NULL);
		}
		if( get_cntrl_packet_type(cmsg) != ACK ) 
		{
			printf("file transfer failed");
			fclose(fp); return;
		}
		if( eof_check ) break;
	}
	fclose(fp);	
}

/* function for server to receive file from client */
void receive_file_server( FILE* fp, int d_sock, int c_sock, const char* data, const char* cmsg )
{
	int i, c, eof_check = 0;
	while(1)
	{
		//printf("inside while receive file\n");
		memset( data, 0, DATA_PACKET_LEN );
		if( recv( d_sock, data, DATA_PACKET_LEN, 0 ) == -1 )
		{
			perror("recv failed");
			fclose(fp);
			pthread_exit(NULL);
		}
		for( i=0; i<DATA_PACKET_LEN; i++ )
		{
			if( (c=data[i]) == 3)
			{
				eof_check = 1; break;
			}
			//printf("inside receive file %c", data[i]);
			fputc(c, fp); 
		}
		fill_control_packet( cmsg, ACK, 0, NULL );
		if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0) == -1 )
		{
			perror("send failed");
			fclose(fp); pthread_exit(NULL);
		} 
		if( eof_check ) break;
	}
	fclose(fp);
}

void start_session_server_side( int c_sock, int d_sock, const char* cur_dir, const char* cmsg )
{
	short type, info;
	char extra[CNTRL_PACKET_LEN];
	FILE* fp; char data[DATA_PACKET_LEN];
	char file_name[256];
	DIR *dirp;
	struct dirent *entry;
	struct stat temp;
	char pattern[CNTRL_PACKET_LEN];
	while(1)
	{
		//printf("Current dir : %s\n", cur_dir);
		memset( cmsg, 0, CNTRL_PACKET_LEN );
		if( recv( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1 )
		{
			perror("recv failed");
			pthread_exit(NULL);
		}
		type = get_cntrl_packet_type( cmsg );
		if( type == FIN )
		{
			close(c_sock); close(d_sock);
			//printf("bye\n");
			pthread_exit(NULL);
		}
		else if( type == RPUT )
		{
			mode_t process_mask = umask(0);
			strcpy( extra, cur_dir );
			strcat( extra, cmsg + 2*sizeof(short) );
			//printf("dir %s\n", extra);
			if( mkdir(extra, S_IRWXU | S_IRWXG | S_IRWXO) == -1 )
			{
				perror("RPUT failed");
				//printf("\n %s", cmsg + 2*sizeof(short));
				umask(process_mask);
				fill_control_packet( cmsg, NACK, 0, NULL );
			}
			else
			{
				umask(process_mask);
				fill_control_packet( cmsg, ACK, 0, NULL );
			}
			if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1 )
			{
				perror("send failed");
				pthread_exit(NULL);
			}

		}
		else if( type == RGET )
		{
			//printf("inside rget\n");
			memset( file_name, 0, 256 );
			strcpy( file_name, cur_dir );
			strcat( file_name, cmsg + 2*sizeof(short) );
			if( is_directory(file_name) )
			{
				//printf("inside is_dire %s\n", file_name);
				fill_control_packet( cmsg, ACK, 0, NULL );
				if(dirp = opendir( file_name ))
				{
					while( entry = readdir(dirp) )
					{
						//printf("inside while%s\n", entry->d_name);
						strcat( cmsg + 2*sizeof(short), entry->d_name );
						strcat( cmsg + 2*sizeof(short), " " );
					}
					closedir( dirp );
				}
			}
			else
			{	
				fill_control_packet( cmsg, NACK, 0, NULL );
			}
			//printf("here %s", cmsg + 2*sizeof(short));
			if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0) == -1 )
			{
				perror("send failed");
				pthread_exit(NULL);
			}
		}
		else if( type == PWD )
		{
			fill_control_packet( cmsg, ACK, 0, cur_dir );
			if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0) == -1 )
			{
				perror("send failed");
				pthread_exit(NULL);
			}
		}
		else if( type == LS )
		{
			info = 0;
			//DIR *dirp;
			if( dirp = opendir( cur_dir ) )
			{
				//printf("yes");
				//char data[DATA_PACKET_LEN];
				//struct dirent *entry;
				while( entry = readdir(dirp) )
				{
					info++;
				}
				closedir( dirp );
				//printf("server info %d\n", info);
				fill_control_packet( cmsg, ACK, info, NULL );
				if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1 )
				{
					perror("send failed");
					pthread_exit(NULL);
				}
				dirp = opendir( cur_dir );
				while( entry = readdir(dirp) )
				{
					memset( data, 0, DATA_PACKET_LEN );
					memcpy( data, entry->d_name, strlen(entry->d_name) );
					if( send( d_sock, data, DATA_PACKET_LEN, 0 ) == -1 )
					{
						perror("data sending failed");
						pthread_exit(NULL);
					}
				}
				closedir( dirp );
			}
			else
			{
				//printf("No");
				fill_control_packet( cmsg, NACK, 0, NULL );
				if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1 )
				{
					perror("send failed");
					pthread_exit(NULL);
				}
			}
		}
		else if( type == CD )
		{
			//printf("Current Dir = %s", cur_dir);
			//printf("CD\n");
			if( *(cmsg + 2*sizeof(short)) == '/' )
			{
				memset( extra, 0, CNTRL_PACKET_LEN);
				strcpy( extra, cmsg + 2*sizeof(short) );
			}
			else
			{
				memset( extra, 0, CNTRL_PACKET_LEN);
				strcpy( extra, cur_dir );
				if( extra[strlen(extra)-1] != '/' )
					strcat( extra, "/");
				strcat( extra, cmsg + 2*sizeof(short) );
				//printf("inside cd %s\n", extra);
			}
			//printf("cd %s\n", extra);
			//printf("inside cd %s\n", extra);
			//struct stat temp;
			//file* FP = popen("cd %s", extra);
			//fseek( FP, 0L, SEEK_END );
			if( (stat(extra, &temp) == 0) && S_ISDIR(temp.st_mode) )//ftell(FP) == 0 )
			{
				//printf("Yes\n");
				memset( cur_dir, 0, 200 );
				strcpy( cur_dir, extra );
				if( cur_dir[strlen(cur_dir)-1] != '/' )
					cur_dir[strlen(cur_dir)] == '/';
				//printf("inside cd 2 %s\n", cur_dir);
				fill_control_packet( cmsg, ACK, 0, NULL );
			}
			else
 			{
				//printf("no\n");
				fill_control_packet( cmsg, NACK, 0, NULL );
			}
			if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1 )
			{
				perror("send failed");
				pthread_exit(NULL);
			}
			
		}
		else if( type == GET )
		{
			//FILE* fp; char data[DATA_PACKET_LEN];
			//char file_name[256];
			memset( file_name, 256, 0);
			strcpy( file_name, cur_dir );
			strcat( file_name, cmsg + 2*sizeof(short) );
			//printf("file_name %s\n", file_name);
			if( (!(fp = fopen(file_name, "r"))) || (is_directory(file_name)) )
			{
				fill_control_packet( cmsg, NACK, 0, NULL );
				if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1 )
				{
					perror("send failed");
					pthread_exit(NULL);
				}
			}
			else
			{
				fill_control_packet( cmsg, ACK, 0, NULL );
				if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1 )
				{
					perror("send failed");
					pthread_exit(NULL);
				}
				//printf("before calling send_file_server");
				memset( data, 0, DATA_PACKET_LEN);
				send_file_server( fp, d_sock, c_sock, data, cmsg);
			}
		}
		else if( type == MGET_W )
		{
			info = 0;
			//DIR *dirp;
			if( dirp = opendir( cur_dir ) )
			{
				//struct dirent *entry;
				//char pattern[CNTRL_PACKET_LEN];
				memset( pattern, 0, CNTRL_PACKET_LEN );
				strcpy( pattern, cmsg + 2*sizeof(short) );
				fill_control_packet( cmsg, ACK, info, NULL );
				while( entry = readdir(dirp) )
				{
					if( (entry->d_type == DT_REG) && wildcard( entry->d_name, pattern ) )
					{	
						strcat( cmsg + 2*sizeof(short), " ");
						strcat( cmsg + 2*sizeof(short), entry->d_name );
					}
				}
				if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1 )
				{
					perror("send failed");
					pthread_exit(NULL);
				}
			}
		}
		/*else if( type == RGET )
		{
			printf("RGET");
			if( !is_directory( cmsg + 2*sizeof(short)) )
			{
				printf("%s", cmsg+2*sizeof(short));
				fill_control_packet( cmsg, NACK, 0, NULL );
				if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1 )
				{
					perror("send failed");
					pthread_exit(NULL);
				}
			}
			else
			{
				char a[500], b[500];
				strcpy( a, cur_dir );
				strcat( a, cmsg + 2*sizeof(short) );
				strcpy(b, cur_dir );
				strcat(b, "help.txt");
				system("ls -R $a > $b");
				printf("%s", a);
				fill_control_packet( cmsg, ACK, 0, "help.txt" );
				if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1 )
				{
					perror("send failed");
					pthread_exit(NULL);
				}
			}
		}*/
		else if( type == PUT )
		{
			//FILE* fp; char data[DATA_PACKET_LEN];
			//char file_name[256];
			memset( file_name, 0, 256 );
			strcpy( file_name, cur_dir );
			strcat( file_name, cmsg + 2*sizeof(short) );
			if( !(fp = fopen(file_name, "w")) )
			{
				fill_control_packet( cmsg, NACK, 0, NULL );
				if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1 )
				{
					perror("send failed");
					pthread_exit(NULL);
				}
			}
			else
			{
				fill_control_packet( cmsg, ACK, 0, NULL );
				if( send( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1 )
				{
					perror("send failed");
					pthread_exit(NULL);
				}
				memset( data, 0, DATA_PACKET_LEN);
				receive_file_server( fp, d_sock, c_sock, data, cmsg);
			}
		}			
	}
}	

/* function that handles client sessions on the server side */		
void* worker_function( void* n_c )
{
	//extern char default_dir[];
	char cur_dir[200];
	strcpy( cur_dir, default_dir );
	struct client_info *new_client = (struct client_info*) n_c;
	char cmsg[CNTRL_PACKET_LEN];
	int d_sock;
	int c_sock = new_client->control_socket;
	memset( cmsg, 0, CNTRL_PACKET_LEN );
	if( recv( c_sock, cmsg, CNTRL_PACKET_LEN, 0 ) == -1 )
	{
		perror("recv failed");
		pthread_exit(NULL);
	}
	short data_port, type;
	memcpy( (void*)&data_port, (void*)(cmsg + sizeof(short)), sizeof(short) );
	memcpy( (void*)&type, (void*)(cmsg), sizeof(short) );
	data_port = ntohs(data_port);
	type = ntohs(type);
	int client_addr_len = sizeof(new_client->client_addr);
	(new_client->client_addr).sin_port = htons(data_port);
	
	/* This is active mode FTP. Server is initiating data connection
	   with client, which is listening on a specified socket */
	if( (d_sock = socket(AF_INET, SOCK_STREAM, 0)) == -1 )
	{
		perror("server data socket failed");
		free(new_client);
		pthread_exit(NULL);
	}
	if( connect(d_sock, (struct sockaddr*)&(new_client->client_addr), client_addr_len)<0 )
	{
		perror("connect failed");
		free(new_client);
		pthread_exit(NULL);
	}
	free(new_client);
	start_session_server_side( c_sock, d_sock, cur_dir, cmsg );
	//free(new_client);
	pthread_exit(NULL);
}
