/**********************************************************************************/
/*    Multi-threaded FTP server written by Abhinandan Nath, Roll no. 09010101     */
/* This server functions in active mode, i.e., the server listens on a designated */
/*  port for incoming connection requests. It opens a control connection for the  */
/*  incoming requests. For each such connection, it then initiates a data connec- */
/*  tion by sending a connection request back to the client. Being multi-thread,  */
/*           the server can handle multiple clients at the same time              */
/**********************************************************************************/

#include "common.c"
#include "ftp_server_header.c"
#define MAX_USER_LIMIT 20

int main()
{
	pthread_t tid;
	int l_sock, c_sock, cli_addr_len;
	struct sockaddr_in server_addr, *client_addr;
	struct client_info *new_client;
	server_addr.sin_family = AF_INET;
	char temp [500];
	getcwd( temp, 500 );
	if( temp[strlen(temp)-1] != "/" )
		strcat( temp, "/");
	if( default_dir[0] != "/" )
	{
		strcat( temp, default_dir );
		strcpy( default_dir, temp );
	}
	server_addr.sin_port = htons(SERVER_LISTEN_PORT);
	server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	
	/* server sets up lisening port and socket */
	if( (l_sock = socket(AF_INET, SOCK_STREAM, 0)) == -1 )
	{
		perror("server listen socket failed");
		exit(1);	
	}
	if( bind(l_sock, (struct sockaddr*)&server_addr, sizeof(server_addr))==-1 )
	{
		perror("bind failed");
		exit(1);
	}
	
	/* server starts listening on designated listening port
	   for incoming connection requests from client */
	if( listen( l_sock, MAX_USER_LIMIT ) == -1 )
	{
		perror("server listen failed");
		exit(1);
	}

	while(1)
	{
		new_client = (struct client_info*)malloc(sizeof(struct client_info)); 
		cli_addr_len = sizeof(new_client->client_addr);
		/* server accepts a new connection request from a client */
		if( (c_sock = accept( l_sock, (struct sock_addr*)&(new_client->client_addr), &cli_addr_len )) == -1 )
		{
			perror("accept failed");
			exit(1);
		}
		new_client->control_socket = c_sock;	
		
		/* server creates a thread for handling the client session */	
		if( pthread_create( &tid, NULL, worker_function, (void*)new_client ) )
		{
			printf("Error in thread creation. Exiting ...\n");
			exit(1);
		}
	}
}
		
		
	
