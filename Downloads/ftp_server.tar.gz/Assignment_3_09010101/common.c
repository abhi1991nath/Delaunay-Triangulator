#include <stdio.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define SERVER_LISTEN_PORT 4000
#define CNTRL_PACKET_LEN 500
#define DATA_PACKET_LEN 500
#define PORT 0
#define FIN 1
#define CD 2
#define ACK 3
#define NACK 4
#define LS 5
#define GET 6
#define PUT 7
#define MGET_W 8
#define MPUT_W 9
#define RGET 10
#define RGET_A 11
#define PWD 12
#define RPUT 13

/* checks if a filepath is a directory */
int is_directory( const char* path )
{
	struct stat temp;
	stat( path, &temp );
	if( S_ISDIR(temp.st_mode) ) return 1;
	return 0;	
}

/* checks if a string is a valid wildcard pattern */
int is_wildcard( const char* target )
{
	char* a = target;
	while(*a)
	{
		if(*a == '*') return 1;
		a++;
	}
	return 0;	
}

/* checks whether a given string matches a wildcard pattern */
int wildcard(const char *source, const char *pattern) {
	while(1) {
		//wildcard
		if (*pattern=='*') {
			// skip pattern while it's equal to '*'
			while(*pattern=='*')
				pattern++;

			// accept the rest of the string if the pattern ends in "*"
			if (*pattern==0)
				return 1;

			// enumerate the source string
			while(*source != *pattern) {
				// did the source string terminate?
				if (*source==0)
					// not what was wanted
					return 0;

				// okay, increment the source string
				source++;
			}

			// continue the loop
			continue;
		}

		// is the source character not equal to the pattern character?
		if (*source != *pattern)
			break; //break to keep the compiler happy

		// they're equal, is it a null termination?
		if (*source==0)
			return 1;

		// okay, there's more to the string, increment each
		source++;
		pattern++;
	}

	// not equal, return zero
	return 0;
}

/* gets the type of a received control packet */
short get_cntrl_packet_type( char* cmsg )
{
	short type;
	memcpy( (void*)&type, (void*)(cmsg), sizeof(short) );
	return ntohs(type);
}

void fill_control_packet( char* msg, short type, short info, char* extra )
{
	memset( msg, 0, CNTRL_PACKET_LEN );
	//if( type == ACK ) printf("ACK\n");
	short n_type = htons(type), n_info = htons(info);
	memcpy( (void*)msg, (void*)&n_type, sizeof(short) );
	memcpy( (void*)(msg + sizeof(short)), (void*)&n_info, sizeof(short) );
	if(extra) strcpy( (msg + 2*sizeof(short)), extra );
}

void collect_garbage( char** a, int n )
{
	//printf("Inside collect_garbage\n");
	int i = 0;
	for( i=0; i<n; i++ )
	{
		//printf("%s ", a[i]);
		free(a[i]);
	}
	free(a);
}

void run_shell_command( const char* a, char* b )
{
	if( b == NULL )
	{
		FILE* fp = popen( a, "r");
		pclose(fp);
	}
}

	
/*int main()
{
	int i, word_count;
	char* buf = (char*)malloc(sizeof(char)*200);
	char** words;
	gets(buf);
	words = remove_blanks( buf, &word_count );
	printf("%d", word_count );
	if( !words ) return -1;
	for( i=0; i<word_count; i++ )
	{
		printf("%s\n", words[i] );
	}
	return 0;
}*/
	
